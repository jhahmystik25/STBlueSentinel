#!/usr/bin/env node
'use strict';
/**
 * Plays the part of SeaTracePro for end-to-end testing: opens a WebSocket to YOUR receiver with the documented
 * X-SeaTrace-* headers, sends ONE signed text frame, and closes. Use it to test the whole chain
 * (gateway -> FCM -> phone) without waiting for a real alert or the SeaTracePro administrator's test cron.
 *
 *   BS_SECRET=<signing secret> node scripts/simulate-seatrace.js --url wss://alerts.example.com/bluesentinel \
 *        [--type notification_test|danger_zone_entry|...] [--severity high] [--id 12345] [--age 0]
 *
 * --age N signs the message N seconds in the past (to test the 300 s replay window and the app's stale handling).
 * The secret is read from the BS_SECRET environment variable only (never an argument: arguments end up in shell history).
 */
const crypto = require('node:crypto');
const WebSocket = require('ws');

function buildFrame({ type, severity, id }) {
  const test = type === 'notification_test';
  return JSON.stringify({
    schema_version: '1.0', source: 'seatracepro', product: 'bluesentinel', event: 'vessel_alert',
    alert_id: id, alert_type: type, severity: test ? 'info' : severity,
    title: test ? 'BlueSentinel notification test' : 'Simulated alert (not a real incident)',
    message: test ? 'This is a test message. It is not a real incident.' : 'Simulated by simulate-seatrace.js for end-to-end testing.',
    timestamp_utc: new Date().toISOString().replace(/\.\d+Z$/, 'Z'), created_utc: new Date().toISOString().replace(/\.\d+Z$/, 'Z'),
    ...(test ? { test: true, test_notice: 'Dummy data - not a real vessel or incident.' } : {}),
    vessel: { ship_id: 123456789, mmsi: 123456789, ship_name: test ? 'TEST VESSEL' : 'MV SIMULATED', latitude: 5.123456, longitude: -0.123456, speed_knots: 14.7, course_deg: 182.4 },
    ...(test ? {} : { threat: { state: 'INSIDE', area_label: 'Simulated area', nearest_incident_km: 3.4, incidents_within_radius: 4, radius_km: 50 } }),
  });
}

function sign(secret, timestamp, frame) {
  return 'sha256=' + crypto.createHmac('sha256', secret).update(timestamp + '.' + frame).digest('hex');
}

function send({ url, secret, frame, alertId, ageSeconds = 0, headersOverride = {} }) {
  const timestamp = String(Math.floor(Date.now() / 1000) - ageSeconds);
  const headers = {
    'X-SeaTrace-Event': 'vessel_alert', 'X-SeaTrace-Alert-Id': alertId, 'X-SeaTrace-Timestamp': timestamp,
    'X-SeaTrace-Signature': sign(secret, timestamp, frame), ...headersOverride,
  };
  for (const k of Object.keys(headers)) if (headers[k] === null) delete headers[k]; // null = omit this header
  return new Promise((resolve) => {
    const ws = new WebSocket(url, { headers, followRedirects: false, handshakeTimeout: 10_000 });
    ws.on('open', () => ws.send(frame));
    ws.on('close', (code, reason) => resolve({ closed: true, code, reason: reason.toString() }));
    ws.on('unexpected-response', (_req, res) => { resolve({ rejected: true, status: res.statusCode }); res.resume(); });
    ws.on('error', (e) => resolve({ error: e.message }));
  });
}

if (require.main === module) {
  const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i > 0 ? process.argv[i + 1] : d; };
  const url = arg('url');
  const secret = process.env.BS_SECRET;
  if (!url || !secret) { console.error('usage: BS_SECRET=... node scripts/simulate-seatrace.js --url wss://host/path [--type T] [--severity S] [--id ID] [--age SECONDS]'); process.exit(2); }
  const host = new URL(url).hostname;
  if (!url.startsWith('wss://') && !['127.0.0.1', 'localhost'].includes(host)) { console.error('Refusing: plain ws:// is only allowed for localhost.'); process.exit(2); }
  const id = arg('id', String(Date.now()));
  const frame = buildFrame({ type: arg('type', 'notification_test'), severity: arg('severity', 'high'), id });
  send({ url, secret, frame, alertId: id, ageSeconds: Number(arg('age', '0')) }).then((r) => { console.log(JSON.stringify({ alert_id: id, ...r })); process.exit(r.error ? 1 : 0); });
}

module.exports = { buildFrame, sign, send };
