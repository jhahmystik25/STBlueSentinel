#!/usr/bin/env node
'use strict';
/**
 * Adds/updates a phone for a subscriber in the registry file.
 *   FCM_TOKEN=<token from the app: Settings > This device > Copy push token> \
 *   node scripts/add-device.js --subscriber acme-fleet --device-id <Device ID shown in the app> [--file config/subscribers.json]
 * The token is read from the FCM_TOKEN environment variable (not an argument) so it stays out of shell history.
 * The file is written with mode 600. Then send SIGHUP to the running gateway (or restart it) to reload.
 */
const fs = require('node:fs');
const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i > 0 ? process.argv[i + 1] : d; };
const file = arg('file', './config/subscribers.json'), subscriberId = arg('subscriber'), deviceId = arg('device-id'), token = process.env.FCM_TOKEN;
if (!subscriberId || !deviceId || !token) { console.error('usage: FCM_TOKEN=... node scripts/add-device.js --subscriber ID --device-id ID [--file path]'); process.exit(2); }
if (!/^[A-Za-z0-9_.-]{1,64}$/.test(deviceId)) { console.error('device-id has invalid characters'); process.exit(2); }
if (!/^[A-Za-z0-9:_\-.]{20,4096}$/.test(token)) { console.error('FCM_TOKEN does not look like an FCM registration token'); process.exit(2); }
const json = JSON.parse(fs.readFileSync(file, 'utf8'));
const sub = json.subscribers.find((s) => s.id === subscriberId);
if (!sub) { console.error(`no subscriber "${subscriberId}" in ${file}`); process.exit(2); }
sub.devices = sub.devices || [];
const existing = sub.devices.find((d) => d.id === deviceId);
if (existing) existing.token = token; else sub.devices.push({ id: deviceId, token });
fs.writeFileSync(file, JSON.stringify(json, null, 2) + '\n', { mode: 0o600 });
fs.chmodSync(file, 0o600);
console.log(`${existing ? 'updated' : 'added'} device "${deviceId}" for subscriber "${subscriberId}"`);
