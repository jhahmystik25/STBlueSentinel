# BlueSentinel receiver gateway (reference implementation)

The component that makes STBlueSentinel work. SeaTracePro connects **to this server**, not the other way round:

```
SeaTracePro --wss (X-SeaTrace-* headers + ONE signed text frame)--> THIS GATEWAY --FCM data message--> STBlueSentinel
```

For each alert the gateway: checks the handshake headers and the **300-second replay window**, verifies the **HMAC-SHA256 over the exact received bytes**, validates the schema, **de-duplicates on the verified `alert_id`**, and relays the original frame (base64) to the owner's phones as a **data-only, high-priority FCM message with a 300 s TTL**. The phone then verifies again.

It is a reference: small, dependency-light (`ws`, `firebase-admin`), and fully tested. Read it before putting it in front of real alerts.

## Security properties

| Property | How |
|---|---|
| No unsigned or forged alert is relayed | HMAC-SHA256 over `timestamp + "." + exact frame bytes`, constant-time compare. Nothing is parsed, re-serialised or normalised before the check. |
| Strict replay window | `abs(now - X-SeaTrace-Timestamp) > 300` is refused at the handshake **and** again when the frame is processed. Never relaxed. |
| Correct owner | Keys are per user and per vessel. Every configured secret is tried; whichever verifies identifies the subscriber (and therefore which phones receive it). |
| Cannot be tricked by the unsigned header | `X-SeaTrace-Alert-Id` is *not* covered by the signature. De-duplication uses the alert_id from the **verified body**, and the header must equal it. |
| Retries are harmless | Same `alert_id` within 3 h = duplicate, ignored. A transient FCM failure is *not* recorded as delivered, so SeaTracePro's retry can still get through. |
| Secrets stay here | Signing secrets are never put in FCM, logs or errors. They come from environment variables (preferred) or a `0600` file. The logger drops sensitive-looking fields. |
| Size rule | A frame that would push the FCM data over **4096 bytes** is rejected and logged. Never truncated, compressed, split or re-encoded. |
| Abuse resistance | 32 KB frame cap, text frames only, exactly one frame per connection, 10 s frame timeout, per-IP rate limit, connection cap, no compression, no redirects. |
| TLS | Refuses to listen in plaintext on a public address. Terminate TLS in a reverse proxy (loopback bind) or in the gateway itself. |

## Quick start

```bash
cd gateway
npm install                                   # then commit package-lock.json
cp config/subscribers.example.json config/subscribers.json
cp .env.example .env                          # edit; export the variables (or use your secret manager)
export BS_SECRET_ACME_FLEET='<signing secret from BlueSentinel>'
export FIREBASE_SERVICE_ACCOUNT_FILE=/etc/bluesentinel/firebase-service-account.json
npm start
```

1. **Signing secret**: SeaTracePro → BlueSentinel → the vessel → *Show WebSocket signing secret*. One subscriber entry per distinct secret. Several vessels owned by one person = several entries pointing at the same devices.
2. **Register a phone**: in STBlueSentinel open *Settings → This device*, note the **Device ID**, tap **Copy push token**, then:
   ```bash
   FCM_TOKEN='<pasted token>' npm run device:add -- --subscriber acme-fleet --device-id <Device ID>
   kill -HUP $(pgrep -f "node src/index.js")      # reload without restarting
   ```
3. **Give SeaTracePro the public URL**, for example `wss://alerts.example.com/bluesentinel`. It must be the final URL: SeaTracePro does not follow redirects.
4. **Test the whole chain** without waiting for a real alert:
   ```bash
   BS_SECRET="$BS_SECRET_ACME_FLEET" node scripts/simulate-seatrace.js \
     --url wss://alerts.example.com/bluesentinel --type notification_test
   ```
   `--age 400` signs 400 s in the past (must be refused: outside the replay window). Also use SeaTracePro's own test-notification action for the real thing.

## Configuration (environment)

| Variable | Default | Meaning |
|---|---|---|
| `HOST` / `PORT` | `127.0.0.1` / `8443` | Bind address. Non-loopback needs TLS (below) or the proxy flags. |
| `WS_PATH` | `/bluesentinel` | The only path that accepts WebSocket upgrades. No query string. |
| `TLS_CERT_FILE`, `TLS_KEY_FILE` | unset | Terminate TLS in the gateway (TLS 1.2+). Set both. |
| `TRUST_PROXY`, `ALLOW_PLAINTEXT_BEHIND_PROXY` | false | Allow a non-loopback plaintext bind **only** on a private network behind your own TLS proxy. `TRUST_PROXY` also enables `X-Forwarded-For` (rightmost entry) for rate limiting. |
| `SUBSCRIBERS_FILE` | `./config/subscribers.json` | Registry (see example). Secrets via `"secretEnv"`. |
| `FIREBASE_SERVICE_ACCOUNT_FILE` | unset | Else `GOOGLE_APPLICATION_CREDENTIALS`. Never commit it. |
| `FCM_DRY_RUN` | false | Validate messages with Firebase without delivering. |
| `MAX_CONNECTIONS`, `RATE_PER_IP_PER_MINUTE`, `FRAME_TIMEOUT_MS` | 200, 60, 10000 | Limits. |
| `LOG_LEVEL` | `info` | `debug`/`info`/`warn`/`error`. JSON lines on stdout. |

## Reverse proxy examples

**Caddy** (WebSockets and custom headers work out of the box; certificates are automatic):
```
alerts.example.com {
    reverse_proxy /bluesentinel 127.0.0.1:8443
}
```

**nginx**:
```nginx
location = /bluesentinel {
    proxy_pass http://127.0.0.1:8443;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_set_header X-Forwarded-For $remote_addr;   # overwrite, never append client-supplied values
    proxy_read_timeout 30s;
    # X-SeaTrace-* headers are forwarded by default; do not strip or rename them.
}
```

The endpoint must be publicly reachable, have a publicly trusted certificate for its host name, and carry no credentials or secrets in the URL.

## Operating it

Logged events (JSON lines): `gateway_started`, `handshake_rejected{reason}`, `frame_rejected{reason}`, `alert_relayed`, `duplicate_ignored`, `push_failed{kind,code}`, `device_token_invalid`, `no_devices`, `alert_too_large_for_fcm`, `registry_reloaded`.

* **`device_token_invalid`**: that phone's token is dead (app reinstalled / data cleared). Re-run `device:add` with the phone's new token.
* **`push_failed` with `kind:"config"`**: Firebase credentials or project problem. Fix and the next SeaTracePro retry will deliver.
* **`alert_too_large_for_fcm`**: the alert would exceed 4 KB once encoded. It is not delivered to phones (it remains in SeaTracePro). The usable frame size is about 2.9 KB.
* **Rotating a secret**: update the environment variable and `SIGHUP`. Both old and new may be listed as two subscribers during the changeover (each secret must be unique).
* **Stopping**: `SIGTERM` closes the server gracefully.

## Known limits (by design, for a reference)

* **Single instance.** De-duplication is in memory. For several instances, implement `begin/commit/abort` from `src/dedupe.js` on Redis (`SET key NX PX`).
* **Dead-token state is in memory** (cleared on reload/restart); the log is the record to act on.
* **5-minute FCM TTL.** A phone that is offline for more than 5 minutes does not receive that alert. This is deliberate (live alerts must not arrive late) and is documented in `docs/FCM_CONTRACT.md`.
* **Reachability ≠ delivery.** The phone's *Test connection* only proves your endpoint is reachable over TLS.

## Tests

```bash
npm test          # node --test: 58 tests, real HTTP server + real WebSocket client, mock FCM sender
```
Covers the cross-checked HMAC vector (Python, the documentation's Node snippet, and the Kotlin app all agree), the 300 s window at ±299/301 s, tampering and forgery, header-swap replay, duplicates and in-flight races, per-subscriber routing, oversize frames and payloads, transient/permanent/configuration FCM failures, rate and connection limits, and that logs never contain secrets, signatures, tokens or frames.
