'use strict';

/**
 * De-duplication on the VERIFIED body alert_id (never the unsigned X-SeaTrace-Alert-Id header, which an attacker could swap
 * when replaying a captured frame). SeaTracePro retries re-send the same alert_id for up to 2 hours, so entries live 3 hours.
 *
 * begin() -> 'new' | 'duplicate' | 'in_flight'
 *   new       : caller must later commit() (delivered / permanently undeliverable) or abort() (transient failure, allow a retry)
 *   duplicate : already delivered -> do nothing
 *   in_flight : an identical alert is being processed right now -> do nothing
 *
 * In-memory: correct for a single gateway instance. For several instances, implement the same interface on Redis (SET NX PX).
 */
class Dedupe {
  constructor({ ttlMs = 3 * 60 * 60 * 1000, maxEntries = 100_000, now = Date.now } = {}) {
    this.ttlMs = ttlMs; this.maxEntries = maxEntries; this.now = now; this.entries = new Map();
  }

  begin(key) {
    this._expire();
    const e = this.entries.get(key);
    if (e) return e.state === 'done' ? 'duplicate' : 'in_flight';
    if (this.entries.size >= this.maxEntries) this._evictOldest();
    this.entries.set(key, { state: 'in_flight', at: this.now() });
    return 'new';
  }
  commit(key) { this.entries.delete(key); this.entries.set(key, { state: 'done', at: this.now() }); }
  abort(key) { const e = this.entries.get(key); if (e && e.state === 'in_flight') this.entries.delete(key); }
  get size() { return this.entries.size; }

  _expire() {
    const cutoff = this.now() - this.ttlMs;
    for (const [k, e] of this.entries) { if (e.at < cutoff) this.entries.delete(k); else break; } // Map keeps insertion (= time) order
  }
  _evictOldest() { const first = this.entries.keys().next(); if (!first.done) this.entries.delete(first.value); }
}

module.exports = { Dedupe };
