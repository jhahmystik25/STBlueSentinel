'use strict';

/**
 * Gateway -> STBlueSentinel FCM contract v1 (mirrors docs/FCM_CONTRACT.md and the Android FcmEnvelopeParser):
 *   - data-only message (NO `notification` block), so the app's FirebaseMessagingService always runs and re-verifies;
 *   - android.priority "high" (wakes a dozing device), android.ttl 300 s (a live alert must not arrive late),
 *     NO collapse_key (distinct alerts must never replace each other);
 *   - the exact original frame, base64, plus the verbatim header values; NEVER any secret or key material;
 *   - if the data would exceed 4096 bytes the alert is REJECTED - never truncated, compressed, split or re-encoded.
 */
const CONTRACT_VERSION = '1';
const MAX_PAYLOAD_BYTES = 4096;
const TTL_MS = 300 * 1000;

class PayloadTooLargeError extends Error {
  constructor(size) { super(`FCM data payload is ${size} bytes (limit ${MAX_PAYLOAD_BYTES})`); this.name = 'PayloadTooLargeError'; this.size = size; }
}

/** Same measure as the Android client: sum of UTF-8 bytes of every key and value. */
function payloadSize(data) {
  let n = 0;
  for (const [k, v] of Object.entries(data)) n += Buffer.byteLength(k, 'utf8') + Buffer.byteLength(v, 'utf8');
  return n;
}

function buildFcmData({ event, alertId, timestamp, signature, frame }) {
  const data = {
    v: CONTRACT_VERSION,
    event,
    alert_id: alertId,
    ts: timestamp,
    sig: signature,
    frame_b64: Buffer.from(frame).toString('base64'),   // standard alphabet, padded, no line breaks
  };
  const size = payloadSize(data);
  if (size > MAX_PAYLOAD_BYTES) throw new PayloadTooLargeError(size);
  return data;
}

function buildMessage(token, data) {
  return { token, data, android: { priority: 'high', ttl: TTL_MS } };
}

/** Largest raw frame (bytes) that still fits, for documentation/diagnostics. */
function maxFrameBytes({ event = 'vessel_alert', alertId = '0'.repeat(10), timestamp = '1790000000', signature = 'sha256=' + '0'.repeat(64) } = {}) {
  const overhead = payloadSize({ v: '1', event, alert_id: alertId, ts: timestamp, sig: signature, frame_b64: '' });
  return Math.floor(((MAX_PAYLOAD_BYTES - overhead) / 4)) * 3;
}

class PushError extends Error {
  /** kind: 'invalid_token' (remove device) | 'transient' (retry) | 'config' (operator must fix) | 'permanent' */
  constructor(kind, code) { super(`push failed: ${kind}`); this.name = 'PushError'; this.kind = kind; this.code = code; }
}

function classifyFirebaseError(err) {
  const code = (err && err.code) || '';
  if (code === 'messaging/registration-token-not-registered' || code === 'messaging/invalid-registration-token') return new PushError('invalid_token', code);
  if (['messaging/server-unavailable', 'messaging/internal-error', 'messaging/message-rate-exceeded', 'messaging/device-message-rate-exceeded', 'app/network-error', 'app/network-timeout', 'messaging/unknown-error'].includes(code)) return new PushError('transient', code);
  if (['messaging/authentication-error', 'messaging/third-party-auth-error', 'app/invalid-credential', 'messaging/mismatched-credential', 'messaging/invalid-apns-credentials'].includes(code)) return new PushError('config', code);
  if (!code) return new PushError('transient', 'unknown');           // network-level failures carry no code
  return new PushError('permanent', code);
}

/**
 * Real sender backed by firebase-admin. Credentials come from GOOGLE_APPLICATION_CREDENTIALS or an explicit
 * service-account file path - never from source code or the repository.
 */
function createFirebaseSender({ serviceAccountFile, dryRun = false, adminModule } = {}) {
  const admin = adminModule || require('firebase-admin');
  const fs = require('node:fs');
  const credential = serviceAccountFile
    ? admin.credential.cert(JSON.parse(fs.readFileSync(serviceAccountFile, 'utf8')))
    : admin.credential.applicationDefault();
  const app = admin.initializeApp({ credential }, 'bluesentinel-gateway');
  const messaging = admin.messaging(app);
  return {
    async send(token, data) {
      try { await messaging.send(buildMessage(token, data), dryRun); }
      catch (err) { throw classifyFirebaseError(err); }
    },
  };
}

module.exports = {
  CONTRACT_VERSION, MAX_PAYLOAD_BYTES, TTL_MS, PayloadTooLargeError, PushError,
  payloadSize, buildFcmData, buildMessage, maxFrameBytes, classifyFirebaseError, createFirebaseSender,
};
