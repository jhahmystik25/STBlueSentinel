#!/usr/bin/env node
'use strict';
const { loadConfig } = require('./config');
const { createLogger } = require('./logger');
const { Registry } = require('./registry');
const { Dedupe } = require('./dedupe');
const { createFirebaseSender } = require('./fcm');
const { createGateway } = require('./server');

async function main() {
  const config = loadConfig(process.env);
  const logger = createLogger(config.logLevel);
  const registry = new Registry(config.subscribersFile);
  const sender = createFirebaseSender({ serviceAccountFile: config.serviceAccountFile || undefined, dryRun: config.fcmDryRun });
  const gateway = createGateway({ config, registry, sender, dedupe: new Dedupe(), logger });

  const addr = await gateway.start();
  logger.info('gateway_started', { host: addr.address, port: addr.port, path: config.wsPath, tls: Boolean(config.tls), subscribers: registry.subscribers.length, fcm_dry_run: config.fcmDryRun });

  process.on('SIGHUP', () => { try { logger.info('registry_reloaded', { subscribers: registry.reload() }); } catch (e) { logger.error('registry_reload_failed', { error: e.message }); } });
  const shutdown = async (sig) => { logger.info('shutting_down', { signal: sig }); await gateway.stop(); process.exit(0); };
  process.on('SIGTERM', () => shutdown('SIGTERM')); process.on('SIGINT', () => shutdown('SIGINT'));
}

main().catch((e) => { process.stderr.write(`Fatal: ${e.message}\n`); process.exit(1); });
