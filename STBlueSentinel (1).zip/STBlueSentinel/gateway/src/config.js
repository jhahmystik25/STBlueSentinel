'use strict';

const LOOPBACK = new Set(['127.0.0.1', '::1', 'localhost']);

function int(env, name, def, min, max) {
  const raw = env[name];
  if (raw === undefined || raw === '') return def;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < min || n > max) throw new Error(`${name} must be an integer between ${min} and ${max}`);
  return n;
}
const bool = (env, name) => ['1', 'true', 'yes'].includes(String(env[name] || '').toLowerCase());

/**
 * Environment-driven configuration. Safe-by-default networking: without TLS the gateway only listens on loopback
 * (for use behind a TLS-terminating reverse proxy) and refuses to bind publicly in plaintext.
 */
function loadConfig(env = process.env) {
  const tlsCert = env.TLS_CERT_FILE || '', tlsKey = env.TLS_KEY_FILE || '';
  if (Boolean(tlsCert) !== Boolean(tlsKey)) throw new Error('TLS_CERT_FILE and TLS_KEY_FILE must be set together');
  const tls = Boolean(tlsCert);
  const host = env.HOST || '127.0.0.1';
  const trustProxy = bool(env, 'TRUST_PROXY');
  if (!tls && !LOOPBACK.has(host) && !(bool(env, 'ALLOW_PLAINTEXT_BEHIND_PROXY') && trustProxy)) {
    throw new Error('Refusing to listen in plaintext on a non-loopback address. SeaTracePro requires wss://. Set TLS_CERT_FILE/TLS_KEY_FILE, ' +
      'or bind to 127.0.0.1 behind a TLS reverse proxy (or set TRUST_PROXY=true and ALLOW_PLAINTEXT_BEHIND_PROXY=true if the proxy is on a private network).');
  }
  const wsPath = env.WS_PATH || '/bluesentinel';
  if (!/^\/[A-Za-z0-9_\-./]*$/.test(wsPath)) throw new Error('WS_PATH must be a plain path such as /bluesentinel (no query string)');
  return {
    host, port: int(env, 'PORT', 8443, 0, 65535), wsPath, tls: tls ? { certFile: tlsCert, keyFile: tlsKey } : null, trustProxy,
    maxConnections: int(env, 'MAX_CONNECTIONS', 200, 1, 100000),
    maxFrameBytes: 32 * 1024,                                           // documented ceiling
    frameTimeoutMs: int(env, 'FRAME_TIMEOUT_MS', 10_000, 100, 120_000),
    ratePerIpPerMinute: int(env, 'RATE_PER_IP_PER_MINUTE', 60, 1, 100000),
    subscribersFile: env.SUBSCRIBERS_FILE || './config/subscribers.json',
    serviceAccountFile: env.FIREBASE_SERVICE_ACCOUNT_FILE || '',        // else GOOGLE_APPLICATION_CREDENTIALS (application default)
    fcmDryRun: bool(env, 'FCM_DRY_RUN'),
    logLevel: env.LOG_LEVEL || 'info',
    retryDelaysMs: [250, 1000],
  };
}

module.exports = { loadConfig };
