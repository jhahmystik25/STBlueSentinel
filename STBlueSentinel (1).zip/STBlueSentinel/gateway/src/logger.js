'use strict';

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
// Defence in depth: even if a caller passes one of these by mistake, it is never written out.
const FORBIDDEN_KEYS = /secret|token|signature|^sig$|frame|payload|authorization|password|credential|key/i;

/** Structured JSON-lines logger. Call sites log identifiers and outcomes only; sensitive-looking keys are dropped. */
function createLogger(level = 'info', write = (line) => process.stdout.write(line + '\n')) {
  const threshold = LEVELS[level] ?? LEVELS.info;
  function log(lvl, msg, fields = {}) {
    if (LEVELS[lvl] < threshold) return;
    const safe = {};
    for (const [k, v] of Object.entries(fields)) {
      if (FORBIDDEN_KEYS.test(k)) continue;
      safe[k] = v instanceof Error ? v.name : v;
    }
    write(JSON.stringify({ ts: new Date().toISOString(), level: lvl, msg, ...safe }));
  }
  return {
    debug: (m, f) => log('debug', m, f),
    info: (m, f) => log('info', m, f),
    warn: (m, f) => log('warn', m, f),
    error: (m, f) => log('error', m, f),
  };
}

module.exports = { createLogger, FORBIDDEN_KEYS };
