'use strict';
const fs = require('node:fs');

const MAX_SUBSCRIBERS = 256;
const MAX_DEVICES_PER_SUBSCRIBER = 20;
const SECRET_MIN = 16, SECRET_MAX = 256;
const TOKEN_FORMAT = /^[A-Za-z0-9:_\-.]{20,4096}$/;

/**
 * Subscribers: who owns which BlueSentinel signing secret, and which phones receive their alerts.
 * The secret is per user and per vessel in BlueSentinel; give each distinct secret its own subscriber entry
 * (several vessels owned by one person = several entries pointing at the same devices).
 * Secrets are best supplied via environment variables (`secretEnv`) so they can come from a secret manager.
 */
function parseRegistry(json, env = process.env) {
  if (!json || !Array.isArray(json.subscribers) || json.subscribers.length === 0) throw new Error('registry: "subscribers" must be a non-empty array');
  if (json.subscribers.length > MAX_SUBSCRIBERS) throw new Error(`registry: more than ${MAX_SUBSCRIBERS} subscribers`);
  const ids = new Set(); const secrets = new Set();
  const subscribers = json.subscribers.map((s, i) => {
    const label = `subscribers[${i}]`;
    if (typeof s.id !== 'string' || !/^[A-Za-z0-9_.-]{1,64}$/.test(s.id)) throw new Error(`${label}: invalid id`);
    if (ids.has(s.id)) throw new Error(`${label}: duplicate id "${s.id}"`);
    ids.add(s.id);
    const secretText = s.secretEnv ? env[s.secretEnv] : s.secret;
    if (typeof secretText !== 'string') throw new Error(`${label} (${s.id}): no secret (set "secretEnv" and export that variable, or "secret")`);
    const secret = secretText.trim();
    if (secret.length < SECRET_MIN || secret.length > SECRET_MAX || !/^[\x21-\x7e]+$/.test(secret)) throw new Error(`${label} (${s.id}): secret must be ${SECRET_MIN}-${SECRET_MAX} visible characters, no spaces`);
    if (secrets.has(secret)) throw new Error(`${label} (${s.id}): secret duplicates another subscriber's (the owner could not be identified)`);
    secrets.add(secret);
    const devices = (s.devices || []).map((d, j) => {
      if (typeof d.id !== 'string' || !/^[A-Za-z0-9_.-]{1,64}$/.test(d.id)) throw new Error(`${label}.devices[${j}]: invalid id`);
      if (typeof d.token !== 'string' || !TOKEN_FORMAT.test(d.token)) throw new Error(`${label}.devices[${j}]: invalid FCM token`);
      return { id: d.id, token: d.token };
    });
    if (devices.length > MAX_DEVICES_PER_SUBSCRIBER) throw new Error(`${label}: more than ${MAX_DEVICES_PER_SUBSCRIBER} devices`);
    return { id: s.id, secret: Buffer.from(secret, 'utf8'), devices };
  });
  return { subscribers };
}

/** Holds the live registry (reloadable on SIGHUP) and the set of devices whose token FCM reported as dead. */
class Registry {
  /** @param source path to a JSON file, or an already-parsed object (used by tests) */
  constructor(source, env = process.env) { this.source = source; this.env = env; this.dead = new Set(); this.data = { subscribers: [] }; this.reload(); }
  reload() {
    const json = typeof this.source === 'string' ? JSON.parse(fs.readFileSync(this.source, 'utf8')) : this.source;
    this.data = parseRegistry(json, this.env); this.dead = new Set(); return this.data.subscribers.length;
  }
  get subscribers() { return this.data.subscribers; }
  liveDevices(subscriber) { return subscriber.devices.filter((d) => !this.dead.has(`${subscriber.id}/${d.id}`)); }
  markDead(subscriber, device) { this.dead.add(`${subscriber.id}/${device.id}`); }
}

module.exports = { parseRegistry, Registry };
