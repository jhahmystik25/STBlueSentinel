'use strict';
const http = require('node:http');
const https = require('node:https');
const fs = require('node:fs');
const { WebSocketServer } = require('ws');
const { validateHandshakeHeaders, checkTimestamp, findMatchingSubscriber, MAX_ALERT_ID_LENGTH } = require('./verify');
const { buildFcmData, PayloadTooLargeError } = require('./fcm');

const EXPECTED = { source: 'seatracepro', product: 'bluesentinel', event: 'vessel_alert', schemaMajor: '1' };
const utf8 = new TextDecoder('utf-8', { fatal: true });

/** Fixed-window per-IP limiter. Cheap protection against handshake floods; the HMAC is the real gate. */
class RateLimiter {
  constructor(perMinute, now = Date.now) { this.perMinute = perMinute; this.now = now; this.hits = new Map(); }
  allow(ip) {
    const minute = Math.floor(this.now() / 60000);
    const e = this.hits.get(ip);
    if (!e || e.minute !== minute) {
      if (this.hits.size > 50_000) this.hits.clear();
      this.hits.set(ip, { minute, n: 1 }); return true;
    }
    return ++e.n <= this.perMinute;
  }
}

function reject(socket, status, text) {
  if (socket.destroyed) return;
  socket.write(`HTTP/1.1 ${status} ${text}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`);
  socket.destroy();
}

function clientIp(req, trustProxy) {
  if (trustProxy) { // rightmost entry = the one appended by OUR trusted proxy; earlier entries are client-controlled
    const xff = req.headers['x-forwarded-for'];
    if (typeof xff === 'string' && xff) return xff.split(',').pop().trim();
  }
  return req.socket.remoteAddress || 'unknown';
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * @param {object} deps config, registry, sender ({send(token, data)}), dedupe, logger, now() -> epoch seconds
 */
function createGateway({ config, registry, sender, dedupe, logger, now = () => Date.now() / 1000 }) {
  const limiter = new RateLimiter(config.ratePerIpPerMinute);
  const stats = { connections: 0, accepted: 0, handshakeRejected: 0, frameRejected: 0, duplicates: 0, relayed: 0, pushFailures: 0 };
  let active = 0;

  const requestListener = (req, res) => {
    if (req.method === 'GET' && req.url === '/healthz') { res.writeHead(200, { 'Content-Type': 'text/plain', Connection: 'close' }); res.end('ok'); return; }
    res.writeHead(404, { Connection: 'close' }); res.end();
  };
  const server = config.tls
    ? https.createServer({ cert: fs.readFileSync(config.tls.certFile), key: fs.readFileSync(config.tls.keyFile), minVersion: 'TLSv1.2' }, requestListener)
    : http.createServer(requestListener);
  server.headersTimeout = 10_000; server.requestTimeout = 15_000; server.maxHeadersCount = 50;

  const wss = new WebSocketServer({ noServer: true, maxPayload: config.maxFrameBytes, perMessageDeflate: false, clientTracking: false });

  server.on('upgrade', (req, socket, head) => {
    socket.on('error', () => {});
    stats.connections++;
    let pathname = '';
    try { pathname = new URL(req.url, 'http://gateway.invalid').pathname; } catch { /* leave empty */ }
    const ip = clientIp(req, config.trustProxy);

    if (pathname !== config.wsPath) { stats.handshakeRejected++; return reject(socket, 404, 'Not Found'); }
    if (!limiter.allow(ip)) { stats.handshakeRejected++; logger.warn('handshake_rejected', { reason: 'rate_limited', ip }); return reject(socket, 429, 'Too Many Requests'); }
    if (active >= config.maxConnections) { stats.handshakeRejected++; logger.warn('handshake_rejected', { reason: 'busy' }); return reject(socket, 503, 'Service Unavailable'); }

    // Reject early, before accepting any frame. Generic status only: nothing here helps an attacker tune a forgery.
    const h = validateHandshakeHeaders(req.headers, now());
    if (!h.ok) { stats.handshakeRejected++; logger.warn('handshake_rejected', { reason: h.reason, ip }); return reject(socket, 401, 'Unauthorized'); }

    wss.handleUpgrade(req, socket, head, (ws) => { stats.accepted++; handleConnection(ws, h, ip); });
  });

  function handleConnection(ws, hs, ip) {
    active++;
    let handled = false;
    const frameTimer = setTimeout(() => { logger.warn('frame_timeout', { alert_id_hdr: hs.alertId }); ws.close(1008, 'timeout'); }, config.frameTimeoutMs);
    ws.on('error', () => { /* oversize frame / protocol error: ws closes the socket itself */ });
    ws.on('close', () => { clearTimeout(frameTimer); active--; });

    ws.on('message', async (data, isBinary) => {
      if (handled) return ws.terminate();           // exactly one frame per connection
      handled = true; clearTimeout(frameTimer);
      if (isBinary) { stats.frameRejected++; logger.warn('frame_rejected', { reason: 'binary_frame' }); return ws.close(1003, 'text only'); }
      const frame = Array.isArray(data) ? Buffer.concat(data) : Buffer.from(data);
      let outcome;
      try { outcome = await processFrame(hs, frame); }
      catch (e) { outcome = 'internal_error'; logger.error('processing_error', { error: e.name }); }
      if (!ws.readyState || ws.readyState === ws.OPEN) ws.close(outcome === 'relayed' || outcome === 'duplicate' ? 1000 : 1008, outcome.slice(0, 100));
    });
  }

  async function processFrame(hs, frame) {
    // 1. Timestamp window again at processing time (the handshake check may be seconds old).
    const ts = checkTimestamp(hs.timestamp, now());
    if (!ts.ok) return rejectFrame(ts.reason, hs);

    // 2. HMAC over the exact received bytes, trying every subscriber secret. No parsing happens before this.
    const sub = findMatchingSubscriber(registry.subscribers, hs.timestamp, frame, hs.signature);
    if (!sub) return rejectFrame('signature_invalid', hs);

    // 3. Only now is the body authentic. Strict UTF-8, then JSON; unknown fields are ignored.
    let alert;
    try { alert = JSON.parse(utf8.decode(frame)); } catch { return rejectFrame('malformed_json', hs, sub); }
    if (alert === null || typeof alert !== 'object' || Array.isArray(alert)) return rejectFrame('malformed_json', hs, sub);
    if (String(alert.schema_version ?? '').split('.')[0] !== EXPECTED.schemaMajor) return rejectFrame('unsupported_schema', hs, sub);
    if (alert.source !== EXPECTED.source || alert.product !== EXPECTED.product || alert.event !== EXPECTED.event) return rejectFrame('invalid_schema', hs, sub);
    const alertId = alert.alert_id;
    if (typeof alertId !== 'string' || alertId.length === 0 || alertId.length > MAX_ALERT_ID_LENGTH) return rejectFrame('invalid_schema', hs, sub);
    // The alert-id header is NOT covered by the signature; it must agree with the signed body.
    if (alertId !== hs.alertId) return rejectFrame('alert_id_mismatch', hs, sub);

    // 4. De-duplicate on the verified alert_id (SeaTracePro retries re-send it for up to 2 h).
    const key = `${sub.id}:${alertId}`;
    const state = dedupe.begin(key);
    if (state !== 'new') { stats.duplicates++; logger.info('duplicate_ignored', { alert_id: alertId, subscriber: sub.id, state }); return 'duplicate'; }

    // 5. Build the FCM data. Oversize alerts are rejected, never truncated.
    let data;
    try { data = buildFcmData({ event: hs.event, alertId, timestamp: hs.timestamp, signature: hs.signature, frame }); }
    catch (e) {
      if (e instanceof PayloadTooLargeError) {
        dedupe.commit(key); // it will never fit; retries would fail identically
        stats.frameRejected++; logger.error('alert_too_large_for_fcm', { alert_id: alertId, subscriber: sub.id, size: e.size });
        return 'payload_too_large';
      }
      dedupe.abort(key); throw e;
    }

    // 6. Relay to every live device of this subscriber.
    const devices = registry.liveDevices(sub);
    if (devices.length === 0) { dedupe.abort(key); logger.warn('no_devices', { alert_id: alertId, subscriber: sub.id }); return 'no_devices'; }
    const results = await Promise.all(devices.map((d) => pushWithRetry(sub, d, data, alertId)));
    const delivered = results.filter((r) => r === 'ok').length;
    const retryable = results.some((r) => r === 'transient' || r === 'config');
    if (delivered > 0 || !retryable) dedupe.commit(key); else dedupe.abort(key); // total transient failure: let SeaTracePro's retry deliver
    if (delivered > 0) { stats.relayed++; logger.info('alert_relayed', { alert_id: alertId, subscriber: sub.id, delivered, devices: devices.length }); return 'relayed'; }
    return 'push_failed';
  }

  async function pushWithRetry(sub, device, data, alertId) {
    for (let attempt = 0; ; attempt++) {
      try { await sender.send(device.token, data); return 'ok'; }
      catch (e) {
        const kind = e && e.kind ? e.kind : 'transient';
        if (kind === 'invalid_token') { registry.markDead(sub, device); stats.pushFailures++; logger.warn('device_token_invalid', { subscriber: sub.id, device: device.id }); return 'invalid_token'; }
        if (kind === 'transient' && attempt < config.retryDelaysMs.length) { await sleep(config.retryDelaysMs[attempt]); continue; }
        stats.pushFailures++;
        logger.error('push_failed', { alert_id: alertId, subscriber: sub.id, device: device.id, kind, code: e && e.code });
        return kind;
      }
    }
  }

  function rejectFrame(reason, hs, sub) {
    stats.frameRejected++;
    logger.warn('frame_rejected', { reason, alert_id_hdr: hs.alertId, subscriber: sub ? sub.id : undefined });
    return reason;
  }

  return {
    server, stats,
    start: () => new Promise((resolve, reject2) => { server.once('error', reject2); server.listen(config.port, config.host, () => resolve(server.address())); }),
    stop: () => new Promise((resolve) => { server.close(() => resolve()); server.closeAllConnections?.(); }),
  };
}

module.exports = { createGateway, RateLimiter, clientIp };
