'use strict';
const crypto = require('node:crypto');

/** Documented replay window. Never relax this: it is the primary replay control. */
const REPLAY_WINDOW_SECONDS = 300;
const MIN_PLAUSIBLE_EPOCH = 1_577_836_800; // 2020-01-01
const MAX_ALERT_ID_LENGTH = 128;
const TS_FORMAT = /^\d{1,12}(\.\d{1,6})?$/;
const SIG_FORMAT = /^sha256=([0-9a-fA-F]{64})$/;
const ALERT_ID_FORMAT = /^[\x21-\x7e]{1,128}$/; // printable ASCII, no whitespace

/** @returns {{ok: true, ts: number} | {ok: false, reason: string}} */
function checkTimestamp(raw, nowSeconds) {
  if (typeof raw !== 'string' || raw.length === 0) return { ok: false, reason: 'timestamp_missing' };
  if (!TS_FORMAT.test(raw)) return { ok: false, reason: 'timestamp_invalid' };
  const ts = Number(raw);
  if (!Number.isFinite(ts) || ts < MIN_PLAUSIBLE_EPOCH) return { ok: false, reason: 'timestamp_invalid' };
  // Exactly the documented rule: reject if |now - ts| > 300 (both directions).
  if (Math.abs(nowSeconds - ts) > REPLAY_WINDOW_SECONDS) return { ok: false, reason: 'timestamp_outside_replay_window' };
  return { ok: true, ts };
}

/** Cheap checks done on the HTTP Upgrade request, before any frame is accepted. Reveals nothing about secrets. */
function validateHandshakeHeaders(headers, nowSeconds) {
  const event = headers['x-seatrace-event'];
  const alertId = headers['x-seatrace-alert-id'];
  const signature = headers['x-seatrace-signature'];
  if (event !== 'vessel_alert') return { ok: false, reason: event ? 'wrong_event' : 'missing_event' };
  if (typeof alertId !== 'string' || !ALERT_ID_FORMAT.test(alertId)) return { ok: false, reason: 'bad_alert_id' };
  if (typeof signature !== 'string' || !SIG_FORMAT.test(signature)) return { ok: false, reason: 'bad_signature_format' };
  const ts = checkTimestamp(headers['x-seatrace-timestamp'], nowSeconds);
  if (!ts.ok) return ts;
  return { ok: true, event, alertId, timestamp: headers['x-seatrace-timestamp'], signature };
}

/**
 * HMAC_SHA256(key, timestamp + "." + frame) over the EXACT received bytes - the frame is never parsed,
 * re-serialised or normalised before this check. The key is the secret's UTF-8 text (as in the reference Node snippet).
 */
function computeMac(secret, timestamp, frame) {
  return crypto.createHmac('sha256', secret).update(timestamp, 'utf8').update('.', 'utf8').update(frame).digest();
}

/** Constant-time check of a `sha256=<hex>` header against one secret. */
function verifySignature(secret, timestamp, frame, signatureHeader) {
  const m = SIG_FORMAT.exec(signatureHeader || '');
  if (!m) return false;
  const got = Buffer.from(m[1], 'hex');
  const expected = computeMac(secret, timestamp, frame);
  return got.length === expected.length && crypto.timingSafeEqual(got, expected);
}

/**
 * The signing key is per user and per vessel, and the body cannot be trusted to say whose it is before it is
 * verified. So every configured secret is tried (cheap HMACs, bounded by the registry size) and the one that
 * verifies identifies the subscriber. No JSON is parsed to make this decision.
 * @returns the matching subscriber or null
 */
function findMatchingSubscriber(subscribers, timestamp, frame, signatureHeader) {
  let match = null;
  for (const sub of subscribers) {            // deliberately no early exit: work does not depend on which key matches
    if (verifySignature(sub.secret, timestamp, frame, signatureHeader) && match === null) match = sub;
  }
  return match;
}

module.exports = {
  REPLAY_WINDOW_SECONDS, MAX_ALERT_ID_LENGTH, checkTimestamp, validateHandshakeHeaders,
  computeMac, verifySignature, findMatchingSubscriber,
};
