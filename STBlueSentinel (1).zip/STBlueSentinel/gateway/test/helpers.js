'use strict';
const WebSocket = require('ws');
const { loadConfig } = require('../src/config');
const { Registry } = require('../src/registry');
const { Dedupe } = require('../src/dedupe');
const { createGateway } = require('../src/server');
const { createLogger } = require('../src/logger');
const { computeMac } = require('../src/verify');

// Dummy credentials. The real BlueSentinel secret must never appear in this repository.
const SECRET_A = 'test-secret-0123456789abcdef-NOT-REAL';
const SECRET_B = 'second-subscriber-secret-9876543210-NOT-REAL';
const TOKEN_A1 = 'fcm-token-A1-' + 'x'.repeat(40);
const TOKEN_A2 = 'fcm-token-A2-' + 'y'.repeat(40);
const TOKEN_B1 = 'fcm-token-B1-' + 'z'.repeat(40);

function registryJson() {
  return { subscribers: [
    { id: 'alpha', secret: SECRET_A, devices: [{ id: 'a1', token: TOKEN_A1 }] },
    { id: 'bravo', secret: SECRET_B, devices: [{ id: 'b1', token: TOKEN_B1 }] },
  ] };
}

function frame(id, extra = {}) {
  return JSON.stringify({
    schema_version: '1.0', source: 'seatracepro', product: 'bluesentinel', event: 'vessel_alert', alert_id: id,
    alert_type: 'danger_zone_entry', severity: 'high', title: 'Entered high-incident area', message: 'MV EXAMPLE entered an area.',
    vessel: { mmsi: 123456789, ship_name: 'MV \u00C5LESUND' }, threat: { state: 'INSIDE', area_label: 'Near Lagos (NGA)' }, ...extra,
  });
}

function mockSender(impl) {
  const s = { calls: [], send: async (token, data) => { s.calls.push({ token, data }); if (impl) return impl(token, data, s.calls.length); } };
  return s;
}

async function startHarness({ registry = registryJson(), sender = mockSender(), env = {}, dedupe = new Dedupe(), now } = {}) {
  const lines = [];
  const config = { ...loadConfig({ HOST: '127.0.0.1', PORT: '0', WS_PATH: '/bluesentinel', ...env }), retryDelaysMs: [5, 5] };
  const gw = createGateway({ config, registry: new Registry(registry, {}), sender, dedupe, logger: createLogger('debug', (l) => lines.push(l)), ...(now ? { now } : {}) });
  const addr = await gw.start();
  const url = `ws://127.0.0.1:${addr.port}${config.wsPath}`;
  return { gw, sender, lines, url, port: addr.port, dedupe, stop: () => gw.stop() };
}

function signedHeaders({ secret = SECRET_A, id, frameText, ageSeconds = 0, ts }) {
  const timestamp = ts ?? String(Math.floor(Date.now() / 1000) - ageSeconds);
  const sig = 'sha256=' + computeMac(secret, timestamp, Buffer.from(frameText)).toString('hex');
  return { 'X-SeaTrace-Event': 'vessel_alert', 'X-SeaTrace-Alert-Id': id, 'X-SeaTrace-Timestamp': timestamp, 'X-SeaTrace-Signature': sig };
}

/** Opens a connection, sends the given messages, resolves when the server closes it (or rejects the handshake). */
function session(url, headers, messages = [], { holdOpen = false } = {}) {
  return new Promise((resolve) => {
    const ws = new WebSocket(url, { headers, followRedirects: false, perMessageDeflate: false });
    ws.on('open', () => { if (!holdOpen) for (const m of messages) ws.send(m.data, { binary: !!m.binary }); });
    ws.on('close', (code, reason) => resolve({ code, reason: reason.toString() }));
    ws.on('unexpected-response', (_q, res) => { res.resume(); resolve({ status: res.statusCode }); });
    ws.on('error', () => {});
    if (holdOpen) ws.on('open', () => resolve({ ws }));
  });
}

/** The normal SeaTracePro behaviour: one correctly signed text frame. */
function deliver(h, { id = 'A1', frameText, secret, ageSeconds, headers = {} } = {}) {
  const text = frameText ?? frame(id);
  return session(h.url, { ...signedHeaders({ secret, id, frameText: text, ageSeconds }), ...headers }, [{ data: text }]);
}

module.exports = { SECRET_A, SECRET_B, TOKEN_A1, TOKEN_A2, TOKEN_B1, registryJson, frame, mockSender, startHarness, signedHeaders, session, deliver };
