'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const { verifySignature } = require('../src/verify');
const { PushError, MAX_PAYLOAD_BYTES } = require('../src/fcm');
const { buildFrame, sign, send } = require('../scripts/simulate-seatrace');
const H = require('./helpers');

/** Each test gets its own gateway on an ephemeral port. */
async function withGateway(opts, fn) {
  const h = await H.startHarness(opts);
  try { await fn(h); } finally { await h.stop(); }
}

test('valid alert: relayed to the subscriber\'s device with the exact frame, headers, 300 s TTL contract', async () => {
  await withGateway({}, async (h) => {
    const text = H.frame('1001');
    const r = await H.session(h.url, H.signedHeaders({ id: '1001', frameText: text }), [{ data: text }]);
    assert.equal(r.code, 1000);
    assert.equal(h.sender.calls.length, 1);
    const { token, data } = h.sender.calls[0];
    assert.equal(token, H.TOKEN_A1);
    assert.equal(data.alert_id, '1001'); assert.equal(data.v, '1'); assert.equal(data.event, 'vessel_alert');
    assert.ok(Buffer.from(data.frame_b64, 'base64').equals(Buffer.from(text)));            // byte-exact, incl. the non-ASCII name
    // What the Android app will do with it: re-verify with its own copy of the secret.
    assert.equal(verifySignature(Buffer.from(H.SECRET_A), data.ts, Buffer.from(data.frame_b64, 'base64'), data.sig), true);
    assert.equal(h.gw.stats.relayed, 1);
  });
});

test('SeaTracePro retry (same alert_id, freshly signed) is not relayed twice', async () => {
  await withGateway({}, async (h) => {
    assert.equal((await H.deliver(h, { id: '2001' })).code, 1000);
    assert.equal((await H.deliver(h, { id: '2001' })).code, 1000);
    assert.equal((await H.deliver(h, { id: '2001' })).code, 1000);
    assert.equal(h.sender.calls.length, 1); assert.equal(h.gw.stats.duplicates, 2);
  });
});

test('replaying a captured valid message inside the window is a duplicate', async () => {
  await withGateway({}, async (h) => {
    const text = H.frame('3001'); const headers = H.signedHeaders({ id: '3001', frameText: text });
    await H.session(h.url, headers, [{ data: text }]); await H.session(h.url, headers, [{ data: text }]);
    assert.equal(h.sender.calls.length, 1);
  });
});

test('swapping the UNSIGNED alert-id header on a replayed frame cannot bypass de-duplication', async () => {
  await withGateway({}, async (h) => {
    const text = H.frame('4001'); const headers = H.signedHeaders({ id: '4001', frameText: text });
    await H.session(h.url, headers, [{ data: text }]);
    const swapped = await H.session(h.url, { ...headers, 'X-SeaTrace-Alert-Id': '4002' }, [{ data: text }]);
    assert.equal(swapped.code, 1008); assert.match(swapped.reason, /alert_id_mismatch/);
    assert.equal(h.sender.calls.length, 1);
  });
});

test('replay window: 299 s accepted; 301 s old or 301 s in the future rejected at the handshake', async () => {
  await withGateway({}, async (h) => {
    assert.equal((await H.deliver(h, { id: '5001', ageSeconds: 299 })).code, 1000);
    assert.equal((await H.deliver(h, { id: '5002', ageSeconds: 301 })).status, 401);
    assert.equal((await H.deliver(h, { id: '5003', ageSeconds: -301 })).status, 401);
    assert.equal(h.sender.calls.length, 1);
  });
});

test('invalid signatures are never relayed', async () => {
  await withGateway({}, async (h) => {
    const text = H.frame('6001');
    const forged = { ...H.signedHeaders({ id: '6001', frameText: text }), 'X-SeaTrace-Signature': 'sha256=' + 'ab'.repeat(32) };
    assert.match((await H.session(h.url, forged, [{ data: text }])).reason, /signature_invalid/);
    const tampered = await H.session(h.url, H.signedHeaders({ id: '6001', frameText: text }), [{ data: text.replace('high', 'low') }]);
    assert.match(tampered.reason, /signature_invalid/);
    assert.match((await H.deliver(h, { id: '6002', secret: 'an-unknown-secret-0123456789abcdef' })).reason, /signature_invalid/);
    assert.equal(h.sender.calls.length, 0);
  });
});

test('missing or wrong headers are refused at the handshake', async () => {
  await withGateway({}, async (h) => {
    const text = H.frame('7001'); const good = H.signedHeaders({ id: '7001', frameText: text });
    for (const drop of ['X-SeaTrace-Event', 'X-SeaTrace-Alert-Id', 'X-SeaTrace-Timestamp', 'X-SeaTrace-Signature']) {
      const headers = { ...good }; delete headers[drop];
      assert.equal((await H.session(h.url, headers, [{ data: text }])).status, 401, drop);
    }
    assert.equal((await H.session(h.url, { ...good, 'X-SeaTrace-Event': 'other' }, [{ data: text }])).status, 401);
    assert.equal(h.sender.calls.length, 0);
  });
});

test('wrong path is 404; /healthz answers; other HTTP is 404', async () => {
  await withGateway({}, async (h) => {
    assert.equal((await H.session(h.url.replace('/bluesentinel', '/elsewhere'), H.signedHeaders({ id: '1', frameText: H.frame('1') }), [])).status, 404);
    const get = (p) => new Promise((resolve) => http.get({ host: '127.0.0.1', port: h.port, path: p }, (res) => { res.resume(); resolve(res.statusCode); }));
    assert.equal(await get('/healthz'), 200); assert.equal(await get('/'), 404); assert.equal(await get('/bluesentinel'), 404);
  });
});

test('binary frames, oversize frames and extra frames are refused', async () => {
  await withGateway({}, async (h) => {
    const text = H.frame('8001'); const headers = H.signedHeaders({ id: '8001', frameText: text });
    assert.equal((await H.session(h.url, headers, [{ data: Buffer.from(text), binary: true }])).code, 1003);
    const big = H.frame('8002', { pad: 'x'.repeat(33 * 1024) });
    assert.equal((await H.session(h.url, H.signedHeaders({ id: '8002', frameText: big }), [{ data: big }])).code, 1009);
    assert.equal(h.sender.calls.length, 0);
    // Only the first frame on a connection counts.
    const t2 = H.frame('8003'); const hd2 = H.signedHeaders({ id: '8003', frameText: t2 });
    await H.session(h.url, hd2, [{ data: t2 }, { data: H.frame('8004') }]);
    assert.deepEqual(h.sender.calls.map((c) => c.data.alert_id), ['8003']);
  });
});

test('a connection that never sends its frame is closed', async () => {
  await withGateway({ env: { FRAME_TIMEOUT_MS: '150' } }, async (h) => {
    const r = await new Promise((resolve) => {
      H.session(h.url, H.signedHeaders({ id: '9001', frameText: H.frame('9001') }), [], { holdOpen: true }).then(({ ws }) => ws.on('close', (code) => resolve(code)));
    });
    assert.equal(r, 1008);
  });
});

test('signed-but-bad bodies are rejected only AFTER the signature check passed', async () => {
  await withGateway({}, async (h) => {
    const cases = {
      'not json': '{not json', 'array': '[1,2]', 'null': 'null',
      'schema 2.0': H.frame('A1').replace('"1.0"', '"2.0"'), 'wrong product': H.frame('A2').replace('bluesentinel', 'other'),
      'wrong event': H.frame('A3').replace('"event":"vessel_alert"', '"event":"x"'),
    };
    for (const [name, text] of Object.entries(cases)) {
      const id = text.match(/"alert_id":"([^"]+)"/)?.[1] ?? 'ZZ';
      const r = await H.session(h.url, H.signedHeaders({ id, frameText: text }), [{ data: text }]);
      assert.equal(r.code, 1008, name);
    }
    const bad = Buffer.from([0x7b, 0xc3, 0x28, 0x7d]);   // valid MAC, invalid UTF-8
    const hd = H.signedHeaders({ id: 'ZZ', frameText: bad.toString('latin1') });
    const { computeMac } = require('../src/verify');
    hd['X-SeaTrace-Signature'] = 'sha256=' + computeMac(H.SECRET_A, hd['X-SeaTrace-Timestamp'], bad).toString('hex');
    // ws itself refuses invalid UTF-8 in a text frame (close 1007); if it ever let it through, our strict decoder would reject it (1008).
    assert.ok([1007, 1008].includes((await H.session(h.url, hd, [{ data: bad, binary: false }])).code));
    assert.equal(h.sender.calls.length, 0);
  });
});

test('notification_test alerts are relayed (the app labels them as tests)', async () => {
  await withGateway({}, async (h) => {
    const text = buildFrame({ type: 'notification_test', severity: 'high', id: 'TEST1' });
    assert.equal((await H.session(h.url, H.signedHeaders({ id: 'TEST1', frameText: text }), [{ data: text }])).code, 1000);
    const relayed = JSON.parse(Buffer.from(h.sender.calls[0].data.frame_b64, 'base64').toString());
    assert.equal(relayed.test, true); assert.equal(relayed.alert_type, 'notification_test');
  });
});

test('alerts too big for FCM are rejected - not truncated - and not retried forever', async () => {
  await withGateway({}, async (h) => {
    const text = H.frame('B1', { pad: 'p'.repeat(3500) });     // valid and < 32 KB, but > 4 KB once base64-encoded
    assert.ok(Buffer.byteLength(text) < 32 * 1024);
    assert.match((await H.deliver(h, { id: 'B1', frameText: text })).reason, /payload_too_large/);
    assert.equal(h.sender.calls.length, 0);
    assert.ok(h.lines.some((l) => l.includes('alert_too_large_for_fcm')));
    assert.equal((await H.deliver(h, { id: 'B1', frameText: text })).code, 1000);   // committed: SeaTracePro's retry is a harmless duplicate
    assert.ok(MAX_PAYLOAD_BYTES === 4096);
  });
});

test('transient FCM errors are retried within the connection', async () => {
  const sender = H.mockSender((_t, _d, n) => { if (n <= 2) throw new PushError('transient', 'messaging/server-unavailable'); });
  await withGateway({ sender }, async (h) => {
    assert.equal((await H.deliver(h, { id: 'C1' })).code, 1000);
    assert.equal(sender.calls.length, 3);
  });
});

test('total FCM failure leaves the alert retryable (SeaTracePro retries re-send it)', async () => {
  let failing = true;
  const sender = H.mockSender(() => { if (failing) throw new PushError('transient', 'messaging/internal-error'); });
  await withGateway({ sender }, async (h) => {
    const first = await H.deliver(h, { id: 'D1' });
    assert.equal(first.code, 1008); assert.match(first.reason, /push_failed/);
    failing = false;
    assert.equal((await H.deliver(h, { id: 'D1' })).code, 1000);            // not wrongly treated as a duplicate
    assert.equal((await H.deliver(h, { id: 'D1' })).code, 1000);
    assert.equal(sender.calls.filter((c) => c.data.alert_id === 'D1').length, 4);   // 3 failed attempts + 1 success, then dedupe
  });
});

test('an operator configuration error (bad Firebase credentials) also stays retryable and is logged as an error', async () => {
  const sender = H.mockSender(() => { throw new PushError('config', 'app/invalid-credential'); });
  await withGateway({ sender }, async (h) => {
    assert.equal((await H.deliver(h, { id: 'E1' })).code, 1008);
    assert.ok(h.lines.some((l) => l.includes('"level":"error"') && l.includes('push_failed')));
    assert.equal(h.dedupe.size, 0);
  });
});

test('a dead FCM token is removed from rotation and reported', async () => {
  const sender = H.mockSender(() => { throw new PushError('invalid_token', 'messaging/registration-token-not-registered'); });
  await withGateway({ sender }, async (h) => {
    await H.deliver(h, { id: 'F1' });
    assert.ok(h.lines.some((l) => l.includes('device_token_invalid')));
    const r = await H.deliver(h, { id: 'F2' });
    assert.match(r.reason, /no_devices/); assert.equal(sender.calls.length, 1);
  });
});

test('several devices: all live ones receive the alert; one dead device does not block the rest', async () => {
  const reg = H.registryJson(); reg.subscribers[0].devices.push({ id: 'a2', token: H.TOKEN_A2 });
  const sender = H.mockSender((token) => { if (token === H.TOKEN_A1) throw new PushError('invalid_token', 'x'); });
  await withGateway({ registry: reg, sender }, async (h) => {
    assert.equal((await H.deliver(h, { id: 'G1' })).code, 1000);
    assert.deepEqual(sender.calls.map((c) => c.token).sort(), [H.TOKEN_A1, H.TOKEN_A2].sort());
    assert.equal(h.dedupe.begin('alpha:G1'), 'duplicate');
  });
});

test('alerts are routed by which secret verifies: another subscriber\'s phones never receive them', async () => {
  await withGateway({}, async (h) => {
    assert.equal((await H.deliver(h, { id: 'H1', secret: H.SECRET_B })).code, 1000);
    assert.deepEqual(h.sender.calls.map((c) => c.token), [H.TOKEN_B1]);
    assert.equal((await H.deliver(h, { id: 'H2', secret: H.SECRET_A })).code, 1000);
    assert.deepEqual(h.sender.calls.map((c) => c.token), [H.TOKEN_B1, H.TOKEN_A1]);
  });
});

test('the same alert_id for two different subscribers is two alerts', async () => {
  await withGateway({}, async (h) => {
    await H.deliver(h, { id: 'SAME', secret: H.SECRET_A }); await H.deliver(h, { id: 'SAME', secret: H.SECRET_B });
    assert.equal(h.sender.calls.length, 2);
  });
});

test('simultaneous identical deliveries produce exactly one push (in-flight guard)', async () => {
  const sender = H.mockSender(() => new Promise((r) => setTimeout(r, 120)));
  await withGateway({ sender }, async (h) => {
    const text = H.frame('J1'); const hd = H.signedHeaders({ id: 'J1', frameText: text });
    await Promise.all([1, 2, 3].map(() => H.session(h.url, hd, [{ data: text }])));
    assert.equal(sender.calls.length, 1);
  });
});

test('per-IP rate limit and connection cap', async () => {
  await withGateway({ env: { RATE_PER_IP_PER_MINUTE: '3' } }, async (h) => {
    const codes = [];
    for (let i = 0; i < 5; i++) codes.push((await H.session(h.url, {}, [])).status);   // handshakes fail validation (401) but still count
    assert.deepEqual(codes.slice(0, 3), [401, 401, 401]); assert.equal(codes[3], 429);
  });
  await withGateway({ env: { MAX_CONNECTIONS: '1', FRAME_TIMEOUT_MS: '5000' } }, async (h) => {
    const text = H.frame('K1'); const hd = H.signedHeaders({ id: 'K1', frameText: text });
    const { ws } = await H.session(h.url, hd, [], { holdOpen: true });
    assert.equal((await H.session(h.url, H.signedHeaders({ id: 'K2', frameText: text }), [])).status, 503);
    ws.terminate();
  });
});

test('logs never contain secrets, signatures, FCM tokens or frame contents', async () => {
  await withGateway({}, async (h) => {
    await H.deliver(h, { id: 'L1' });
    await H.deliver(h, { id: 'L2', secret: 'an-unknown-secret-0123456789abcdef' });
    await H.deliver(h, { id: 'L3', ageSeconds: 9999 });
    const all = h.lines.join('\n');
    for (const leak of [H.SECRET_A, H.SECRET_B, H.TOKEN_A1, H.TOKEN_B1, 'sha256=', 'ALESUND', 'Entered high-incident', Buffer.from(H.frame('L1')).toString('base64').slice(0, 24)])
      assert.ok(!all.includes(leak), `log leaked: ${leak}`);
    assert.ok(all.includes('alert_relayed'));
  });
});

test('the SeaTracePro simulator speaks the documented protocol', async () => {
  await withGateway({}, async (h) => {
    const id = 'SIM1'; const text = buildFrame({ type: 'danger_zone_entry', severity: 'critical', id });
    const r = await send({ url: h.url, secret: H.SECRET_A, frame: text, alertId: id });
    assert.equal(r.code, 1000); assert.equal(h.sender.calls.length, 1);
    assert.equal(sign('k', '1', 'f'), 'sha256=' + require('node:crypto').createHmac('sha256', 'k').update('1.f').digest('hex'));
    const stale = await send({ url: h.url, secret: H.SECRET_A, frame: text, alertId: 'SIM2', ageSeconds: 400 });
    assert.equal(stale.status, 401);
  });
});
