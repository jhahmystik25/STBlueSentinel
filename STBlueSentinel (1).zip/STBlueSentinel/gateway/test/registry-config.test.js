'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { parseRegistry, Registry } = require('../src/registry');
const { loadConfig } = require('../src/config');
const { createLogger } = require('../src/logger');

const tok = (c) => 'fcm-token-' + c.repeat(40);
const sub = (o = {}) => ({ id: 'alpha', secret: 'a'.repeat(32), devices: [{ id: 'd1', token: tok('x') }], ...o });

test('registry: valid file; secrets can come from the environment instead of the file', () => {
  const r = parseRegistry({ subscribers: [sub(), sub({ id: 'bravo', secret: undefined, secretEnv: 'BS_B' })] }, { BS_B: 'b'.repeat(32) });
  assert.equal(r.subscribers.length, 2); assert.ok(Buffer.isBuffer(r.subscribers[1].secret)); assert.equal(r.subscribers[1].secret.toString(), 'b'.repeat(32));
});

test('registry: rejects bad input', () => {
  const bad = (subs, env = {}) => assert.throws(() => parseRegistry({ subscribers: subs }, env));
  bad([]); bad([sub({ id: 'bad id!' })]); bad([sub(), sub()]);                                 // empty, bad id, duplicate id
  bad([sub({ secret: 'short' })]); bad([sub({ secret: 'has space in it, long enough.' })]);   // secret policy
  bad([sub({ secret: undefined, secretEnv: 'MISSING' })]);                                     // env var not exported
  bad([sub(), sub({ id: 'bravo' })]);                                                         // two subscribers sharing a secret => owner ambiguous
  bad([sub({ devices: [{ id: 'd', token: 'short' }] })]); bad([sub({ devices: [{ id: 'bad id', token: tok('x') }] })]);
});

test('registry: a subscriber may exist with no devices yet', () => assert.equal(parseRegistry({ subscribers: [sub({ devices: [] })] }).subscribers[0].devices.length, 0));

test('registry: dead devices are skipped until reload', () => {
  const reg = new Registry({ subscribers: [sub({ devices: [{ id: 'd1', token: tok('x') }, { id: 'd2', token: tok('y') }] })] }, {});
  const s = reg.subscribers[0]; reg.markDead(s, s.devices[0]);
  assert.deepEqual(reg.liveDevices(s).map((d) => d.id), ['d2']);
  reg.reload(); assert.equal(reg.liveDevices(reg.subscribers[0]).length, 2);
});

test('config: loopback plaintext is allowed (behind a TLS proxy); public plaintext is refused', () => {
  assert.equal(loadConfig({}).host, '127.0.0.1');
  assert.throws(() => loadConfig({ HOST: '0.0.0.0' }), /wss/);
  assert.throws(() => loadConfig({ HOST: '0.0.0.0', ALLOW_PLAINTEXT_BEHIND_PROXY: 'true' }), /wss/);   // needs TRUST_PROXY too
  assert.doesNotThrow(() => loadConfig({ HOST: '10.0.0.5', ALLOW_PLAINTEXT_BEHIND_PROXY: 'true', TRUST_PROXY: 'true' }));
  assert.doesNotThrow(() => loadConfig({ HOST: '0.0.0.0', TLS_CERT_FILE: '/c.pem', TLS_KEY_FILE: '/k.pem' }));
});

test('config: validation', () => {
  assert.throws(() => loadConfig({ TLS_CERT_FILE: '/c.pem' }), /together/);
  assert.throws(() => loadConfig({ WS_PATH: '/a?token=1' }), /WS_PATH/);
  assert.throws(() => loadConfig({ PORT: '99999' }), /PORT/); assert.throws(() => loadConfig({ PORT: 'abc' }), /PORT/);
  const c = loadConfig({}); assert.equal(c.maxFrameBytes, 32768); assert.equal(c.wsPath, '/bluesentinel'); assert.equal(c.fcmDryRun, false);
});

test('logger never writes sensitive-looking fields', () => {
  const out = []; const log = createLogger('debug', (l) => out.push(l));
  log.info('x', { alert_id: '1', secret: 'S', fcm_token: 'T', signature: 'G', frame: 'F', payload: 'P', Authorization: 'A', subscriber: 'alpha' });
  const line = out.join('');
  for (const leak of ['"S"', '"T"', '"G"', '"F"', '"P"', '"A"']) assert.ok(!line.includes(leak), leak);
  assert.ok(line.includes('"alert_id":"1"') && line.includes('"subscriber":"alpha"'));
});
