'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { buildFcmData, buildMessage, payloadSize, maxFrameBytes, PayloadTooLargeError, PushError, classifyFirebaseError, createFirebaseSender, MAX_PAYLOAD_BYTES, TTL_MS } = require('../src/fcm');

const base = { event: 'vessel_alert', alertId: '12345', timestamp: '1790000000', signature: 'sha256=' + 'a'.repeat(64) };

test('contract constants', () => { assert.equal(MAX_PAYLOAD_BYTES, 4096); assert.equal(TTL_MS, 300_000); });

test('data carries the exact frame as base64 plus the verbatim headers - and nothing else', () => {
  const frame = Buffer.from('{"alert_id":"12345","name":"MV \u00C5LESUND"}', 'utf8');
  const d = buildFcmData({ ...base, frame });
  assert.deepEqual(Object.keys(d).sort(), ['alert_id', 'event', 'frame_b64', 'sig', 'ts', 'v']);
  assert.equal(d.v, '1'); assert.equal(d.event, 'vessel_alert'); assert.equal(d.alert_id, '12345'); assert.equal(d.ts, '1790000000'); assert.equal(d.sig, base.signature);
  assert.ok(Buffer.from(d.frame_b64, 'base64').equals(frame));       // byte-exact round trip
  assert.match(d.frame_b64, /^[A-Za-z0-9+/]+={0,2}$/);               // standard alphabet, no line breaks
});

test('every data value is a string (an FCM requirement) and no secret-like field exists', () => {
  const d = buildFcmData({ ...base, frame: Buffer.from('{}') });
  for (const v of Object.values(d)) assert.equal(typeof v, 'string');
  for (const k of Object.keys(d)) assert.doesNotMatch(k, /secret|key|password|credential/i);
});

test('message is data-only, high priority, 300 s TTL, no collapse key', () => {
  const m = buildMessage('tok', buildFcmData({ ...base, frame: Buffer.from('{}') }));
  assert.equal(m.token, 'tok'); assert.equal(m.android.priority, 'high'); assert.equal(m.android.ttl, 300_000);
  assert.equal(m.notification, undefined); assert.equal(m.android.notification, undefined);
  assert.equal(m.android.collapseKey, undefined); assert.equal(m.android.collapse_key, undefined); assert.equal(m.apns, undefined);
});

test('size rule: exactly at the limit is sent, one byte over is rejected - never truncated', () => {
  const sizeFor = (n) => payloadSize(buildFcmDataUnchecked(n));
  function buildFcmDataUnchecked(n) { return { v: '1', event: base.event, alert_id: base.alertId, ts: base.timestamp, sig: base.signature, frame_b64: Buffer.alloc(n, 0x61).toString('base64') }; }
  let n = 1; while (sizeFor(n + 3) <= MAX_PAYLOAD_BYTES) n += 3;     // largest frame (multiple of 3 => no padding) that still fits
  const fits = buildFcmData({ ...base, frame: Buffer.alloc(n, 0x61) });
  assert.ok(payloadSize(fits) <= MAX_PAYLOAD_BYTES);
  assert.throws(() => buildFcmData({ ...base, frame: Buffer.alloc(n + 3, 0x61) }), PayloadTooLargeError);
  assert.throws(() => buildFcmData({ ...base, frame: Buffer.alloc(10_000, 0x61) }), (e) => e instanceof PayloadTooLargeError && e.size > MAX_PAYLOAD_BYTES);
});

test('documented capacity is about 2.9 KB of raw frame', () => {
  const cap = maxFrameBytes(); assert.ok(cap > 2800 && cap < 3100, `cap=${cap}`);
  assert.doesNotThrow(() => buildFcmData({ ...base, frame: Buffer.alloc(cap - 6) }));
});

test('payloadSize counts UTF-8 bytes of keys and values like the Android client', () => {
  assert.equal(payloadSize({ ab: 'cd' }), 4); assert.equal(payloadSize({ k: '\u00E9' }), 3);
});

test('Firebase error classification', () => {
  const k = (code) => classifyFirebaseError({ code }).kind;
  assert.equal(k('messaging/registration-token-not-registered'), 'invalid_token'); assert.equal(k('messaging/invalid-registration-token'), 'invalid_token');
  for (const c of ['messaging/server-unavailable', 'messaging/internal-error', 'messaging/message-rate-exceeded', 'app/network-error']) assert.equal(k(c), 'transient', c);
  for (const c of ['messaging/authentication-error', 'app/invalid-credential', 'messaging/third-party-auth-error']) assert.equal(k(c), 'config', c);
  assert.equal(k('messaging/invalid-argument'), 'permanent'); assert.equal(k('messaging/payload-size-limit-exceeded'), 'permanent');
  assert.equal(classifyFirebaseError(new Error('socket hang up')).kind, 'transient');
});

test('Firebase sender passes the contract message and the dry-run flag; classifies failures', async () => {
  const sent = [];
  let fail = null;
  const admin = {
    credential: { applicationDefault: () => 'cred', cert: (j) => ({ cert: j }) },
    initializeApp: (opts, name) => ({ opts, name }),
    messaging: () => ({ send: async (msg, dry) => { sent.push({ msg, dry }); if (fail) throw fail; return 'id'; } }),
  };
  const s = createFirebaseSender({ adminModule: admin, dryRun: true });
  const data = buildFcmData({ ...base, frame: Buffer.from('{}') });
  await s.send('tok', data);
  assert.equal(sent[0].dry, true); assert.deepEqual(sent[0].msg, buildMessage('tok', data));
  fail = Object.assign(new Error('x'), { code: 'messaging/registration-token-not-registered' });
  await assert.rejects(s.send('tok', data), (e) => e instanceof PushError && e.kind === 'invalid_token');
});
