'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { Dedupe } = require('../src/dedupe');

test('new -> in_flight -> duplicate after commit', () => {
  const d = new Dedupe();
  assert.equal(d.begin('k'), 'new'); assert.equal(d.begin('k'), 'in_flight');
  d.commit('k'); assert.equal(d.begin('k'), 'duplicate');
});

test('abort lets a later retry through (transient push failure)', () => {
  const d = new Dedupe();
  d.begin('k'); d.abort('k'); assert.equal(d.begin('k'), 'new');
});

test('abort never undoes a committed delivery', () => {
  const d = new Dedupe(); d.begin('k'); d.commit('k'); d.abort('k'); assert.equal(d.begin('k'), 'duplicate');
});

test('entries expire after the TTL (3 h by default covers the 2 h retry horizon)', () => {
  let t = 0; const d = new Dedupe({ now: () => t });
  assert.equal(new Dedupe().ttlMs, 3 * 60 * 60 * 1000);
  d.begin('k'); d.commit('k');
  t = 3 * 60 * 60 * 1000 - 1; assert.equal(d.begin('k'), 'duplicate');
  t = 3 * 60 * 60 * 1000 + 10; assert.equal(d.begin('k'), 'new');
});

test('distinct keys are independent', () => {
  const d = new Dedupe(); assert.equal(d.begin('a:1'), 'new'); assert.equal(d.begin('b:1'), 'new'); assert.equal(d.begin('a:2'), 'new');
});

test('memory is bounded: oldest entries are evicted at capacity', () => {
  const d = new Dedupe({ maxEntries: 3 });
  for (const k of ['1', '2', '3']) { d.begin(k); d.commit(k); }
  d.begin('4'); assert.equal(d.size, 3); assert.equal(d.begin('1'), 'new');
});
