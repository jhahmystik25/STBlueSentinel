'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { computeMac, verifySignature, checkTimestamp, validateHandshakeHeaders, findMatchingSubscriber, REPLAY_WINDOW_SECONDS } = require('../src/verify');

// Same vector as the Android tests (SignatureVerifierTest/TestVectors). It was computed by Python's hmac module and by the
// reference Node snippet from the BlueSentinel documentation, and is asserted by the Kotlin implementation: three-way agreement.
const SECRET = 'test-secret-0123456789abcdef-NOT-REAL';
const TS = '1790000000';
const FRAME = fs.readFileSync(path.join(__dirname, 'vector-frame.json'));
const EXPECTED = '1369db11cbb94d59804218812b9c8669a8fd25a1aa10e702f5980e84198b7f84';

/** Verbatim from the SeaTracePro developer reference, with Date.now() injected. */
function docVerify(headers, frameText, key, nowSec) {
  const ts = headers['x-seatrace-timestamp'];
  if (Math.abs(nowSec - Number(ts)) > 300) return false;
  const mac = crypto.createHmac('sha256', key).update(ts + '.' + frameText).digest('hex');
  const got = (headers['x-seatrace-signature'] || '').replace('sha256=', '');
  return got.length === mac.length && crypto.timingSafeEqual(Buffer.from(got), Buffer.from(mac));
}

test('known secret + timestamp + exact frame produces the cross-checked signature', () => {
  assert.equal(computeMac(SECRET, TS, FRAME).toString('hex'), EXPECTED);
});

test('agrees with the documentation reference verifier on valid, tampered and expired input', () => {
  const headers = { 'x-seatrace-timestamp': TS, 'x-seatrace-signature': 'sha256=' + EXPECTED };
  const text = FRAME.toString('utf8');
  for (const [name, h, t, now] of [
    ['valid', headers, text, 1790000010], ['tampered frame', headers, text.replace('high', 'low'), 1790000010],
    ['expired', headers, text, 1790000301], ['wrong sig', { ...headers, 'x-seatrace-signature': 'sha256=' + '0'.repeat(64) }, text, 1790000010],
  ]) {
    const ours = checkTimestamp(h['x-seatrace-timestamp'], now).ok && verifySignature(SECRET, TS, Buffer.from(t), h['x-seatrace-signature']);
    assert.equal(ours, docVerify(h, t, SECRET, now), name);
  }
});

test('modified frame, modified timestamp and wrong secret are rejected', () => {
  const sig = 'sha256=' + EXPECTED;
  assert.equal(verifySignature(SECRET, TS, FRAME, sig), true);
  assert.equal(verifySignature(SECRET, TS, Buffer.from(FRAME.toString().replace('high', 'low')), sig), false);
  assert.equal(verifySignature(SECRET, '1790000001', FRAME, sig), false);
  assert.equal(verifySignature('another-secret-value-0123456789', TS, FRAME, sig), false);
});

test('verification is over exact bytes: reformatted-but-equivalent JSON fails', () => {
  const pretty = Buffer.from(JSON.stringify(JSON.parse(FRAME.toString()), null, 2));
  assert.equal(verifySignature(SECRET, TS, pretty, 'sha256=' + EXPECTED), false);
});

test('non-UTF-8 bytes are signed and verified byte-for-byte (no lossy string round trip)', () => {
  const bytes = Buffer.from([0x7b, 0xc3, 0x28, 0x7d]);
  const sig = 'sha256=' + computeMac(SECRET, TS, bytes).toString('hex');
  assert.equal(verifySignature(SECRET, TS, bytes, sig), true);
});

test('malformed signature headers are rejected without throwing', () => {
  for (const bad of [undefined, null, '', 'sha256=', 'sha256=abc', 'sha1=' + EXPECTED, 'SHA256=' + EXPECTED, EXPECTED, 'sha256=' + 'z'.repeat(64), 'sha256=' + EXPECTED + '00', ' sha256=' + EXPECTED])
    assert.equal(verifySignature(SECRET, TS, FRAME, bad), false, String(bad));
});

test('upper-case hex is the same MAC', () => assert.equal(verifySignature(SECRET, TS, FRAME, 'sha256=' + EXPECTED.toUpperCase()), true));

test('replay window is exactly 300 seconds in both directions', () => {
  assert.equal(REPLAY_WINDOW_SECONDS, 300);
  const now = 1790000000;
  assert.equal(checkTimestamp(String(now - 300), now).ok, true);
  assert.equal(checkTimestamp(String(now - 301), now).reason, 'timestamp_outside_replay_window');
  assert.equal(checkTimestamp(String(now + 300), now).ok, true);
  assert.equal(checkTimestamp(String(now + 301), now).reason, 'timestamp_outside_replay_window');
});

test('missing / malformed / implausible timestamps are rejected', () => {
  const now = 1790000000;
  assert.equal(checkTimestamp(undefined, now).reason, 'timestamp_missing');
  assert.equal(checkTimestamp('', now).reason, 'timestamp_missing');
  for (const bad of ['abc', '-5', '1790000000x', ' 1790000000', '1.79e9', '0', '12345', '99999999999999', 'NaN', '1790000000.', '0x10'])
    assert.equal(checkTimestamp(bad, now).reason, 'timestamp_invalid', bad);
  assert.equal(checkTimestamp('1789999999.5', now).ok, true); // reference verifiers parse floats
});

test('handshake header validation', () => {
  const now = 1790000000;
  const good = { 'x-seatrace-event': 'vessel_alert', 'x-seatrace-alert-id': '12345', 'x-seatrace-timestamp': String(now), 'x-seatrace-signature': 'sha256=' + EXPECTED };
  assert.equal(validateHandshakeHeaders(good, now).ok, true);
  const bad = (patch) => validateHandshakeHeaders({ ...good, ...patch }, now);
  assert.equal(bad({ 'x-seatrace-event': undefined }).reason, 'missing_event');
  assert.equal(bad({ 'x-seatrace-event': 'other' }).reason, 'wrong_event');
  assert.equal(bad({ 'x-seatrace-alert-id': undefined }).reason, 'bad_alert_id');
  assert.equal(bad({ 'x-seatrace-alert-id': 'has space' }).reason, 'bad_alert_id');
  assert.equal(bad({ 'x-seatrace-alert-id': 'a'.repeat(129) }).reason, 'bad_alert_id');
  assert.equal(bad({ 'x-seatrace-signature': 'sha256=short' }).reason, 'bad_signature_format');
  assert.equal(bad({ 'x-seatrace-timestamp': String(now - 1000) }).reason, 'timestamp_outside_replay_window');
  assert.equal(bad({ 'x-seatrace-alert-id': '1, 2' }).reason, 'bad_alert_id'); // duplicated header folded by Node
});

test('findMatchingSubscriber identifies the owner by whichever secret verifies - without parsing the frame', () => {
  const subs = [{ id: 'a', secret: Buffer.from('aaaaaaaaaaaaaaaaaaaa') }, { id: 'b', secret: Buffer.from(SECRET) }, { id: 'c', secret: Buffer.from('cccccccccccccccccccc') }];
  assert.equal(findMatchingSubscriber(subs, TS, FRAME, 'sha256=' + EXPECTED).id, 'b');
  assert.equal(findMatchingSubscriber(subs, TS, FRAME, 'sha256=' + '0'.repeat(64)), null);
  assert.equal(findMatchingSubscriber([], TS, FRAME, 'sha256=' + EXPECTED), null);
});
