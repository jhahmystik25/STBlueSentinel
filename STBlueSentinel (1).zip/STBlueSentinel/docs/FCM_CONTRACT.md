# Gateway → STBlueSentinel FCM contract (version 1)

The **receiver gateway** is the only component that talks to SeaTracePro. It forwards each alert to the
phone as an FCM **data message** following the rules below. The Android app re-verifies every message
itself; it never trusts a push merely because it arrived.

```
SeaTracePro --WSS--> Gateway (verify HMAC, 300 s window, dedupe) --FCM--> STBlueSentinel (verify again, dedupe, store, notify)
```

## Required rules

| # | Rule | Why |
|---|------|-----|
| 1 | Send the **exact original WebSocket text frame**, UTF-8 bytes, **standard base64** (RFC 4648 §4, padded, no line breaks) in `frame_b64`. | The HMAC covers the exact bytes. No parsing, re-serialising, trimming or normalising anywhere on the path. |
| 2 | Send the three header values **verbatim as strings**: `event`, `alert_id`, `ts`, plus `sig` (the full `sha256=<hex>`). | The app needs them to recompute `HMAC(secret, ts + "." + frame)`. |
| 3 | **Never** send the signing secret, any key material, or `BS_WS_MASTER_SECRET` in FCM. | The secret stays on the gateway and, for end-to-end verification, in the phone's Keystore. |
| 4 | If the serialized data payload (sum of key + value UTF-8 bytes) would exceed **4096 bytes**, **do not send**. Log `alert_id` and size; do not truncate, compress, split or re-encode. | A modified frame cannot verify; truncation would silently destroy security. |
| 5 | **TTL = 300 seconds** (`android.ttl: "300s"`). | Live security alerts must not be delivered long after they stop being relevant; aligns with the gateway's 300 s freshness window. |
| 6 | **Priority = high**, **data-only** (no `notification` block), **no `collapse_key`**. | High priority lets FCM wake a dozing device. A `notification` block would be shown by the system tray and bypass app verification/storage. Collapsing would drop distinct alerts. |

## Message shape

```json
{
  "message": {
    "token": "<device FCM token>",
    "android": { "priority": "high", "ttl": "300s" },
    "data": {
      "v": "1",
      "event": "vessel_alert",
      "alert_id": "12345",
      "ts": "1790000000",
      "sig": "sha256=1369db11…",
      "frame_b64": "eyJzY2hlbWFfdmVyc2lvbiI6IjEuMCIs…"
    }
  }
}
```

Practical size note: base64 inflates the frame by 4/3, and the keys and header values add roughly 150 bytes,
so the largest raw frame that fits is about **2.9 KB**. Typical alerts are ~1.5 KB.

## Consequences of the 5-minute TTL (be aware)

* If a phone is offline or unreachable for more than 5 minutes, FCM discards the alert and the phone **never receives it**.
  This is deliberate: an old live alert must not be presented as live. The alert remains visible in SeaTracePro.
* Android-side classification remains as defense in depth: a validly signed alert whose signing time is more than
  15 minutes old is stored as `STALE` and never notifies; more than 24 hours old, or more than 60 s in the future, is rejected.
* A future "catch-up" feature (the app asking the gateway for alerts missed while offline) would be the way to
  recover missed alerts as clearly labelled history. It is not part of V1.

## What the app does with it

`FcmEnvelopeParser` → `AlertVerifier` (headers → timestamp → HMAC on the exact bytes → JSON → schema) →
`alerts` table with unique `alert_id` (duplicate = no row, no notification) → notification **only** if the alert is
`VERIFIED` (live) and the user's preferences allow it.
