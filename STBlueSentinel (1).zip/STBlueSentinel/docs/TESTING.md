# Testing STBlueSentinel

Four layers, from fastest to most realistic. Run the first two on every change; run the last two before a release.

| Layer | What it proves | Where it runs | Command |
|-------|----------------|---------------|---------|
| **Pure JVM unit tests** | HMAC (exact-frame, constant-time, tamper/forgery), timestamp policy (live ≤15 min, stale, future, >24 h), FCM contract parsing (base64 exactness, 4 KB cap), notification policy & wording, URL validation, status logic, filters, formatting, secret policy, verifier pipeline, processor (dedupe, stale never notifies) | JVM | `./gradlew testDebugUnitTest` |
| **Source-hygiene scan** (`SourceHygieneTest`) | No hard-coded 64-hex secret, no custom TLS trust/hostname verifier, no cleartext, `ws://` only inside the validator's rejection text, manifest permissions == {INTERNET, POST_NOTIFICATIONS}, no foreground service, backup off, service unexported, no secrets in logs/BuildConfig, no ad/tracking SDKs | JVM | included above |
| **Robolectric tests** | Room DAO (unique `alert_id`, atomic dedupe, counts, read-tracking, bounded audit log), entity mapping, config repository, notification channels/content/lock-screen privacy/permission handling, and the **real `FirebaseMessagingService` driven with a real `RemoteMessage` and no Activity** (store + notify, duplicate, stale, forged, no secret, preferences) | JVM (simulated Android 14) | included above |
| **Instrumented tests** | Real Android Keystore (non-exportable key, ciphertext at rest, fresh IV, corruption ⇒ "no secret"), and the full pipeline against the real notification manager | Device / emulator | `./gradlew connectedDebugAndroidTest` |

Instrumented tests use their own Keystore alias and preference file, so they never touch the secret or history of the app installed on the same device.

## Gateway tests

`cd gateway && npm install && npm test` runs 58 Node tests against a real HTTP server with a real WebSocket client (mock FCM sender). The Node gateway's FCM payload was also verified by the app's own Kotlin parser and HMAC verifier, compiled and run together, in both the live and the stale case.

## What automation cannot cover (use the QA matrix)

Real FCM delivery through Google's servers, Doze, screen-off/locked behaviour, OEM battery managers, and force-stop. These need a physical device and the reference gateway; see [QA_BACKGROUND_NOTIFICATIONS.md](QA_BACKGROUND_NOTIFICATIONS.md).
