# Release signing and Google Play

Never commit a keystore or a password. Never ship a debug-signed build. The build enforces both: `assembleRelease` / `bundleRelease` stop with a clear message if signing or `app/google-services.json` is missing, and the release build type has **no** fallback to the debug key.

## 1. Create an upload key (once)

```bash
keytool -genkeypair -v -keystore stbluesentinel-upload.jks -alias stbluesentinel \
        -keyalg RSA -keysize 4096 -validity 10000
```

* Keep the `.jks` **outside** the repository and back it up (password manager / secure vault), together with the alias and both passwords.
* Use **Play App Signing** (default for new apps): Google holds the key that signs what users install; this keystore is only your *upload* key. If you lose it, Play support can reset it. Without Play App Signing, losing the key means you can never update the app.

## 2. Give Gradle the credentials (pick one)

**Environment variables** (CI, or a shell profile you keep private):

| Variable | Meaning |
|---|---|
| `STB_KEYSTORE_FILE` | absolute path to the `.jks` |
| `STB_KEYSTORE_PASSWORD` | keystore password |
| `STB_KEY_ALIAS` | key alias (`stbluesentinel`) |
| `STB_KEY_PASSWORD` | key password |

**`keystore.properties`** in the project root (git-ignored; start from `keystore.properties.example`):

```properties
storeFile=/absolute/path/to/stbluesentinel-upload.jks
storePassword=...
keyAlias=stbluesentinel
keyPassword=...
```

Environment variables win over the file. Nothing is read from source code, `BuildConfig`, resources or `gradle.properties`.

## 3. Build

```bash
./gradlew testDebugUnitTest lintRelease          # tests + lint first
./gradlew assembleRelease                        # -> app/build/outputs/apk/release/app-release.apk   (direct install/testing)
./gradlew bundleRelease                          # -> app/build/outputs/bundle/release/app-release.aab (Play upload)
```

`app/google-services.json` must be present ([FIREBASE_SETUP.md](FIREBASE_SETUP.md)). Release builds use R8 (minify + shrink resources).

## 4. Verify what you built

```bash
# APK: signature, signer certificate, no debug cert
$ANDROID_HOME/build-tools/<version>/apksigner verify --verbose --print-certs app/build/outputs/apk/release/app-release.apk

# AAB: signed with your upload key
jarsigner -verify -verbose -certs app/build/outputs/bundle/release/app-release.aab
keytool -printcert -jarfile app/build/outputs/bundle/release/app-release.aab   # compare SHA-256 with your keystore

# Optional: install the AAB the way Play would (bundletool)
bundletool build-apks --bundle=app-release.aab --output=app.apks --connected-device && bundletool install-apks --apks=app.apks
```

Check that the certificate is **not** "Android Debug", the package is `net.seatrace.stbluesentinel`, and versionName/versionCode are what you expect.

## 5. CI (GitHub Actions example)

Store the keystore as a base64 **secret**, never as a file in the repo.

```yaml
name: release
on: workflow_dispatch
jobs:
  release:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with: { distribution: temurin, java-version: 17 }
      - name: Restore signing + Firebase config
        env:
          KEYSTORE_B64: ${{ secrets.STB_KEYSTORE_B64 }}
          GOOGLE_SERVICES_JSON: ${{ secrets.GOOGLE_SERVICES_JSON }}
        run: |
          echo "$KEYSTORE_B64" | base64 -d > "$RUNNER_TEMP/upload.jks"
          echo "$GOOGLE_SERVICES_JSON" > app/google-services.json
          echo "STB_KEYSTORE_FILE=$RUNNER_TEMP/upload.jks" >> "$GITHUB_ENV"
      - name: Build
        env:
          STB_KEYSTORE_PASSWORD: ${{ secrets.STB_KEYSTORE_PASSWORD }}
          STB_KEY_ALIAS: ${{ secrets.STB_KEY_ALIAS }}
          STB_KEY_PASSWORD: ${{ secrets.STB_KEY_PASSWORD }}
        run: ./gradlew testDebugUnitTest bundleRelease assembleRelease
      - uses: actions/upload-artifact@v4
        with: { name: release, path: "app/build/outputs/**/*release*" }
```

This workflow is an example and has not been run. Add a separate job for `cd gateway && npm ci && npm test`.

## 6. Play Console checklist

* **Before each upload:** raise `versionCode` in `app/build.gradle.kts` (must increase every upload); update `versionName`; run the tests; build the AAB.
* **Upload the R8 mapping file** (`app/build/outputs/mapping/release/mapping.txt`) so crash stack traces can be de-obfuscated.
* **Target API:** the app targets API 36 (Android 16); Play requires recent target levels, so re-check each year.
* **Data safety form:** no ads, no analytics, history stays on device; FCM uses Firebase installation identifiers. Complete the form with Google's Firebase disclosures in front of you rather than from memory.
* **Permissions:** only `INTERNET` and `POST_NOTIFICATIONS`. No declarations beyond that are needed (no foreground service, no sensitive permissions).
* **Notification permission:** be prepared to explain in the store listing that alerts are security-critical.
* **Roll out gradually:** *Internal testing* first, then closed/open testing, then production.
* **Keep the upload key secret and backed up.** Rotate it via Play Console if it is ever exposed.
