# Architecture

## Components and trust

```
 SeaTracePro                  Receiver gateway                     Firebase / Google              STBlueSentinel (Android)
 -----------                  ----------------                     ---------------------          ------------------------
 opens WSS to your URL  --->  handshake: path, rate limit,         FCM (high priority,     --->   FirebaseMessagingService
 X-SeaTrace-* headers         headers, 300 s window                data-only, 300 s TTL)          parse -> verify -> dedupe
 ONE signed text frame        HMAC over exact bytes                                               -> Room -> notification
                              schema, de-duplicate (verified id)
                              relay frame (base64) + headers
```

| Component | Holds | Verifies / enforces |
|---|---|---|
| SeaTracePro | signing secret(s) | signs `timestamp + "." + frame` |
| **Gateway** | signing secret(s), Firebase service-account key | headers, **300 s replay window**, **HMAC on exact bytes**, schema, de-duplication, 4 KB / 32 KB limits, TLS-only |
| **FCM** | nothing sensitive (frame is already signed; contains no secret) | delivery; drops after the 5-minute TTL |
| **App** | one signing secret in the Android Keystore | **HMAC again**, timestamp policy (live ≤ 15 min, stale, future, > 24 h), schema, de-duplication (unique `alert_id`), notification policy |

Principle: **nothing is trusted because of how it arrived.** A push reaching the phone proves nothing; only a valid HMAC does. A compromised or spoofed push channel can at worst cause rejected deliveries.

## One alert, step by step

1. SeaTracePro connects to the gateway with `X-SeaTrace-Event/Alert-Id/Timestamp/Signature`.
2. Gateway rejects bad paths, floods, malformed headers or a timestamp outside ±300 s *before* accepting any frame.
3. It accepts one text frame (≤ 32 KB), verifies the HMAC with each configured secret (the one that matches identifies the owner), then parses and validates the body and requires the header alert ID to equal the signed body's.
4. It de-duplicates on `subscriber:alert_id` (retries re-send the same ID for up to 2 h).
5. It sends each of the owner's phones a data-only FCM message: `v, event, alert_id, ts, sig, frame_b64` (≤ 4096 bytes or the alert is rejected).
6. Android starts the app process if needed and calls `StbMessagingService.onMessageReceived` (no UI involved).
7. The app parses the push, runs `AlertVerifier`, and inserts into Room; a duplicate `alert_id` is a no-op.
8. Only a newly inserted, live (`VERIFIED`) alert that the user's preferences allow raises a notification; tapping it opens the alert detail.

## Why these choices

| Decision | Reason |
|---|---|
| Gateway in the middle | SeaTracePro connects *to* a public wss:// endpoint; a phone behind mobile NAT cannot be one. |
| FCM instead of a permanent socket | The Android-supported way to be woken for a message with the app closed; no foreground service, no polling, no battery abuse. |
| Verify twice | Gateway protects the secret and filters early; the app removes any trust in the push path. |
| Data-only FCM | Guarantees the app's code runs, so verification and storage always happen. A `notification` message would be shown by the system and bypass both. |
| 300 s TTL | A live alert must not be presented late; matches the gateway's freshness window. |
| 15-min client tolerance, `STALE` never notifies | Tolerates delayed processing without ever treating an old alert as live; kept for history. |
| Dedupe on verified body `alert_id` | The alert-ID header is not signed and could be swapped on a replay. |
| Secret in Android Keystore, only for HMAC | Non-exportable key; the UI never reads it back. |

## Android limits (not bypassed, only documented)

* **Force stop:** Android blocks all background activity, including FCM delivery, until the user opens the app again.
* **Notifications disabled** (app or channel): alerts are stored but cannot be shown. The app detects and explains this.
* **Doze / App Standby / OEM battery managers:** high-priority FCM is the most resilient path but is not guaranteed. The Help screen reports restricted background activity and standby bucket.
* **Offline > 5 minutes:** FCM discards the alert (by design).

## Failure modes

| Failure | Result |
|---|---|
| Forged / modified frame | Rejected at the gateway; if it somehow reached the phone, rejected there too |
| Replay inside 300 s | Duplicate → ignored |
| Replay with swapped alert-ID header | Header/body mismatch → rejected |
| FCM temporarily down | Gateway retries; if still failing the alert stays retryable for SeaTracePro's own retry |
| Dead push token | Gateway marks the device and logs `device_token_invalid` |
| Alert too large for FCM | Rejected and logged, never truncated |
| Wrong secret on phone | Every alert rejected; dashboard shows *Security verification failed* |
| Keystore unreadable (e.g. before first unlock) | Treated as "no secret": nothing is marked verified |
