# Delivery status

An honest map of what exists and **how far each part was actually verified**. Verification levels:

* **EXECUTED**: compiled and run in the authoring sandbox, with passing results.
* **WRITTEN**: complete source/document, **never built or run** (needs the Android SDK, Gradle and Maven dependencies, which the sandbox could not reach).
* **NOT PRODUCED**: cannot be produced without your environment or credentials.

## The 28 deliverables

| # | Deliverable | Where | Status |
|---|---|---|---|
| 1 | Complete Android Studio project | project root | WRITTEN (51 Kotlin files; Gradle wrapper *jar* not included, see runbook) |
| 2 | Kotlin source | `app/src/main` | WRITTEN; the pure logic files (below) are also EXECUTED |
| 3 | Gradle configuration | `build.gradle.kts`, `app/build.gradle.kts`, `gradle/libs.versions.toml` | WRITTEN; dependency versions **unresolved/unverified** |
| 4 | Room database | `data/db` | WRITTEN; DAO/mapper tests written, not run |
| 5 | HMAC-SHA256 verification | `core/security/SignatureVerifier.kt` | **EXECUTED**: vector agreed by Python, the documentation's Node snippet, the gateway and this Kotlin code |
| 6 | Replay protection | gateway `verify.js` (300 s); app `TimestampPolicy` (15 min / stale / future / 24 h) | **EXECUTED** (both) |
| 7 | Alert de-duplication | gateway `dedupe.js`; app unique `alert_id` + atomic insert-or-ignore | Gateway **EXECUTED**; app-side WRITTEN (Room/processor tests written, not run) |
| 8 | Secure secret storage | `KeystoreSecretStore` (AES-256-GCM, non-exportable Keystore key) | WRITTEN; on-device tests written, not run. Policy part EXECUTED |
| 9 | FCM integration | `fcm/`, gateway `fcm.js` | Payload parser + gateway payload **EXECUTED** (Node gateway output verified by the Kotlin parser/verifier); service WRITTEN |
| 10 | Background notification handling | `StbMessagingService` → `AlertProcessor` | WRITTEN; Robolectric service test written, not run |
| 11 | Notification channels | `NotificationChannels` | WRITTEN (tests written) |
| 12 | Notification permission handling | `NotificationAccessChecker`, `NotificationPermissionCard` | WRITTEN (tests written) |
| 13 | Battery/background guidance | Help screen, `BackgroundHealth` | WRITTEN |
| 14 | Alert history | `HistoryScreen`, filters | Filter/format logic **EXECUTED**; UI WRITTEN |
| 15 | Alert detail | `DetailScreen` | WRITTEN |
| 16 | Settings | `SettingsScreen` | WRITTEN; URL validation **EXECUTED** |
| 17 | Splash screen | system splash + `BrandSplash` | Assets generated from your logo and previewed; code WRITTEN |
| 18 | SeaTrace branding | adaptive + monochrome launcher icon | Generated from your file and previewed on the circle mask |
| 19 | BlueSentinel branding | splash / in-app logo | Generated from your file |
| 20 | Automated tests | `app/src/test`, `app/src/androidTest`, `gateway/test` | 178 JVM/Robolectric + 14 instrumented + 58 gateway written. **EXECUTED here: 92 Kotlin + 58 gateway, all passing**; the rest need Gradle/device |
| 21 | Debug APK | n/a | **NOT PRODUCED** (needs Android SDK + Gradle) |
| 22 | Signed release APK | n/a | **NOT PRODUCED** (needs your keystore; a signing key must never be created or held by a third party) |
| 23 | Signed release AAB | n/a | **NOT PRODUCED** (same) |
| 24 | Release signing instructions | `docs/RELEASE_SIGNING.md` | Written; commands cross-checked against the build script (CI example not run) |
| 25 | Firebase configuration instructions | `docs/FIREBASE_SETUP.md` | Written; message validated against the real `firebase-admin` 13.10.0 validator |
| 26 | Receiver/gateway architecture docs | `docs/ARCHITECTURE.md`, `docs/FCM_CONTRACT.md`, `gateway/README.md` | Written |
| 27 | README | `README.md` | Written; links/paths/env names machine-checked |
| 28 | Background notification testing checklist | `docs/QA_BACKGROUND_NOTIFICATIONS.md` | Written; to be executed on devices |

Also delivered beyond the list: the reference Node.js gateway, a SeaTracePro simulator (`gateway/scripts/simulate-seatrace.js`), a device-registration helper, and a source-hygiene test that enforces the "do not" list (verified to catch 9 planted violations).

## First-build runbook

1. Open the project in a recent Android Studio. Generate the wrapper jar (Android Studio does it, or `gradle wrapper --gradle-version 8.14.3`).
2. **Sync.** Expect to adjust `gradle/libs.versions.toml` if any version cannot be resolved (AGP 8.11.1, Kotlin 2.2.0, KSP 2.2.0-2.0.2, Compose BOM 2025.07.00, Room 2.7.2, Firebase BoM 34.0.0 were chosen from knowledge, not resolved).
3. `./gradlew testDebugUnitTest`: fix any compile errors (see risks) and confirm all tests pass, especially `SourceHygieneTest` and `BackgroundDeliveryTest`.
4. `./gradlew assembleDebug`, install, then `./gradlew connectedDebugAndroidTest` on a device.
5. Add `google-services.json`, run the gateway, then work through [QA_BACKGROUND_NOTIFICATIONS.md](QA_BACKGROUND_NOTIFICATIONS.md).
6. Only then create the upload key and build the release APK/AAB ([RELEASE_SIGNING.md](RELEASE_SIGNING.md)).

### Where first-build problems are most likely
* Compose/Material API drift: `LocalLifecycleOwner` import location, `autoCorrectEnabled`, deprecated icons (`HelpOutline`), `Card(onClick)` opt-ins.
* KSP/Kotlin/AGP version compatibility.
* Robolectric: pinned to SDK 34 (it does not yet cover 36); driving `FirebaseMessagingService` under Robolectric is the least predictable test.
* Lint: hard-coded UI strings produce warnings (English only in V1); `checkReleaseBuilds` is on.

## Decisions made along the way (review these)

| Decision | Detail |
|---|---|
| Client freshness policy | Live ≤ 15 min; > 15 min = `STALE` (stored, **never notifies**); future > 60 s or > 24 h = rejected. Gateway keeps the strict 300 s |
| FCM TTL 300 s | A phone offline > 5 min misses that alert (by design) |
| Stale alerts raise no notification at all | Appear in history as DELAYED |
| One secret in the Android UI | Gateway supports many (tries every configured secret; the match identifies the owner) |
| Unknown future `alert_type` | Kept (shown with its raw name) rather than dropped, because it is correctly signed |
| Extra security level `ATTENTION NEEDED` | "SECURE" is claimed only when verification is configured *and* push/notifications are actually ready |
| "Connected" means reachable | The phone never connects to SeaTracePro; the test only proves your endpoint answers over TLS |
| De-duplicate on the verified body `alert_id` | The alert-ID header is not signed |
| Three notification channels | Alerts (critical/high), Updates (medium/low), Test Alerts |
| `FLAG_SECURE` on Settings | Blocks screenshots while the secret field may be visible |
| Tests use a dummy secret | Your real secret is never in the repository |

## Before you go live

* **Rotate the signing secret.** The real one was pasted into the chat; regenerate it in BlueSentinel and use the new value only in your gateway's environment and the app's Settings.
* Create your own Firebase project; keep the service-account key on the gateway only.
* Keep the upload keystore and its passwords out of git and backed up.
* Run the QA matrix on real devices; do not describe delivery as guaranteed.
