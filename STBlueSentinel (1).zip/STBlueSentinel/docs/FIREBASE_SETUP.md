# Firebase setup (Cloud Messaging)

STBlueSentinel uses Firebase Cloud Messaging (FCM) only to deliver already-verified alerts to the phone. **No Firebase credential and no BlueSentinel signing secret is ever placed in source code, in the FCM payload, or in this repository.**

Two different Firebase files are involved. Do not mix them up:

| File | Where it goes | What it is |
|---|---|---|
| `google-services.json` | `app/` in this project (git-ignored) | Public client configuration for the **Android app** |
| Service-account key (JSON) | **Only** on the gateway server | Private credential that lets the **gateway** send messages. Treat like a password |

## 1. Create a Firebase project

[console.firebase.google.com](https://console.firebase.google.com) → **Add project**. You can decline Google Analytics: the app does not use it.

## 2. Add the Android app

*Project settings → Your apps → Add app → Android*. Use the **exact package name**:

```
net.seatrace.stbluesentinel
```

Nickname is free-form. No SHA-1/SHA-256 fingerprint is needed for FCM.

## 3. Download `google-services.json`

Download it from the same screen and place it here (not in `app/src`):

```
STBlueSentinel/
└── app/
    └── google-services.json
```

It is git-ignored. Release builds refuse to run without it; debug builds compile without it but report *Push: Not configured*.

## 4. Messaging configuration

Nothing else is required in the app: the Firebase Messaging library, the `FirebaseMessagingService` (`StbMessagingService`) and the notification channels are already wired. The **Firebase Cloud Messaging API (V1)** is enabled by default on new projects; if sending fails with a permission error, enable it in Google Cloud Console → APIs & Services.

## 5. The phone's registration token

On first run (and whenever FCM rotates it) the app obtains a push token and stores it locally. To let your gateway reach this phone:

1. In the app: **Settings → This device**: note the **Device ID**, tap **Copy push token** (treat it as private).
2. On the gateway host:
   ```bash
   FCM_TOKEN='<pasted token>' npm run device:add -- --subscriber <your-subscriber-id> --device-id <Device ID>
   kill -HUP $(pgrep -f "node src/index.js")      # reload
   ```

The registry is designed for later growth: each device record already carries `device_id`, `fcm_token`, and a subscriber (user/receiver) association.

## 6. Give the gateway permission to send

*Project settings → Service accounts → Generate new private key.* Save the JSON on the **gateway server only** (e.g. `/etc/bluesentinel/firebase-service-account.json`, mode `600`) and point to it with `FIREBASE_SERVICE_ACCOUNT_FILE` (or `GOOGLE_APPLICATION_CREDENTIALS`).

Prefer least privilege: in Google Cloud Console → IAM, create a dedicated service account with only the FCM sending role (listed in IAM as **Firebase Cloud Messaging Admin**; confirm the name in your console) and use *its* key rather than the default Admin SDK key. Never commit the file (it is git-ignored) and rotate it if exposed.

## 7. Configure the gateway

See [gateway/README.md](../gateway/README.md): set your subscribers, export each BlueSentinel signing secret via the environment, terminate TLS, and give SeaTracePro your `wss://` URL. The **BlueSentinel signing secret belongs to the gateway (and the app's Keystore), never to Firebase**; it is neither a Firebase credential nor an FCM setting.

## 8. Test, from safe to real

1. **Validate without delivering:** start the gateway with `FCM_DRY_RUN=true` and run the simulator (below). Firebase checks the message; nothing is sent to a phone.
2. **Deliver a test alert:**
   ```bash
   BS_SECRET="$YOUR_SIGNING_SECRET" node gateway/scripts/simulate-seatrace.js \
     --url wss://alerts.example.com/bluesentinel --type notification_test
   ```
   The phone should show **TEST ALERT — NOT A REAL INCIDENT**, and the alert should be in the app's history.
3. **Background check:** repeat with the app swiped away, the screen locked, and the phone idle (see the QA matrix).
4. **Expected rejections:** `--age 400` is refused by the gateway (outside 300 s). Delivery held back by the network for more than 5 minutes is dropped by FCM (TTL).

> **Do not use the Firebase console's "Send test message" / Notifications composer.** It sends *notification* messages, which Android displays itself when the app is in the background, bypassing the app's verification and storage. The app is built to ignore messages that are not in the gateway's contract. Always test through the gateway.

## 9. Troubleshooting

| Symptom | Check |
|---|---|
| App says *Push: Not configured* | `app/google-services.json` missing or built before it was added; package name must match exactly |
| Gateway `push_failed` with `kind:"config"` | Service-account file path/permissions, wrong project, FCM API disabled |
| Gateway `device_token_invalid` | App reinstalled or data cleared: copy a fresh token |
| Gateway `alert_too_large_for_fcm` | Alert exceeds the 4 KB FCM data limit once encoded (about 2.9 KB of raw frame): rejected, not truncated |
| Works with the app open, not when closed | Notifications disabled/silenced in Android, battery "Restricted", or the app was force-stopped (see *Help & diagnostics*) |
