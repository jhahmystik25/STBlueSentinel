# Background-notification QA checklist

Purpose: prove, on real devices, that a verified BlueSentinel alert produces a trustworthy notification **without the app UI being open**, and that every documented limitation behaves as described. Automated tests cover the logic ([TESTING.md](TESTING.md)); this checklist covers what only a device, Google's FCM servers and the OEM's battery manager can show.

**Do not claim guaranteed delivery.** Android can block notifications (permission, channel, force-stop, battery restrictions), and the 5-minute FCM TTL is deliberate. This checklist records what *happened*, it does not promise outcomes.

## 0. Setup (once per device)

1. Install a build (debug or release) with a real `app/google-services.json`; run the gateway ([gateway/README.md](../gateway/README.md)) on a public `wss://` URL.
2. In the app: save the receiver URL and the **same signing secret** the gateway uses; allow notifications; open *Help & diagnostics* and confirm *Push: Active* and *Push token present*.
3. Register the phone with the gateway (`device:add`, then `SIGHUP`) and leave the gateway log visible (`alert_relayed` is the gateway-side proof).
4. Shell helpers (run from the repository root):
   ```bash
   export PKG=net.seatrace.stbluesentinel
   export URL=wss://alerts.example.com/bluesentinel
   export BS_SECRET='<the signing secret>'          # same value as in the app and the gateway
   send() { node gateway/scripts/simulate-seatrace.js --url "$URL" "$@"; }
   # examples:  send --type danger_zone_entry --severity high --id QA-A1
   #            send --type notification_test --id QA-TEST1
   ```
   Always give each test a **unique `--id`** (the gateway and the app both drop repeats).

Useful device commands (USB debugging; `adb` on your PATH):

| Goal | Command |
|---|---|
| Home button | `adb shell input keyevent KEYCODE_HOME` |
| Screen off / on | `adb shell input keyevent KEYCODE_SLEEP` / `KEYCODE_WAKEUP` |
| Kill the app process (not a force-stop) | `adb shell am kill $PKG` (works when the app is in the background) |
| **Force-stop** | `adb shell am force-stop $PKG` |
| Deep Doze on | `adb shell dumpsys battery unplug && adb shell dumpsys deviceidle enable deep && adb shell dumpsys deviceidle force-idle` |
| Deep Doze status / off | `adb shell dumpsys deviceidle get deep` (expect `IDLE`) / `adb shell dumpsys deviceidle unforce && adb shell dumpsys battery reset` |
| Standby bucket | `adb shell am set-standby-bucket $PKG restricted` (also `rare`, `frequent`, `working_set`, `active`); read: `adb shell am get-standby-bucket $PKG` |
| Background "Restricted" battery setting | `adb shell cmd appops set $PKG RUN_ANY_IN_BACKGROUND deny` (undo: `... default`) |
| Airplane mode | `adb shell cmd connectivity airplane-mode enable` / `disable` (Android 11+; otherwise use the UI) |
| Revoke / grant notification permission (Android 13+) | `adb shell pm revoke $PKG android.permission.POST_NOTIFICATIONS` / `pm grant ...` |
| See posted notifications | `adb shell dumpsys notification \| grep -A12 "pkg=$PKG"` |
| App log (debug builds) | `adb logcat -s STBlueSentinel` (event wording only; never secrets) |
| Inspect stored alerts (debug builds) | `adb exec-out run-as $PKG cat databases/stbluesentinel.db > qa.db` (also copy `-wal`/`-shm`), then `sqlite3 qa.db "select alert_id,severity,delivery_status,test_alert from alerts"` |

## 1. Matrix at a glance

| Device state | Test | Expected |
|---|---|---|
| App open | **A** | Alert stored + notification |
| App in background (Home) | **B** | Alert stored + notification |
| Screen locked | **C** | Notification, shaped by the lock-screen setting |
| Screen off | **D** | Notification |
| App UI closed / process dead | **E** | Notification via FCM, no UI involved |
| Device idle (Doze) | **F** | Notification, *subject to Android/FCM delivery rules* |
| App force-stopped by the user | **G** | **No delivery.** Documented Android restriction |
| Network temporarily unavailable | **H** | Delivered if back within 5 min; otherwise dropped by FCM TTL |
| Notifications disabled | **I** | Alert stored; app explains and links to Settings |
| Battery restricted / OEM manager | **J** | Delivery may be delayed or blocked; Help screen reports it |

Plus integrity checks **K1–K6** (duplicates, forgery, test styling, tap-through, privacy, permission flow).

## 2. Tests

For each: do the steps, tick the evidence, record the result in §4.

### A. App open
1. Open the app on the dashboard. 2. `send --type danger_zone_entry --severity high --id QA-A1`.
**Expect:** gateway `alert_relayed`; notification **BlueSentinel — HIGH** appears; alert in *View Alerts* (marked NEW); dashboard counts increase.
**Evidence:** screenshot of notification + history row; gateway log line.

### B. App in background
1. Press Home (`KEYCODE_HOME`); leave the app listed in recents. 2. `send ... --id QA-B1`.
**Expect:** notification arrives; tapping it opens the app **on the alert detail**; alert already in history.

### C. Screen locked
1. Lock the device (secure lock screen set). 2. `send ... --id QA-C1`.
**Expect:** a notification on the lock screen according to *Settings → Notifications → Lock screen*:
* "Show all": shows severity + title; 
* "Hide sensitive content": shows only the public version: **`BlueSentinel — HIGH` / "New alert. Unlock to view details."**, with **no vessel or area**.
**Fail if** vessel name or position is visible while sensitive content is hidden.

### D. Screen off
1. `KEYCODE_SLEEP`; wait 30 s. 2. `send ... --id QA-D1`. **Expect:** screen wakes or the notification is waiting on wake, per device behaviour; alert stored.

### E. App UI closed (process not running)
1. Swipe the app away from recents, then `adb shell am kill $PKG`; confirm no process: `adb shell pidof $PKG` returns nothing.
2. `send ... --id QA-E1`.
**Expect:** notification appears; `pidof` now shows a process (Android started it for the push); open the app: **QA-E1 is already in history**.
This is the core requirement: *alerts do not need the UI to be open*.

### F. Idle / Doze
1. Unplug logic + deep Doze (commands above); confirm `IDLE`. 2. `send ... --id QA-F1`.
**Expect:** the high-priority message is delivered and the notification shown. Record latency (gateway `alert_relayed` time → notification time). Investigate anything over ~60 s, but do not treat Doze delay as an app bug: it is Android/FCM behaviour.
3. Undo Doze (`unforce`, `battery reset`).

### G. Force-stopped (documented limitation)
1. `adb shell am force-stop $PKG`. 2. `send ... --id QA-G1`.
**Expect: no notification and no history entry.** This is Android's rule and is not bypassed. Confirm the *Help & diagnostics → Limits* text says so.
3. Open the app once (launching clears the stopped state). 4. `send ... --id QA-G2` → **must** arrive again. QA-G1 stays missing (5-minute TTL).

### H. Network temporarily unavailable
1. Airplane mode on. 2. `send ... --id QA-H1`. 3a. Airplane off within **2 minutes** → **expect delivery** after reconnect. 3b. Repeat with `QA-H2` and wait **> 5 minutes** before airplane off → **expect no delivery** (FCM TTL), and nothing stale appears as "live".
Gateway log shows `alert_relayed` both times (it hands over to FCM; delivery to the phone is FCM's job).

### I. Notifications disabled
1. Android 13+: `pm revoke ... POST_NOTIFICATIONS` (or switch the app's notifications off in Settings). 2. Open the app: dashboard shows **ATTENTION NEEDED** and the card **"Notifications are disabled. Enable notifications in Android Settings to receive BlueSentinel alerts."** with a working *Open notification settings* button. 3. `send ... --id QA-I1`.
**Expect:** no notification; **QA-I1 is in history**. Re-enable; `send ... --id QA-I2` → notification.
Also: silence only the **BlueSentinel Alerts** channel → dashboard/Help report *channel silenced*.

### J. Battery restriction / OEM managers
1. Set standby bucket `restricted`, and separately `RUN_ANY_IN_BACKGROUND deny`. 2. Open *Help & diagnostics*: it must report the restriction. 3. `send ... --id QA-J1` for each; record whether and when it arrived. **Do not** assert a pass/fail expectation for delivery here: record the behaviour; the requirement is that the app *explains* the risk.
4. Repeat §3 (OEM notes) on at least one physical Samsung/Xiaomi/Huawei-class device with default battery settings, then with the vendor's "allow background" setting.

## 3. Integrity checks (device-level)

| ID | Do | Expect |
|---|---|---|
| **K1** Duplicate | `send --id QA-K1` three times | One notification, one history row (gateway logs `duplicate_ignored` twice) |
| **K2** Forgery | Use a wrong `BS_SECRET` | Gateway `frame_rejected: signature_invalid`; nothing reaches the phone. Then change only the secret *saved in the app* and send a valid alert → app shows **Security verification failed**, nothing stored; *Help → Recent rejected deliveries* lists `signature mismatch` |
| **K3** Replay window | `send --age 400 --id QA-K3` | Gateway `handshake_rejected: timestamp_outside_replay_window`; no push |
| **K4** Test alert | `send --type notification_test --id QA-K4` | Title **TEST ALERT — NOT A REAL INCIDENT**, channel *BlueSentinel Test Alerts*, purple TEST tag in history, not counted on the dashboard |
| **K5** Tap-through | Tap the notification from cold start and from warm | Opens the **alert detail** for that alert; Back returns to the dashboard |
| **K6** Permission flow (Android 13+) | Fresh install; open app | No system prompt on launch; prompt appears only after tapping **Allow notifications**; deny once → can ask again; deny twice → only **Open notification settings** is offered |
| **K7** Stale | *Cannot be produced on a device through the normal chain by design* (the gateway refuses anything older than 300 s). Covered by automated tests (`TimestampPolicyTest`, `BackgroundDeliveryTest`). |
| **K8** Oversize | Send an alert whose frame exceeds ~2.9 KB | Gateway logs `alert_too_large_for_fcm`; **not** delivered or truncated |

## 4. Result record (copy per device)

| Field | Value |
|---|---|
| Device / OS build / Android version | |
| Build (debug/release, versionName) | |
| Gateway version/date, network | |
| Battery settings (default / unrestricted / restricted) | |

| Test | Result (Pass / Fail / N/A) | Latency | Evidence (screenshot / log) | Notes |
|---|---|---|---|---|
| A App open | | | | |
| B Background | | | | |
| C Locked (+ privacy) | | | | |
| D Screen off | | | | |
| E UI closed | | | | |
| F Doze | | | | |
| G Force-stop (expect NOT delivered) | | | | |
| H Network drop (<2 min / >5 min) | | | | |
| I Notifications disabled | | | | |
| J Battery restricted | | | | |
| K1–K6, K8 | | | | |

## 5. Per-manufacturer notes (menu names vary by version; see dontkillmyapp.com)

| Family | What commonly interferes | What to check |
|---|---|---|
| Google Pixel / stock Android | App Standby buckets, "Restricted" battery | *App info → Battery → Unrestricted/Optimized*. Pixel is the baseline: if it fails here, suspect the app or gateway |
| Samsung (One UI) | "Put unused apps to sleep", Sleeping apps | *Battery → Background usage limits*: ensure STBlueSentinel is not in Sleeping/Deep sleeping apps |
| Xiaomi / Redmi / POCO (MIUI, HyperOS) | Autostart off, aggressive battery saver | *Autostart* on; *Battery saver → No restrictions* for the app |
| Huawei / Honor | App launch "Manage manually" needed, power-intensive prompts | *App launch*: manual, allow background activity |
| OnePlus / OPPO / realme / Vivo | Auto-launch, battery optimisation | Allow auto-launch/background; set battery to unrestricted |

The app deliberately **does not request a battery-optimisation exemption**; these steps are guidance for users, shown in *Help & diagnostics*.

## 6. Android-version coverage (minimum)

| Version | Why |
|---|---|
| Android 10 (API 29) | minSdk; no runtime notification permission |
| Android 13 (API 33) | first runtime `POST_NOTIFICATIONS` (test K6, I) |
| Android 14/15 | current behaviour for background limits |
| Android 16 (API 36) | target SDK |
Emulators are fine for A–E, G, I and Doze commands; use physical devices for H timing, C (secure lock screen) and every J/OEM case.

## 7. Release gate

Do not ship a build until, on at least one physical device per row above that you support: **A, B, C(privacy), D, E, K1, K2, K4, K5, K6** pass; **G** behaves exactly as documented; **I** and **J** show the correct explanations; and the gateway log for every run shows the expected `alert_relayed` / `duplicate_ignored` / `*_rejected` lines with no secrets, signatures, tokens or frames in them.
