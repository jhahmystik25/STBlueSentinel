# kotlinx.serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class net.seatrace.stbluesentinel.**$$serializer { *; }
-keepclassmembers class net.seatrace.stbluesentinel.** { *** Companion; }
-keepclasseswithmembers class net.seatrace.stbluesentinel.** { kotlinx.serialization.KSerializer serializer(...); }

# OkHttp / Okio optional platform classes
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**

# Release-safe logging: strip verbose/debug/info logging calls entirely.
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
    public static int i(...);
}
