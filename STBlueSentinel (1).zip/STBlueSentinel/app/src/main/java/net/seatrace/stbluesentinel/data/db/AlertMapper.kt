package net.seatrace.stbluesentinel.data.db

import net.seatrace.stbluesentinel.core.model.DeliveryStatus
import net.seatrace.stbluesentinel.core.pipeline.VerificationOutcome
import java.time.OffsetDateTime

/** Converts an HMAC-verified alert into a database row. Only [VerificationOutcome.Accepted] can be mapped. */
fun VerificationOutcome.Accepted.toEntity(receivedAtMillis: Long): AlertEntity {
    require(status != DeliveryStatus.REJECTED)
    val a = alert
    val v = a.vessel
    val t = a.threat
    val ni = t?.nearestIncident
    return AlertEntity(
        alertId = requireNotNull(a.alertId),
        alertType = requireNotNull(a.alertType),
        severity = requireNotNull(a.severity).lowercase(),
        title = requireNotNull(a.title),
        message = a.message,
        schemaVersion = a.schemaVersion,
        source = a.source,
        product = a.product,
        timestampUtc = parseIsoMillis(a.timestampUtc),
        createdUtc = parseIsoMillis(a.createdUtc),
        receivedAt = receivedAtMillis,
        verified = true,
        deliveryStatus = status.name,
        signedAt = signedAtEpochSeconds,
        deliveryAgeSeconds = ageSeconds,
        testAlert = a.isTest,
        testNotice = a.testNotice,
        shipId = v?.shipId,
        mmsi = v?.mmsi,
        shipName = v?.shipName,
        imo = v?.imo,
        latitude = v?.latitude,
        longitude = v?.longitude,
        speedKnots = v?.speedKnots,
        courseDeg = v?.courseDeg,
        lastSeenUtc = parseIsoMillis(v?.lastSeenUtc),
        threatState = t?.state,
        areaLabel = t?.areaLabel,
        nearestIncidentKm = t?.nearestIncidentKm,
        incidentsWithinRadius = t?.incidentsWithinRadius,
        radiusKm = t?.radiusKm,
        datasetLatestIncidentDate = t?.datasetLatestIncidentDate,
        nearestIncidentDate = ni?.date,
        nearestIncidentAttackType = ni?.attackType,
        nearestIncidentCountry = ni?.nearestCountry,
        nearestIncidentLocation = ni?.locationDescription,
        nearestIncidentDistanceKm = ni?.distanceKm,
        rawPayload = rawFrame,
    )
}

/** Parses ISO-8601 with `Z` or an offset. Returns null (never a fake value) if absent or unparseable. */
internal fun parseIsoMillis(value: String?): Long? =
    if (value.isNullOrBlank()) null else runCatching { OffsetDateTime.parse(value).toInstant().toEpochMilli() }.getOrNull()
