package net.seatrace.stbluesentinel.receiver

import java.net.URI
import java.net.URISyntaxException

enum class UrlError(val message: String) {
    EMPTY("Enter your receiver's wss:// address."),
    NOT_WSS("The address must start with wss:// (ws:// and http(s):// are not allowed)."),
    MALFORMED("This is not a valid web address."),
    CREDENTIALS_IN_URL("Remove the username/password from the address. Credentials must never be placed in the URL."),
    QUERY_NOT_ALLOWED("Remove everything after “?”. Secrets and tokens must never be placed in query parameters."),
    FRAGMENT_NOT_ALLOWED("Remove everything after “#”."),
    NOT_PUBLIC_HOST("SeaTracePro connects from the internet, so the address must be a public hostname (not localhost, a private IP, or an internal name)."),
    TOO_LONG("The address is too long."),
}

sealed interface UrlValidation {
    data class Valid(val normalized: String) : UrlValidation
    data class Invalid(val error: UrlError) : UrlValidation
}

/**
 * Validates the customer's public receiver endpoint exactly as the BlueSentinel documentation requires:
 * wss:// only, publicly resolvable, no credentials in the URL, no secrets in query parameters.
 */
object ReceiverUrlValidator {
    private const val MAX_LENGTH = 2048
    private val IPV4 = Regex("""(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})""")
    private val INTERNAL_SUFFIXES = listOf(".local", ".localhost", ".internal", ".lan", ".home", ".corp", ".home.arpa", ".intranet")

    fun validate(input: String): UrlValidation {
        val text = input.trim()
        if (text.isEmpty() || text.equals("wss://", ignoreCase = true)) return bad(UrlError.EMPTY)
        if (text.length > MAX_LENGTH) return bad(UrlError.TOO_LONG)
        if (text.any { it.isWhitespace() }) return bad(UrlError.MALFORMED)

        val schemeEnd = text.indexOf("://")
        if (schemeEnd <= 0) return bad(UrlError.NOT_WSS)
        if (!text.substring(0, schemeEnd).equals("wss", ignoreCase = true)) return bad(UrlError.NOT_WSS)
        val normalized = "wss" + text.substring(schemeEnd)

        val uri = try { URI(normalized) } catch (_: URISyntaxException) { return bad(UrlError.MALFORMED) }
        if (uri.rawUserInfo != null) return bad(UrlError.CREDENTIALS_IN_URL)
        if (uri.rawQuery != null) return bad(UrlError.QUERY_NOT_ALLOWED)
        if (uri.rawFragment != null) return bad(UrlError.FRAGMENT_NOT_ALLOWED)
        val host = uri.host?.lowercase()?.trimEnd('.') ?: return bad(UrlError.MALFORMED)
        if (host.isEmpty()) return bad(UrlError.MALFORMED)
        if (!isPublicHost(host)) return bad(UrlError.NOT_PUBLIC_HOST)
        return UrlValidation.Valid(normalized)
    }

    private fun bad(e: UrlError) = UrlValidation.Invalid(e)

    private fun isPublicHost(host: String): Boolean {
        if (host.startsWith("[") || host.contains(':')) { // IPv6 literal
            val h = host.trim('[', ']')
            return !(h == "::1" || h == "::" || h.startsWith("fe80") || h.startsWith("fc") || h.startsWith("fd"))
        }
        IPV4.matchEntire(host)?.let { m ->
            val o = m.groupValues.drop(1).map { it.toInt() }
            if (o.any { it > 255 }) return false
            val (a, b) = o[0] to o[1]
            val private = a == 10 || a == 127 || a == 0 || (a == 169 && b == 254) ||
                (a == 172 && b in 16..31) || (a == 192 && b == 168) || (a == 100 && b in 64..127) || a >= 224
            return !private
        }
        if (!host.contains('.')) return false                       // single-label names are not publicly resolvable
        if (INTERNAL_SUFFIXES.any { host == it.trimStart('.') || host.endsWith(it) }) return false
        return true
    }
}
