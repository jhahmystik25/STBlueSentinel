package net.seatrace.stbluesentinel.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import kotlinx.coroutines.delay
import net.seatrace.stbluesentinel.ui.screens.BrandSplash
import net.seatrace.stbluesentinel.ui.screens.DashboardScreen
import net.seatrace.stbluesentinel.ui.screens.DetailScreen
import net.seatrace.stbluesentinel.ui.screens.HelpScreen
import net.seatrace.stbluesentinel.ui.screens.HistoryScreen
import net.seatrace.stbluesentinel.ui.screens.SettingsScreen
import net.seatrace.stbluesentinel.ui.theme.StbTheme

private object Routes {
    const val DASHBOARD = "dashboard"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
    const val HELP = "help"
    const val DETAIL = "detail/{id}"
    fun detail(id: Long) = "detail/$id"
}

/**
 * Root composable. A notification tap (openAlertRowId >= 0) skips the branded splash so the alert opens immediately,
 * with the dashboard underneath so Back behaves naturally.
 */
@Composable
fun StbApp(openAlertRowId: Long, onOpenAlertHandled: () -> Unit) {
    StbTheme {
        var showSplash by rememberSaveable { mutableStateOf(openAlertRowId < 0) }
        LaunchedEffect(Unit) { if (showSplash) { delay(900); showSplash = false } }

        if (showSplash) {
            BrandSplash()
        } else {
            val nav = rememberNavController()
            LaunchedEffect(openAlertRowId) {
                if (openAlertRowId >= 0) {
                    nav.navigate(Routes.detail(openAlertRowId)) { launchSingleTop = true }
                    onOpenAlertHandled()
                }
            }
            NavHost(nav, startDestination = Routes.DASHBOARD) {
                composable(Routes.DASHBOARD) {
                    DashboardScreen(
                        onViewAlerts = { nav.navigate(Routes.HISTORY) },
                        onSettings = { nav.navigate(Routes.SETTINGS) },
                        onHelp = { nav.navigate(Routes.HELP) },
                        onOpenAlert = { nav.navigate(Routes.detail(it)) },
                    )
                }
                composable(Routes.HISTORY) { HistoryScreen(onBack = { nav.popBackStack() }, onOpenAlert = { nav.navigate(Routes.detail(it)) }) }
                composable(Routes.DETAIL, arguments = listOf(navArgument("id") { type = NavType.LongType })) { DetailScreen(onBack = { nav.popBackStack() }) }
                composable(Routes.SETTINGS) { SettingsScreen(onBack = { nav.popBackStack() }, onHelp = { nav.navigate(Routes.HELP) }) }
                composable(Routes.HELP) { HelpScreen(onBack = { nav.popBackStack() }) }
            }
        }
    }
}
