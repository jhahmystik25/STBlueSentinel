package net.seatrace.stbluesentinel.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import net.seatrace.stbluesentinel.R
import net.seatrace.stbluesentinel.notifications.NotificationAccess
import net.seatrace.stbluesentinel.notifications.NotificationAccessChecker
import net.seatrace.stbluesentinel.notifications.SharedPrefsNotificationPreferences

/**
 * Notification permission flow. The Android system prompt is shown ONLY after the user taps
 * "Allow notifications" on this card, i.e. after the reason has been explained - never on launch.
 * State is re-evaluated every time the screen resumes, so returning from Android Settings updates it.
 */
@Composable
fun NotificationPermissionCard(prefs: SharedPrefsNotificationPreferences, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    var access by remember { mutableStateOf(NotificationAccessChecker.evaluate(context, activity, prefs.permissionRequested)) }
    fun refresh() { access = NotificationAccessChecker.evaluate(context, activity, prefs.permissionRequested) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) refresh() }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }

    Card(modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            when (access) {
                NotificationAccess.GRANTED -> Text(stringResource(R.string.notif_enabled), style = MaterialTheme.typography.bodyLarge)

                NotificationAccess.CAN_REQUEST -> {
                    Text(stringResource(R.string.notif_why_title), style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(R.string.notif_why_body), Modifier.padding(vertical = 8.dp), style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = {
                        prefs.permissionRequested = true
                        launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }) { Text(stringResource(R.string.notif_allow_button)) }
                }

                NotificationAccess.OPEN_SETTINGS -> {
                    Text(stringResource(R.string.notif_disabled_title), style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(R.string.notif_disabled_body), Modifier.padding(vertical = 8.dp), style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = { context.startActivity(NotificationAccessChecker.settingsIntent(context)) }) {
                        Text(stringResource(R.string.notif_open_settings))
                    }
                }

                NotificationAccess.CHANNEL_BLOCKED -> {
                    Text(stringResource(R.string.notif_channel_blocked_title), style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(R.string.notif_channel_blocked_body), Modifier.padding(vertical = 8.dp), style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = { context.startActivity(NotificationAccessChecker.settingsIntent(context)) }) {
                        Text(stringResource(R.string.notif_open_settings))
                    }
                }
            }
        }
    }
}

internal tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
