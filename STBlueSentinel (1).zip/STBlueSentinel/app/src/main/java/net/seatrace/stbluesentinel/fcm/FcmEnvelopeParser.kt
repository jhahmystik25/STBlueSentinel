package net.seatrace.stbluesentinel.fcm

import net.seatrace.stbluesentinel.core.pipeline.AlertEnvelope
import net.seatrace.stbluesentinel.core.security.RejectReason
import java.util.Base64

/**
 * Gateway -> app FCM data-message contract, version 1. See docs/FCM_CONTRACT.md.
 *
 * The gateway forwards the ORIGINAL WebSocket frame, base64-encoded (so no transport can alter the
 * signed bytes), plus the three header values needed to verify it. The signing secret is NEVER part
 * of this payload.
 */
object FcmContract {
    const val VERSION = "1"
    const val KEY_VERSION = "v"
    const val KEY_EVENT = "event"          // X-SeaTrace-Event
    const val KEY_ALERT_ID = "alert_id"    // X-SeaTrace-Alert-Id
    const val KEY_TIMESTAMP = "ts"         // X-SeaTrace-Timestamp (exact string)
    const val KEY_SIGNATURE = "sig"        // X-SeaTrace-Signature (exact string)
    const val KEY_FRAME = "frame_b64"      // exact received text frame, UTF-8 bytes, standard base64

    /** FCM's data-payload ceiling (keys + values). The gateway REJECTS oversize alerts - it never truncates or re-encodes. */
    const val MAX_PAYLOAD_BYTES = 4096

    /** Live security alerts must expire quickly: aligned with the gateway's 300 s freshness window. */
    const val TTL_SECONDS = 300
}

sealed interface FcmParseResult {
    /** A BlueSentinel message, ready for verification. */
    class Envelope(val envelope: AlertEnvelope) : FcmParseResult
    /** Not one of ours (no contract version key): ignored silently. */
    data object NotBlueSentinel : FcmParseResult
    /** Ours but unusable. Recorded as a rejection; never notified. */
    class Invalid(val reason: RejectReason) : FcmParseResult
}

object FcmEnvelopeParser {
    fun parse(data: Map<String, String>): FcmParseResult {
        val version = data[FcmContract.KEY_VERSION] ?: return FcmParseResult.NotBlueSentinel
        if (version != FcmContract.VERSION) return FcmParseResult.Invalid(RejectReason.UNSUPPORTED_PUSH_VERSION)

        val size = data.entries.sumOf { it.key.toByteArray(Charsets.UTF_8).size + it.value.toByteArray(Charsets.UTF_8).size }
        if (size > FcmContract.MAX_PAYLOAD_BYTES) return FcmParseResult.Invalid(RejectReason.PUSH_PAYLOAD_TOO_LARGE)

        val b64 = data[FcmContract.KEY_FRAME]
        if (b64.isNullOrEmpty()) return FcmParseResult.Invalid(RejectReason.INVALID_PUSH_PAYLOAD)
        // Strict standard-alphabet decoder: whitespace, line breaks or URL-safe characters are rejected, not "fixed up".
        val frame = try {
            Base64.getDecoder().decode(b64)
        } catch (_: IllegalArgumentException) {
            return FcmParseResult.Invalid(RejectReason.INVALID_PUSH_PAYLOAD)
        }

        return FcmParseResult.Envelope(
            AlertEnvelope(
                event = data[FcmContract.KEY_EVENT],
                alertId = data[FcmContract.KEY_ALERT_ID],
                timestamp = data[FcmContract.KEY_TIMESTAMP],
                signature = data[FcmContract.KEY_SIGNATURE],
                frame = frame,
            ),
        )
    }
}
