package net.seatrace.stbluesentinel.core.pipeline

import kotlinx.coroutines.CancellationException
import net.seatrace.stbluesentinel.core.model.Severity
import net.seatrace.stbluesentinel.core.security.RejectReason
import net.seatrace.stbluesentinel.data.db.AlertEntity
import net.seatrace.stbluesentinel.data.db.toEntity
import net.seatrace.stbluesentinel.notifications.NotificationPolicy
import net.seatrace.stbluesentinel.notifications.NotificationPreferences
import net.seatrace.stbluesentinel.notifications.NotifyDecision

/** Narrow seams so the processor is unit-testable without Room or Android. */
fun interface AlertWriter { suspend fun insertIfNew(alert: AlertEntity): Long }   // < 0 means duplicate alert_id
fun interface RejectionRecorder { suspend fun record(alertId: String?, reason: RejectReason, atMillis: Long) }
fun interface AlertNotifier { fun notify(alert: AlertEntity): Boolean }           // true = actually posted

sealed interface ProcessResult {
    class Rejected(val reason: RejectReason) : ProcessResult
    /** Same alert_id already stored (SeaTracePro retry): no new row, no new notification. */
    data object Duplicate : ProcessResult
    class Notified(val rowId: Long) : ProcessResult
    /** Stored in history but intentionally not notified (stale, or switched off by the user). */
    class StoredSilently(val rowId: Long, val decision: NotifyDecision) : ProcessResult
    /** Stored, a notification was wanted, but Android did not post it (e.g. permission off). */
    class StoredNotificationBlocked(val rowId: Long) : ProcessResult
    class StorageFailed : ProcessResult
}

/**
 * The full pipeline from the architecture diagram:
 *   verify (headers -> timestamp -> HMAC -> parse -> schema) -> dedupe+store -> notify.
 *
 * Invariants:
 *  - A notification can only follow a row that was newly inserted, so each alert_id notifies at most once.
 *  - Only VERIFIED (live, HMAC-valid) alerts may notify; STALE alerts are history-only.
 *  - Storage happens before notification, so history is complete even if posting fails or the process dies.
 *  - Nothing here throws to the caller (the FCM service must never crash), except coroutine cancellation.
 */
class AlertProcessor(
    private val verifier: AlertVerifier,
    private val writer: AlertWriter,
    private val rejections: RejectionRecorder,
    private val notifier: AlertNotifier,
    private val prefs: NotificationPreferences,
    private val nowMillis: () -> Long = { System.currentTimeMillis() },
) {
    suspend fun process(envelope: AlertEnvelope): ProcessResult {
        val outcome = verifier.verify(envelope)
        val now = nowMillis()

        if (outcome is VerificationOutcome.Rejected) {
            safely { rejections.record(outcome.alertId, outcome.reason, now) }
            return ProcessResult.Rejected(outcome.reason)
        }
        outcome as VerificationOutcome.Accepted

        val entity = outcome.toEntity(receivedAtMillis = now)
        val rowId = try {
            writer.insertIfNew(entity)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            return ProcessResult.StorageFailed()
        }
        if (rowId < 0) return ProcessResult.Duplicate

        val severity = Severity.fromWire(entity.severity) ?: Severity.LOW
        val decision = NotificationPolicy.decide(outcome.status, severity, entity.testAlert, prefs)
        if (decision != NotifyDecision.NOTIFY) return ProcessResult.StoredSilently(rowId, decision)

        val posted = try { notifier.notify(entity.copy(id = rowId)) } catch (_: Exception) { false }
        return if (posted) ProcessResult.Notified(rowId) else ProcessResult.StoredNotificationBlocked(rowId)
    }

    private suspend inline fun safely(block: () -> Unit) {
        try { block() } catch (e: CancellationException) { throw e } catch (_: Exception) { /* audit log is best-effort */ }
    }
}
