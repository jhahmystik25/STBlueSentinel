package net.seatrace.stbluesentinel.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Dark maritime-intelligence palette: deep navy surfaces, SeaTrace cyan accent, restrained contrast. Dark only, by design. */
private val StbDark = darkColorScheme(
    primary = Color(0xFF4FC3F7), onPrimary = Color(0xFF00232F),
    primaryContainer = Color(0xFF0B3A57), onPrimaryContainer = Color(0xFFCDEBFF),
    secondary = Color(0xFF90CAF9), onSecondary = Color(0xFF0A1B2E),
    background = Color(0xFF0A1020), onBackground = Color(0xFFE3EAF4),
    surface = Color(0xFF0F1830), onSurface = Color(0xFFE3EAF4),
    surfaceVariant = Color(0xFF17233F), onSurfaceVariant = Color(0xFFA9B6CC),
    outline = Color(0xFF3A4A6B), outlineVariant = Color(0xFF26324F),
    error = Color(0xFFFF6B6B), onError = Color(0xFF3B0A0A),
    errorContainer = Color(0xFF4A1620), onErrorContainer = Color(0xFFFFD9D9),
)

object StbColors {
    val ok = Color(0xFF66D18F)
    val warn = Color(0xFFFFB74D)
    val test = Color(0xFFB388FF)
    val delayed = Color(0xFFFFB74D)
}

@Composable
fun StbTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = StbDark, content = content)
