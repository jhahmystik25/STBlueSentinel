package net.seatrace.stbluesentinel.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Report
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import net.seatrace.stbluesentinel.core.model.Severity
import net.seatrace.stbluesentinel.ui.theme.StbColors

data class SeverityColors(val container: Color, val content: Color)

fun severityColors(s: Severity): SeverityColors = when (s) {
    Severity.CRITICAL -> SeverityColors(Color(0xFFB3261E), Color.White)
    Severity.HIGH -> SeverityColors(Color(0xFFE65100), Color.White)
    Severity.MEDIUM -> SeverityColors(Color(0xFFF9A825), Color(0xFF1A1200))
    Severity.LOW -> SeverityColors(Color(0xFF1E6FD9), Color.White)
    Severity.INFO -> SeverityColors(Color(0xFF546E7A), Color.White)
}

/** Distinct icon per severity: colour is never the only signal (text label + icon + weight always accompany it). */
fun severityIcon(s: Severity): ImageVector = when (s) {
    Severity.CRITICAL -> Icons.Filled.Report
    Severity.HIGH -> Icons.Filled.Warning
    Severity.MEDIUM -> Icons.Filled.ErrorOutline
    Severity.LOW -> Icons.Filled.Info
    Severity.INFO -> Icons.Filled.Notifications
}

@Composable
fun SeverityBadge(severity: Severity, large: Boolean = false, modifier: Modifier = Modifier) {
    val c = severityColors(severity)
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp)).background(c.container)
            .padding(horizontal = if (large) 12.dp else 8.dp, vertical = if (large) 6.dp else 3.dp)
            .clearAndSetSemantics { contentDescription = "Severity ${severity.label}" },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(severityIcon(severity), contentDescription = null, tint = c.content, modifier = Modifier.size(if (large) 22.dp else 16.dp))
        Spacer(Modifier.width(6.dp))
        Text(
            severity.label, color = c.content, fontWeight = FontWeight.Bold,
            style = if (large) MaterialTheme.typography.titleMedium else MaterialTheme.typography.labelLarge,
        )
    }
}

@Composable
fun TagChip(text: String, color: Color, modifier: Modifier = Modifier) {
    Text(
        text, color = color, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold,
        modifier = modifier.clip(RoundedCornerShape(4.dp)).background(color.copy(alpha = 0.14f)).padding(horizontal = 6.dp, vertical = 2.dp),
    )
}

@Composable
fun SectionCard(title: String, modifier: Modifier = Modifier, border: BorderStroke? = null, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = border ?: BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title.uppercase(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

/** A status line: icon + words (✓ / ⚠), so state is readable without colour. */
@Composable
fun StatusLine(text: String, ok: Boolean, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(
            if (ok) Icons.Filled.CheckCircle else Icons.Filled.WarningAmber,
            contentDescription = if (ok) "OK" else "Needs attention",
            tint = if (ok) StbColors.ok else StbColors.warn, modifier = Modifier.size(20.dp),
        )
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun KeyValueRow(key: String, value: String, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(key, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(120.dp))
        Text(value, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
    }
}

@Composable
fun Banner(text: String, container: Color, content: Color, modifier: Modifier = Modifier) {
    Text(
        text, color = content, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall,
        modifier = modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(container).padding(12.dp),
    )
}
