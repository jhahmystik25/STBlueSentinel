package net.seatrace.stbluesentinel.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import net.seatrace.stbluesentinel.core.security.SaveResult
import net.seatrace.stbluesentinel.core.security.SecretStore
import net.seatrace.stbluesentinel.receiver.ReceiverUrlValidator
import net.seatrace.stbluesentinel.receiver.UrlValidation

/**
 * What the UI is allowed to know about configuration. Deliberately has NO secret field: the signing secret
 * can be written and cleared through here but is never read back into UI state.
 */
data class ConfigSnapshot(val receiverUrl: String?, val receiverUrlValid: Boolean, val hasSecret: Boolean)

class ConfigRepository(context: Context, private val secrets: SecretStore) {
    private val prefs = context.applicationContext.getSharedPreferences("stb_config", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(read())
    val state: StateFlow<ConfigSnapshot> = _state.asStateFlow()

    private fun read(): ConfigSnapshot {
        val url = prefs.getString(K_URL, null)
        return ConfigSnapshot(url, url != null && ReceiverUrlValidator.validate(url) is UrlValidation.Valid, secrets.hasSecret())
    }

    /** Only a valid wss:// address is ever persisted. */
    fun saveReceiverUrl(input: String): UrlValidation {
        val result = ReceiverUrlValidator.validate(input)
        if (result is UrlValidation.Valid) prefs.edit().putString(K_URL, result.normalized).apply()
        _state.value = read()
        return result
    }

    fun saveSecret(input: String): SaveResult = secrets.save(input).also { _state.value = read() }
    fun clearSecret() { secrets.clear(); _state.value = read() }

    fun resetAll() {
        prefs.edit().clear().apply()
        secrets.clear()
        _state.value = read()
    }

    private companion object { const val K_URL = "receiver_url" }
}
