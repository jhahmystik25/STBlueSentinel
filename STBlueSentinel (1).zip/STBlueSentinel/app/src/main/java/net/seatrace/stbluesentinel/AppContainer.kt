package net.seatrace.stbluesentinel

import android.content.Context
import net.seatrace.stbluesentinel.core.pipeline.AlertProcessor
import net.seatrace.stbluesentinel.data.ConfigRepository
import net.seatrace.stbluesentinel.receiver.ReceiverChecker
import net.seatrace.stbluesentinel.core.pipeline.AlertVerifier
import net.seatrace.stbluesentinel.core.security.KeystoreSecretStore
import net.seatrace.stbluesentinel.core.security.SecretStore
import net.seatrace.stbluesentinel.data.db.RejectionEntity
import net.seatrace.stbluesentinel.data.db.StbDatabase
import net.seatrace.stbluesentinel.notifications.AndroidAlertNotifier
import net.seatrace.stbluesentinel.notifications.SharedPrefsNotificationPreferences
import net.seatrace.stbluesentinel.push.DeviceStore

/**
 * Manual dependency container (no DI framework: the graph is tiny). Everything is lazy and
 * Activity-free, so the FCM service can use it when the process was started only to deliver an alert.
 */
class AppContainer(
    context: Context,
    secretStoreFactory: (Context) -> SecretStore = { KeystoreSecretStore(it) },
) {
    private val storeFactory = secretStoreFactory
    private val app = context.applicationContext

    val database: StbDatabase by lazy { StbDatabase.get(app) }
    val secretStore: SecretStore by lazy { storeFactory(app) }
    val notificationPrefs: SharedPrefsNotificationPreferences by lazy { SharedPrefsNotificationPreferences(app) }
    val deviceStore: DeviceStore by lazy { DeviceStore(app) }
    val config: ConfigRepository by lazy { ConfigRepository(app, secretStore) }
    val receiverChecker: ReceiverChecker by lazy { ReceiverChecker() }

    val processor: AlertProcessor by lazy {
        AlertProcessor(
            verifier = AlertVerifier(secretProvider = { secretStore.load() }),
            writer = { alert -> database.alertDao().insertIgnore(alert) },
            rejections = { alertId, reason, at ->
                database.rejectionDao().insert(RejectionEntity(alertId = alertId, reason = reason.name, receivedAt = at))
                database.rejectionDao().prune(200)
            },
            notifier = AndroidAlertNotifier(app),
            prefs = notificationPrefs,
        )
    }
}
