package net.seatrace.stbluesentinel.data.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * One stored BlueSentinel alert. Only alerts whose HMAC verified are ever stored (`verified` is
 * therefore always true; it is kept as an explicit column for auditability).
 *
 * `delivery_status` is VERIFIED (arrived inside the live window, may have notified) or STALE
 * (validly signed but delayed past 15 minutes: history only, never notified as a live alert).
 *
 * Times are epoch milliseconds (UTC). Absent optional values are NULL - never placeholders.
 * `alert_id` is UNIQUE: that constraint is the dedupe guarantee against SeaTracePro retries.
 */
@Entity(
    tableName = "alerts",
    indices = [
        Index(value = ["alert_id"], unique = true),
        Index(value = ["received_at"]),
        Index(value = ["severity"]),
    ],
)
data class AlertEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "alert_id") val alertId: String,
    @ColumnInfo(name = "alert_type") val alertType: String,
    val severity: String,
    val title: String,
    val message: String?,
    @ColumnInfo(name = "schema_version") val schemaVersion: String?,
    val source: String?,
    val product: String?,
    @ColumnInfo(name = "timestamp_utc") val timestampUtc: Long?,
    @ColumnInfo(name = "created_utc") val createdUtc: Long?,
    @ColumnInfo(name = "received_at") val receivedAt: Long,
    val verified: Boolean,
    @ColumnInfo(name = "delivery_status") val deliveryStatus: String,
    /** Header signing time (epoch seconds) and how old it was when this device processed it. */
    @ColumnInfo(name = "signed_at") val signedAt: Long,
    @ColumnInfo(name = "delivery_age_seconds") val deliveryAgeSeconds: Long,
    @ColumnInfo(name = "test_alert") val testAlert: Boolean,
    @ColumnInfo(name = "test_notice") val testNotice: String?,

    @ColumnInfo(name = "ship_id") val shipId: Long?,
    val mmsi: Long?,
    @ColumnInfo(name = "ship_name") val shipName: String?,
    val imo: Long?,
    val latitude: Double?,
    val longitude: Double?,
    @ColumnInfo(name = "speed_knots") val speedKnots: Double?,
    @ColumnInfo(name = "course_deg") val courseDeg: Double?,
    @ColumnInfo(name = "last_seen_utc") val lastSeenUtc: Long?,

    @ColumnInfo(name = "threat_state") val threatState: String?,
    @ColumnInfo(name = "area_label") val areaLabel: String?,
    @ColumnInfo(name = "nearest_incident_km") val nearestIncidentKm: Double?,
    @ColumnInfo(name = "incidents_within_radius") val incidentsWithinRadius: Int?,
    @ColumnInfo(name = "radius_km") val radiusKm: Double?,
    @ColumnInfo(name = "dataset_latest_incident_date") val datasetLatestIncidentDate: String?,
    @ColumnInfo(name = "nearest_incident_date") val nearestIncidentDate: String?,
    @ColumnInfo(name = "nearest_incident_attack_type") val nearestIncidentAttackType: String?,
    @ColumnInfo(name = "nearest_incident_country") val nearestIncidentCountry: String?,
    @ColumnInfo(name = "nearest_incident_location") val nearestIncidentLocation: String?,
    @ColumnInfo(name = "nearest_incident_distance_km") val nearestIncidentDistanceKm: Double?,

    /** Exact frame text as received, for diagnostics. Contains no secret (the secret is never in the frame). */
    @ColumnInfo(name = "raw_payload") val rawPayload: String,
    val read: Boolean = false,
)

/** Internal audit of refused deliveries: reason + alert id only. No headers, payload or secret. */
@Entity(tableName = "rejections", indices = [Index(value = ["received_at"])])
data class RejectionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(name = "alert_id") val alertId: String?,
    val reason: String,
    @ColumnInfo(name = "received_at") val receivedAt: Long,
)
