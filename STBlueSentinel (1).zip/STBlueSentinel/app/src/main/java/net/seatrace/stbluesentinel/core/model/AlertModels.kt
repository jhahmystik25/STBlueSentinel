package net.seatrace.stbluesentinel.core.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Wire model for BlueSentinel schema 1.0, exactly as documented. Every field is nullable/optional
 * because the sender OMITS unknown values (nothing is ever sent as a placeholder), and unknown
 * extra fields are ignored by the parser configuration so additive schema changes don't break us.
 */
@Serializable
data class AlertPayload(
    @SerialName("schema_version") val schemaVersion: String? = null,
    val source: String? = null,
    val product: String? = null,
    val event: String? = null,
    @SerialName("alert_id") val alertId: String? = null,
    @SerialName("alert_type") val alertType: String? = null,
    val severity: String? = null,
    val title: String? = null,
    val message: String? = null,
    @SerialName("timestamp_utc") val timestampUtc: String? = null,
    @SerialName("created_utc") val createdUtc: String? = null,
    /** Present (true) only on notification_test alerts. */
    val test: Boolean? = null,
    @SerialName("test_notice") val testNotice: String? = null,
    val vessel: VesselPayload? = null,
    val threat: ThreatPayload? = null,
) {
    val isTest: Boolean get() = test == true || alertType == AlertType.NOTIFICATION_TEST.wire
}

@Serializable
data class VesselPayload(
    @SerialName("ship_id") val shipId: Long? = null,
    val mmsi: Long? = null,
    @SerialName("ship_name") val shipName: String? = null,
    val imo: Long? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    @SerialName("speed_knots") val speedKnots: Double? = null,
    @SerialName("course_deg") val courseDeg: Double? = null,
    @SerialName("last_seen_utc") val lastSeenUtc: String? = null,
)

@Serializable
data class ThreatPayload(
    val state: String? = null,
    @SerialName("area_label") val areaLabel: String? = null,
    @SerialName("nearest_incident_km") val nearestIncidentKm: Double? = null,
    @SerialName("incidents_within_radius") val incidentsWithinRadius: Int? = null,
    @SerialName("radius_km") val radiusKm: Double? = null,
    @SerialName("dataset_latest_incident_date") val datasetLatestIncidentDate: String? = null,
    @SerialName("nearest_incident") val nearestIncident: NearestIncidentPayload? = null,
)

@Serializable
data class NearestIncidentPayload(
    val date: String? = null,
    @SerialName("attack_type") val attackType: String? = null,
    @SerialName("nearest_country") val nearestCountry: String? = null,
    @SerialName("location_description") val locationDescription: String? = null,
    @SerialName("distance_km") val distanceKm: Double? = null,
)
