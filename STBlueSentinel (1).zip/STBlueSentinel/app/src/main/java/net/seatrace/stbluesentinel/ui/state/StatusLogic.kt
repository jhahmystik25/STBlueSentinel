package net.seatrace.stbluesentinel.ui.state

import net.seatrace.stbluesentinel.notifications.NotificationAccess
import net.seatrace.stbluesentinel.push.PushStatus
import net.seatrace.stbluesentinel.receiver.CheckState
import net.seatrace.stbluesentinel.receiver.ReceiverCheckResult

enum class SecurityLevel(val label: String) {
    SECURE("SECURE"),
    ATTENTION("ATTENTION NEEDED"),
    NOT_CONFIGURED("NOT CONFIGURED"),
}

data class StatusLine(val text: String, val ok: Boolean)
data class SecurityStatus(val level: SecurityLevel, val lines: List<StatusLine>)

/** Receiver-gateway status labels from the brief. "Connected" means the endpoint answered a reachability check - nothing more. */
enum class ReceiverStatus(val label: String) {
    NOT_CONFIGURED("Not configured"),
    CONNECTING("Connecting"),
    CONNECTED("Connected"),
    WAITING("Waiting for alerts"),
    DISCONNECTED("Disconnected"),
    CONNECTION_ERROR("Connection error"),
    VERIFICATION_FAILED("Security verification failed"),
}

object StatusLogic {
    /**
     * SECURE is claimed only when verification is configured AND the alert path to this phone is actually
     * ready (push active, notifications allowed). Otherwise the user is told exactly what is missing.
     */
    fun security(receiverUrlValid: Boolean, hasSecret: Boolean, push: PushStatus, notifications: NotificationAccess): SecurityStatus {
        val backgroundReady = push == PushStatus.ACTIVE && notifications == NotificationAccess.GRANTED
        val level = when {
            !receiverUrlValid || !hasSecret -> SecurityLevel.NOT_CONFIGURED
            !backgroundReady -> SecurityLevel.ATTENTION
            else -> SecurityLevel.SECURE
        }
        val problem = when {
            push == PushStatus.NOT_CONFIGURED -> "push is not configured in this build"
            push == PushStatus.TOKEN_PENDING -> "waiting for the push token"
            notifications == NotificationAccess.CHANNEL_BLOCKED -> "the BlueSentinel Alerts channel is silenced"
            notifications != NotificationAccess.GRANTED -> "notifications are disabled"
            else -> ""
        }
        return SecurityStatus(
            level,
            listOf(
                StatusLine(if (hasSecret) "HMAC verification enabled" else "HMAC verification needs a signing secret", hasSecret),
                StatusLine("Replay protection enabled", true),
                StatusLine("Duplicate protection enabled", true),
                StatusLine(if (backgroundReady) "Background alerts enabled" else "Background alerts need attention: $problem", backgroundReady),
            ),
        )
    }

    fun receiverStatus(configured: Boolean, check: CheckState, recentSignatureFailure: Boolean): ReceiverStatus = when {
        !configured -> ReceiverStatus.NOT_CONFIGURED
        check is CheckState.Checking -> ReceiverStatus.CONNECTING
        recentSignatureFailure -> ReceiverStatus.VERIFICATION_FAILED
        check is CheckState.Done -> when (check.result) {
            is ReceiverCheckResult.Reachable -> ReceiverStatus.CONNECTED
            ReceiverCheckResult.Timeout -> ReceiverStatus.DISCONNECTED
            else -> ReceiverStatus.CONNECTION_ERROR
        }
        else -> ReceiverStatus.WAITING
    }

    fun pushLabel(push: PushStatus): String = when (push) {
        PushStatus.ACTIVE -> "Active"
        PushStatus.TOKEN_PENDING -> "Starting (waiting for token)"
        PushStatus.NOT_CONFIGURED -> "Not configured"
    }

    fun standbyBucketLabel(bucket: Int?): String = when {
        bucket == null -> "Unknown"
        bucket <= 10 -> "Active"
        bucket <= 20 -> "Working set"
        bucket <= 30 -> "Frequent"
        bucket <= 40 -> "Rare"
        bucket <= 45 -> "Restricted"
        else -> "Never"
    }

    /** Rare/Restricted buckets can delay or limit background work; high-priority FCM is the most resilient path but is not exempt. */
    fun isStandbyConcerning(bucket: Int?): Boolean = bucket != null && bucket >= 40
}
