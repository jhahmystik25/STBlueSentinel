package net.seatrace.stbluesentinel.push

enum class PushStatus { ACTIVE, TOKEN_PENDING, NOT_CONFIGURED }
