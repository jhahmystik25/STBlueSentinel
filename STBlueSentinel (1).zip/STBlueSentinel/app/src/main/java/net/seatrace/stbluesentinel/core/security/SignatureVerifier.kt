package net.seatrace.stbluesentinel.core.security

import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

enum class SignatureResult { VALID, MISSING, MALFORMED, WRONG_ALGORITHM, MISMATCH }

/**
 * BlueSentinel signature check, exactly as documented:
 *
 *     X-SeaTrace-Signature = "sha256=" + hex( HMAC_SHA256(key, timestamp + "." + frame_text) )
 *
 * Rules enforced here:
 *  - The signing input is built from the EXACT received header string and the EXACT received frame
 *    bytes. The JSON is never parsed/re-serialised/normalised before verification.
 *  - The key is the signing secret's UTF-8 text (as with Node's createHmac('sha256', keyString)).
 *    It is NOT hex-decoded.
 *  - The comparison is constant-time ([MessageDigest.isEqual]).
 */
object SignatureVerifier {
    private const val ALGORITHM = "HmacSHA256"
    private const val PREFIX_ALGORITHM = "sha256"
    private const val HEX_LENGTH = 64
    private val HEX = Regex("[0-9a-fA-F]{$HEX_LENGTH}")

    fun verify(secret: ByteArray, timestamp: String, frame: ByteArray, signatureHeader: String?): SignatureResult {
        if (signatureHeader.isNullOrBlank()) return SignatureResult.MISSING
        val eq = signatureHeader.indexOf('=')
        if (eq <= 0) return SignatureResult.MALFORMED
        if (signatureHeader.substring(0, eq) != PREFIX_ALGORITHM) return SignatureResult.WRONG_ALGORITHM
        val hex = signatureHeader.substring(eq + 1)
        if (!HEX.matches(hex)) return SignatureResult.MALFORMED

        val provided = hexToBytes(hex)
        val expected = computeMac(secret, timestamp, frame)
        return if (MessageDigest.isEqual(expected, provided)) SignatureResult.VALID else SignatureResult.MISMATCH
    }

    /** Lower-case hex HMAC. Used by tests and the reference gateway's cross-check vectors. */
    fun computeHex(secret: ByteArray, timestamp: String, frame: ByteArray): String =
        computeMac(secret, timestamp, frame).joinToString("") { "%02x".format(it) }

    private fun computeMac(secret: ByteArray, timestamp: String, frame: ByteArray): ByteArray {
        require(secret.isNotEmpty()) { "signing secret must not be empty" }
        val mac = Mac.getInstance(ALGORITHM)
        mac.init(SecretKeySpec(secret, ALGORITHM))
        // Equivalent to HMAC(key, timestamp + "." + frame) without building a combined string.
        mac.update(timestamp.toByteArray(Charsets.UTF_8))
        mac.update('.'.code.toByte())
        mac.update(frame)
        return mac.doFinal()
    }

    private fun hexToBytes(hex: String): ByteArray =
        ByteArray(hex.length / 2) { i -> hex.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
}
