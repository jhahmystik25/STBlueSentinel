package net.seatrace.stbluesentinel.core.pipeline

import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import net.seatrace.stbluesentinel.core.model.AlertPayload
import net.seatrace.stbluesentinel.core.model.DeliveryStatus
import net.seatrace.stbluesentinel.core.model.Severity
import net.seatrace.stbluesentinel.core.security.RejectReason
import net.seatrace.stbluesentinel.core.security.SignatureResult
import net.seatrace.stbluesentinel.core.security.SignatureVerifier
import net.seatrace.stbluesentinel.core.security.TimestampPolicy
import net.seatrace.stbluesentinel.core.security.TimestampStatus
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction

sealed interface VerificationOutcome {
    /** HMAC valid + schema valid. [status] is VERIFIED (live) or STALE (history only). */
    class Accepted(
        val status: DeliveryStatus,
        val alert: AlertPayload,
        /** The exact received frame text (stored for diagnostics; contains no secret). */
        val rawFrame: String,
        val signedAtEpochSeconds: Long,
        val ageSeconds: Long,
    ) : VerificationOutcome

    class Rejected(val reason: RejectReason, val alertId: String?) : VerificationOutcome {
        val status: DeliveryStatus get() = DeliveryStatus.REJECTED
    }
}

/**
 * Pure verification pipeline (no Android, no I/O, no logging):
 *
 *   frame size -> required headers -> timestamp policy -> HMAC (exact bytes) -> UTF-8 -> JSON
 *   -> schema validation -> header/body alert_id agreement
 *
 * Dedupe, persistence and notification happen AFTER this, in the AlertProcessor (step 3), and only
 * for [VerificationOutcome.Accepted]. Nothing here can produce VERIFIED without a successful HMAC check.
 */
class AlertVerifier(
    /** Returns the secret bytes, or null if not configured. The verifier zeroes the array after use. */
    private val secretProvider: () -> ByteArray?,
    private val nowEpochSeconds: () -> Long = { System.currentTimeMillis() / 1000L },
) {
    fun verify(envelope: AlertEnvelope): VerificationOutcome {
        val headerAlertId = envelope.alertId?.takeIf { it.isNotBlank() && it.length <= MAX_ALERT_ID_LENGTH }
        fun reject(reason: RejectReason) = VerificationOutcome.Rejected(reason, headerAlertId)

        // 1. Frame presence and size (documented limit: 32 KB text frame)
        val frame = envelope.frame
        if (frame == null || frame.isEmpty()) return reject(RejectReason.FRAME_MISSING)
        if (frame.size > MAX_FRAME_BYTES) return reject(RejectReason.FRAME_TOO_LARGE)

        // 2. Required headers
        if (envelope.event == null) return reject(RejectReason.MISSING_HEADER)
        if (envelope.event != EXPECTED_EVENT) return reject(RejectReason.WRONG_EVENT)
        if (headerAlertId == null) return reject(RejectReason.MISSING_HEADER)
        if (envelope.signature.isNullOrBlank()) return reject(RejectReason.SIGNATURE_MISSING)

        // 3. Client-side timestamp policy (independent of the gateway's strict 300 s window)
        val ts = TimestampPolicy.evaluate(envelope.timestamp, nowEpochSeconds())
        if (ts.status == TimestampStatus.REJECTED) return reject(ts.reason ?: RejectReason.INVALID_TIMESTAMP)
        val timestampHeader = envelope.timestamp!! // non-null: policy accepted it

        // 4. HMAC over the EXACT received bytes - before any JSON parsing
        val secret = secretProvider() ?: return reject(RejectReason.SECRET_NOT_CONFIGURED)
        val signature = try {
            SignatureVerifier.verify(secret, timestampHeader, frame, envelope.signature)
        } finally {
            secret.fill(0)
        }
        when (signature) {
            SignatureResult.VALID -> Unit
            SignatureResult.MISSING -> return reject(RejectReason.SIGNATURE_MISSING)
            SignatureResult.MALFORMED -> return reject(RejectReason.SIGNATURE_MALFORMED)
            SignatureResult.WRONG_ALGORITHM -> return reject(RejectReason.SIGNATURE_WRONG_ALGORITHM)
            SignatureResult.MISMATCH -> return reject(RejectReason.SIGNATURE_MISMATCH)
        }

        // 5. Strict UTF-8 decode, then parse (unknown fields ignored)
        val text = decodeUtf8Strict(frame) ?: return reject(RejectReason.MALFORMED_JSON)
        val alert = try {
            PARSER.decodeFromString(AlertPayload.serializer(), text)
        } catch (_: SerializationException) {
            return reject(RejectReason.MALFORMED_JSON)
        } catch (_: IllegalArgumentException) {
            return reject(RejectReason.MALFORMED_JSON)
        }

        // 6. Schema validation
        schemaProblem(alert, headerAlertId)?.let { return reject(it) }

        // 7. Final disposition. VERIFIED only exists after the HMAC check above succeeded.
        val status = if (ts.status == TimestampStatus.WITHIN_LIVE_WINDOW) DeliveryStatus.VERIFIED else DeliveryStatus.STALE
        return VerificationOutcome.Accepted(status, alert, text, ts.signedAtEpochSeconds!!, ts.ageSeconds!!)
    }

    private fun schemaProblem(a: AlertPayload, headerAlertId: String): RejectReason? {
        if (a.schemaVersion?.substringBefore('.') != SUPPORTED_MAJOR) return RejectReason.UNSUPPORTED_SCHEMA
        if (a.source != EXPECTED_SOURCE || a.product != EXPECTED_PRODUCT || a.event != EXPECTED_EVENT) return RejectReason.INVALID_SCHEMA
        val id = a.alertId
        if (id.isNullOrBlank() || id.length > MAX_ALERT_ID_LENGTH) return RejectReason.INVALID_SCHEMA
        if (id != headerAlertId) return RejectReason.ALERT_ID_MISMATCH
        if (a.alertType.isNullOrBlank()) return RejectReason.INVALID_SCHEMA
        if (Severity.fromWire(a.severity) == null) return RejectReason.INVALID_SCHEMA
        if (a.title.isNullOrBlank()) return RejectReason.INVALID_SCHEMA
        return null
    }

    private fun decodeUtf8Strict(bytes: ByteArray): String? = try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(bytes)).toString()
    } catch (_: CharacterCodingException) {
        null
    }

    companion object {
        const val MAX_FRAME_BYTES = 32 * 1024
        const val MAX_ALERT_ID_LENGTH = 128
        const val EXPECTED_EVENT = "vessel_alert"
        const val EXPECTED_SOURCE = "seatracepro"
        const val EXPECTED_PRODUCT = "bluesentinel"
        const val SUPPORTED_MAJOR = "1"

        /** Applied only AFTER the HMAC check, so leniency cannot weaken authenticity. */
        private val PARSER = Json {
            ignoreUnknownKeys = true
            isLenient = true
            coerceInputValues = true
        }
    }
}
