package net.seatrace.stbluesentinel.notifications

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object NotificationAccessChecker {
    fun evaluate(context: Context, activity: Activity?, alreadyRequested: Boolean): NotificationAccess {
        val appEnabled = NotificationManagerCompat.from(context).areNotificationsEnabled()
        if (appEnabled) {
            return if (NotificationChannels.isBlocked(context, NotificationChannels.ALERTS)) NotificationAccess.CHANNEL_BLOCKED
            else NotificationAccess.GRANTED
        }
        if (Build.VERSION.SDK_INT < 33) return NotificationAccess.OPEN_SETTINGS
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (granted) return NotificationAccess.OPEN_SETTINGS // permission held but notifications switched off in Settings
        if (!alreadyRequested) return NotificationAccess.CAN_REQUEST
        val canAskAgain = activity != null &&
            ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.POST_NOTIFICATIONS)
        return if (canAskAgain) NotificationAccess.CAN_REQUEST else NotificationAccess.OPEN_SETTINGS
    }

    /** Opens this app's notification settings page. */
    fun settingsIntent(context: Context): Intent =
        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
