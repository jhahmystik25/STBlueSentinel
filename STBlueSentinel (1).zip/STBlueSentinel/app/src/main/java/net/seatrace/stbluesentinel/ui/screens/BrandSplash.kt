package net.seatrace.stbluesentinel.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import net.seatrace.stbluesentinel.R

/** Brief branded hand-off after the system splash: the supplied BlueSentinel logo, prominent, with the product line. No animation. */
@Composable
fun BrandSplash() {
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        // The supplied artwork has an opaque white background, so it is presented on a rounded white panel.
        Box(Modifier.clip(RoundedCornerShape(28.dp)).background(Color.White)) {
            Image(painterResource(R.drawable.bluesentinel_logo), stringResource(R.string.cd_bluesentinel_logo), Modifier.size(280.dp))
        }
        Text(stringResource(R.string.brand_bluesentinel), Modifier.padding(top = 28.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Text(stringResource(R.string.brand_by_seatrace), Modifier.padding(top = 4.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
