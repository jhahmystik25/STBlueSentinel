package net.seatrace.stbluesentinel.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [AlertEntity::class, RejectionEntity::class], version = 1, exportSchema = false)
abstract class StbDatabase : RoomDatabase() {
    abstract fun alertDao(): AlertDao
    abstract fun rejectionDao(): RejectionDao

    companion object {
        const val NAME = "stbluesentinel.db"

        @Volatile private var instance: StbDatabase? = null

        /** Test hook: drops the singleton so each Robolectric test starts from a fresh database file. */
        @androidx.annotation.VisibleForTesting
        fun resetForTesting() = synchronized(this) { instance?.close(); instance = null }

        /** Process-wide singleton, safe to call from the FCM service while no UI exists. */
        fun get(context: Context): StbDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, StbDatabase::class.java, NAME)
                .build()
                .also { instance = it }
        }
    }
}
