package net.seatrace.stbluesentinel.ui.vm

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import net.seatrace.stbluesentinel.AppContainer
import net.seatrace.stbluesentinel.StbApplication
import net.seatrace.stbluesentinel.core.model.Severity
import net.seatrace.stbluesentinel.core.security.SaveResult
import net.seatrace.stbluesentinel.data.db.AlertEntity
import net.seatrace.stbluesentinel.data.db.SeverityCount
import net.seatrace.stbluesentinel.notifications.BackgroundHealth
import net.seatrace.stbluesentinel.notifications.NotificationAccess
import net.seatrace.stbluesentinel.notifications.NotificationAccessChecker
import net.seatrace.stbluesentinel.push.PushSetup
import net.seatrace.stbluesentinel.push.PushStatus
import net.seatrace.stbluesentinel.receiver.UrlValidation
import net.seatrace.stbluesentinel.ui.state.AlertCounts
import net.seatrace.stbluesentinel.ui.state.AlertFilter
import net.seatrace.stbluesentinel.ui.state.ReceiverStatus
import net.seatrace.stbluesentinel.ui.state.SecurityStatus
import net.seatrace.stbluesentinel.ui.state.StatusLogic
import net.seatrace.stbluesentinel.ui.state.ViewFilter

private const val STOP_TIMEOUT_MS = 5_000L

abstract class ContainerViewModel(app: Application) : AndroidViewModel(app) {
    protected val c: AppContainer get() = (getApplication<Application>() as StbApplication).container
}

data class HealthState(val push: PushStatus, val notifications: NotificationAccess, val background: BackgroundHealth) {
    val backgroundReady: Boolean get() = push == PushStatus.ACTIVE && notifications == NotificationAccess.GRANTED
}

private fun readHealth(app: Application, c: AppContainer) = HealthState(
    push = PushSetup.status(app, c.deviceStore),
    // No Activity here: only "granted or not" matters for summaries (the permission card does its own, Activity-aware check).
    notifications = NotificationAccessChecker.evaluate(app, null, c.notificationPrefs.permissionRequested),
    background = BackgroundHealth.read(app),
)

internal fun foldCounts(rows: List<SeverityCount>): Map<Severity, Int> = AlertCounts.fold(rows.map { it.severity to it.count })

class DashboardViewModel(app: Application) : ContainerViewModel(app) {
    private val alerts = c.database.alertDao()
    private val rejections = c.database.rejectionDao()

    private val _health = MutableStateFlow(readHealth(app, c))
    val health: StateFlow<HealthState> = _health.asStateFlow()
    fun refresh() { _health.value = readHealth(getApplication(), c) }
    val permissionPrefs get() = c.notificationPrefs

    val counts: StateFlow<Map<Severity, Int>> =
        alerts.observeSeverityCounts().map(::foldCounts).stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), foldCounts(emptyList()))
    val latest: StateFlow<AlertEntity?> = alerts.observeLatestReal().stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)
    val unread: StateFlow<Int> = alerts.observeUnreadCount().stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), 0)

    val security: StateFlow<SecurityStatus> = combine(c.config.state, _health) { cfg, h ->
        StatusLogic.security(cfg.receiverUrlValid, cfg.hasSecret, h.push, h.notifications)
    }.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
        StatusLogic.security(c.config.state.value.receiverUrlValid, c.config.state.value.hasSecret, _health.value.push, _health.value.notifications),
    )

    val receiverStatus: StateFlow<ReceiverStatus> =
        combine(c.config.state, c.receiverChecker.state, latest, rejections.observeRecent(1)) { cfg, check, last, rej ->
            // A signature rejection newer than the last accepted alert is surfaced as "Security verification failed".
            val sigFail = rej.firstOrNull()?.let { it.reason.startsWith("SIGNATURE_") && (last == null || it.receivedAt > last.receivedAt) } ?: false
            StatusLogic.receiverStatus(cfg.receiverUrlValid, check, sigFail)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), ReceiverStatus.NOT_CONFIGURED)
}

class HistoryViewModel(app: Application) : ContainerViewModel(app) {
    private val dao = c.database.alertDao()
    private val _filter = MutableStateFlow(AlertFilter())
    val filter: StateFlow<AlertFilter> = _filter.asStateFlow()

    val alerts: StateFlow<List<AlertEntity>> = combine(dao.observeAll(), _filter) { all, f ->
        all.filter { f.matches(it.severity, it.testAlert, it.deliveryStatus) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())

    val counts: StateFlow<Map<Severity, Int>> =
        dao.observeSeverityCounts().map(::foldCounts).stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), foldCounts(emptyList()))

    fun toggleSeverity(s: Severity) { _filter.value = _filter.value.toggle(s) }
    fun clearSeverities() { _filter.value = _filter.value.copy(severities = emptySet()) }
    fun setView(v: ViewFilter) { _filter.value = _filter.value.copy(view = v) }
    fun markAllRead() { viewModelScope.launch(Dispatchers.IO) { dao.markAllRead() } }
    fun clearAll() { viewModelScope.launch(Dispatchers.IO) { dao.clearAll() } }
}

class DetailViewModel(app: Application, handle: SavedStateHandle) : ContainerViewModel(app) {
    private val id: Long = handle.get<Long>("id") ?: -1L
    private val dao = c.database.alertDao()
    val alert: StateFlow<AlertEntity?> = dao.observeById(id).stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), null)
    init { viewModelScope.launch(Dispatchers.IO) { dao.markRead(id) } } // opening an alert marks it read
}

class SettingsViewModel(app: Application) : ContainerViewModel(app) {
    val config = c.config.state
    val checkState = c.receiverChecker.state
    val prefs = c.notificationPrefs

    private val _health = MutableStateFlow(readHealth(app, c))
    val health: StateFlow<HealthState> = _health.asStateFlow()
    fun refresh() { _health.value = readHealth(getApplication(), c) }

    fun saveUrl(text: String): UrlValidation = c.config.saveReceiverUrl(text)
    fun saveSecret(text: String): SaveResult = c.config.saveSecret(text)
    fun clearSecret() = c.config.clearSecret()
    fun testConnection() {
        val url = config.value.receiverUrl ?: return
        viewModelScope.launch { c.receiverChecker.check(url) }
    }

    val deviceId: String get() = c.deviceStore.deviceId
    val fcmToken: String? get() = c.deviceStore.fcmToken

    fun clearAlerts() { viewModelScope.launch(Dispatchers.IO) { c.database.alertDao().clearAll() } }

    /** Wipes secret, URL, preferences, alert history, rejection log and device identity. A fresh push token is then requested. */
    fun resetApplication() {
        viewModelScope.launch(Dispatchers.IO) {
            c.database.clearAllTables()
            c.config.resetAll()
            c.notificationPrefs.clear()
            c.deviceStore.clear()
            PushSetup.refreshToken(getApplication(), c.deviceStore)
        }
    }
}

class HelpViewModel(app: Application) : ContainerViewModel(app) {
    private val _health = MutableStateFlow(readHealth(app, c))
    val health: StateFlow<HealthState> = _health.asStateFlow()
    fun refresh() { _health.value = readHealth(getApplication(), c) }
    val rejections = c.database.rejectionDao().observeRecent(10).stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyList())
    val tokenPresent: Boolean get() = !c.deviceStore.fcmToken.isNullOrEmpty()
}
