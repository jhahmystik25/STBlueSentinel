package net.seatrace.stbluesentinel.core.security

sealed interface SaveResult {
    data object Saved : SaveResult
    data object Invalid : SaveResult
    data object StorageError : SaveResult
}

/** Format rules for the BlueSentinel signing secret as typed/pasted by the user. */
object SecretPolicy {
    const val MIN_LENGTH = 16
    const val MAX_LENGTH = 256

    /** Trims surrounding whitespace/newlines from a paste; returns null if the result is not an acceptable secret. */
    fun normalize(input: String): String? {
        val s = input.trim()
        if (s.length !in MIN_LENGTH..MAX_LENGTH) return null
        if (s.any { it.code !in 0x21..0x7E }) return null // printable ASCII, no inner whitespace
        return s
    }
}

/**
 * Holds the one BlueSentinel signing secret (V1). Contract:
 *  - the secret is only ever readable by [load] for HMAC verification - the UI never reads it back;
 *  - never logged, never sent anywhere, never placed in a notification, URL or FCM payload.
 */
interface SecretStore {
    fun hasSecret(): Boolean
    fun save(secret: String): SaveResult
    /** Returns a fresh copy of the secret bytes (caller must zero them), or null if none/unreadable. */
    fun load(): ByteArray?
    fun clear()
}
