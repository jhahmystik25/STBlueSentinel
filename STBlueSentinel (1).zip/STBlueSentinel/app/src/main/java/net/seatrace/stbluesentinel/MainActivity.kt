package net.seatrace.stbluesentinel

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.setValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import net.seatrace.stbluesentinel.notifications.AppIntents
import net.seatrace.stbluesentinel.ui.StbApp

class MainActivity : ComponentActivity() {
    /** Row id of the alert a tapped notification asked to open; -1 when none (consumed by navigation once handled). */
    private var openAlertRowId by mutableLongStateOf(-1L)

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen() // must precede super.onCreate: swaps the Starting theme for the post-splash theme
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) handleIntent(intent)
        setContent { StbApp(openAlertRowId = openAlertRowId, onOpenAlertHandled = { openAlertRowId = -1L }) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == AppIntents.ACTION_OPEN_ALERT) {
            val id = intent.getLongExtra(AppIntents.EXTRA_ALERT_ROW_ID, -1L)
            if (id >= 0) openAlertRowId = id
        }
    }
}
