package net.seatrace.stbluesentinel.ui.state

import net.seatrace.stbluesentinel.core.model.AlertType
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs

/** Display formatting. Absent values are the caller's job to omit - nothing here invents a placeholder. */
object AlertFormat {
    private val SHORT = DateTimeFormatter.ofPattern("HH:mm 'UTC'", Locale.ENGLISH).withZone(ZoneOffset.UTC)
    private val COMPACT = DateTimeFormatter.ofPattern("dd MMM HH:mm 'UTC'", Locale.ENGLISH).withZone(ZoneOffset.UTC)
    private val FULL = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.ENGLISH).withZone(ZoneOffset.UTC)

    fun utcShort(millis: Long): String = SHORT.format(Instant.ofEpochMilli(millis))
    fun utcCompact(millis: Long): String = COMPACT.format(Instant.ofEpochMilli(millis))
    fun utcFull(millis: Long): String = FULL.format(Instant.ofEpochMilli(millis))

    fun alertTypeLabel(wire: String): String = when (AlertType.fromWire(wire)) {
        AlertType.DANGER_ZONE_ENTRY -> "Danger zone entry"
        AlertType.THREAT_AREA_DETECTED -> "Threat area detected"
        AlertType.DANGER_ZONE_APPROACH -> "Danger zone approach"
        AlertType.DANGER_ZONE_EXIT -> "Danger zone exit"
        AlertType.NEW_INCIDENT_NEARBY -> "New incident nearby"
        AlertType.TRANSMISSION_LOST -> "Transmission lost"
        AlertType.TRANSMISSION_RESUMED -> "Transmission resumed"
        AlertType.SPEED_CHANGE -> "Speed change"
        AlertType.COURSE_CHANGE -> "Course change"
        AlertType.DISTRESS_STATUS -> "Distress status"
        AlertType.NOTIFICATION_TEST -> "Notification test"
        AlertType.UNKNOWN -> wire.replace('_', ' ').replaceFirstChar { it.uppercase() }
    }

    fun latitude(v: Double): String = "%.6f° %s".format(Locale.ROOT, abs(v), if (v >= 0) "N" else "S")
    fun longitude(v: Double): String = "%.6f° %s".format(Locale.ROOT, abs(v), if (v >= 0) "E" else "W")
    fun speedKnots(v: Double): String = "%.1f kn".format(Locale.ROOT, v)
    fun courseDegrees(v: Double): String = "%.1f°".format(Locale.ROOT, v)
    fun kilometres(v: Double): String = "%.1f km".format(Locale.ROOT, v)

    fun duration(seconds: Long): String = when {
        seconds < 60 -> "$seconds s"
        seconds < 3600 -> "${seconds / 60} min"
        else -> "${seconds / 3600} h %02d min".format(Locale.ROOT, (seconds % 3600) / 60)
    }
}
