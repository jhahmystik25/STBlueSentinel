package net.seatrace.stbluesentinel.push

import android.content.Context
import java.util.UUID

/**
 * What the receiver gateway needs to address this device. [userId] and [receiverId] are reserved for the
 * future registration backend (null in V1: the gateway operator pairs the device manually - see docs).
 */
data class DeviceRegistration(
    val deviceId: String,
    val fcmToken: String?,
    val userId: String? = null,
    val receiverId: String? = null,
)

/** Private, app-local store. The FCM token identifies the device to the gateway; it is NOT a signing secret, but it is never logged. */
class DeviceStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("stb_device", Context.MODE_PRIVATE)

    val deviceId: String
        get() = prefs.getString(K_ID, null) ?: UUID.randomUUID().toString().also { prefs.edit().putString(K_ID, it).apply() }

    var fcmToken: String?
        get() = prefs.getString(K_TOKEN, null)
        set(v) = prefs.edit().putString(K_TOKEN, v).putLong(K_TOKEN_AT, System.currentTimeMillis()).apply()

    val tokenUpdatedAt: Long get() = prefs.getLong(K_TOKEN_AT, 0L)

    fun registration() = DeviceRegistration(deviceId = deviceId, fcmToken = fcmToken)

    fun clear() = prefs.edit().clear().apply()

    private companion object { const val K_ID = "device_id"; const val K_TOKEN = "fcm_token"; const val K_TOKEN_AT = "fcm_token_at" }
}
