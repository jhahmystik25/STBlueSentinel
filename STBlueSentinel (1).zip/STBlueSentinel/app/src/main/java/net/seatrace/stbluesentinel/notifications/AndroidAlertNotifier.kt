package net.seatrace.stbluesentinel.notifications

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import net.seatrace.stbluesentinel.MainActivity
import net.seatrace.stbluesentinel.R
import net.seatrace.stbluesentinel.core.SafeLog
import net.seatrace.stbluesentinel.core.model.Severity
import net.seatrace.stbluesentinel.core.pipeline.AlertNotifier
import net.seatrace.stbluesentinel.data.db.AlertEntity

/** Posts one notification per stored alert. Notification id == Room row id, so a row can never notify twice. */
class AndroidAlertNotifier(context: Context) : AlertNotifier {
    private val context = context.applicationContext

    @SuppressLint("MissingPermission") // permission is checked explicitly below
    override fun notify(alert: AlertEntity): Boolean {
        val nm = NotificationManagerCompat.from(context)
        if (!nm.areNotificationsEnabled()) return false
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false

        val severity = Severity.fromWire(alert.severity) ?: Severity.LOW
        val channel = NotificationChannels.channelFor(severity, alert.testAlert)
        val text = NotificationTextBuilder.build(severity, alert.testAlert, alert.title, alert.shipName, alert.areaLabel, alert.testNotice)

        val open = Intent(context, MainActivity::class.java).apply {
            action = AppIntents.ACTION_OPEN_ALERT
            putExtra(AppIntents.EXTRA_ALERT_ROW_ID, alert.id)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val tap = PendingIntent.getActivity(
            context, alert.id.toInt(), open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        val publicVersion = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_stat_bluesentinel)
            .setContentTitle(text.publicTitle).setContentText(text.publicBody)
            .build()

        val builder = NotificationCompat.Builder(context, channel)
            .setSmallIcon(R.drawable.ic_stat_bluesentinel)
            .setColor(ContextCompat.getColor(context, accentFor(severity, alert.testAlert)))
            .setContentTitle(text.title)
            .setContentText(text.body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text.bigText))
            .setContentIntent(tap)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(true)
            .setWhen(alert.receivedAt)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(publicVersion)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
        if (alert.testAlert) builder.setSubText("Test — not a real incident")

        return try {
            nm.notify(alert.id.toInt(), builder.build())
            SafeLog.i("Notification generated for alert row ${alert.id}")
            true
        } catch (_: SecurityException) {
            false
        }
    }

    // Colour is a secondary cue only: the severity word is always in the title text.
    private fun accentFor(s: Severity, isTest: Boolean): Int = when {
        isTest -> R.color.stb_test
        s == Severity.CRITICAL -> R.color.stb_critical
        s == Severity.HIGH -> R.color.stb_high
        s == Severity.MEDIUM -> R.color.stb_medium
        s == Severity.LOW -> R.color.stb_low
        else -> R.color.stb_info
    }
}
