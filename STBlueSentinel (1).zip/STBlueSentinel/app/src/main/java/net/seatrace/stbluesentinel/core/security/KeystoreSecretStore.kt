package net.seatrace.stbluesentinel.core.security

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.security.keystore.StrongBoxUnavailableException
import android.util.Base64
import android.util.Log
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Stores the signing secret as AES-256-GCM ciphertext. The AES key is generated inside the Android
 * Keystore (hardware-backed where available, StrongBox preferred) and is non-exportable, so the
 * ciphertext on disk is useless without this device and this app. The secret never touches
 * plaintext SharedPreferences, BuildConfig, resources or logs.
 *
 * Works with no Activity, so the FCM background path can verify while the UI is closed.
 */
class KeystoreSecretStore(
    context: Context,
    /** Overridable so device tests use their own key + file and can never touch a developer's real secret. */
    private val keyAlias: String = DEFAULT_KEY_ALIAS,
    prefsName: String = DEFAULT_PREFS,
) : SecretStore {
    private val prefs = context.applicationContext.getSharedPreferences(prefsName, Context.MODE_PRIVATE)

    override fun hasSecret(): Boolean = prefs.contains(KEY_BLOB)

    override fun save(secret: String): SaveResult {
        val normalized = SecretPolicy.normalize(secret) ?: return SaveResult.Invalid
        val plain = normalized.toByteArray(Charsets.UTF_8)
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            cipher.updateAAD(AAD)
            val ct = cipher.doFinal(plain)
            val blob = cipher.iv + ct
            val ok = prefs.edit().putString(KEY_BLOB, Base64.encodeToString(blob, Base64.NO_WRAP)).commit()
            if (ok) SaveResult.Saved else SaveResult.StorageError
        } catch (e: Exception) {
            Log.w(TAG, "Secret storage failed (${e.javaClass.simpleName})") // class name only: never the message/secret
            SaveResult.StorageError
        } finally {
            plain.fill(0)
        }
    }

    override fun load(): ByteArray? {
        val encoded = prefs.getString(KEY_BLOB, null) ?: return null
        return try {
            val blob = Base64.decode(encoded, Base64.NO_WRAP)
            if (blob.size <= IV_BYTES) return null
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(TAG_BITS, blob, 0, IV_BYTES))
            cipher.updateAAD(AAD)
            cipher.doFinal(blob, IV_BYTES, blob.size - IV_BYTES)
        } catch (e: Exception) {
            // Key invalidated/missing, corrupted blob, or storage not yet unlocked (direct boot).
            // Treated as "no usable secret": alerts are then NOT marked verified.
            Log.w(TAG, "Secret unreadable (${e.javaClass.simpleName})")
            null
        }
    }

    override fun clear() {
        prefs.edit().remove(KEY_BLOB).commit()
        runCatching { KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }.deleteEntry(keyAlias) }
    }

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        (ks.getKey(keyAlias, null) as? SecretKey)?.let { return it }
        return try {
            generateKey(strongBox = Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
        } catch (_: StrongBoxUnavailableException) {
            generateKey(strongBox = false)
        } catch (_: java.security.ProviderException) {
            generateKey(strongBox = false) // some devices fail StrongBox with a generic provider error
        }
    }

    private fun generateKey(strongBox: Boolean): SecretKey {
        val spec = KeyGenParameterSpec.Builder(keyAlias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)
            .apply { if (strongBox && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) setIsStrongBoxBacked(true) }
            .build()
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE).apply { init(spec) }.generateKey()
    }

    companion object {
        const val DEFAULT_KEY_ALIAS = "stb_signing_secret_key_v1"
        const val DEFAULT_PREFS = "stb_secret_store"
        private const val TAG = "STB.SecretStore"
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val KEY_BLOB = "blob_v1"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val IV_BYTES = 12
        private const val TAG_BITS = 128
        private val AAD = "net.seatrace.stbluesentinel/hmac-secret/v1".toByteArray(Charsets.UTF_8)
    }
}
