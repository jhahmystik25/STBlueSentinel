@file:OptIn(ExperimentalMaterial3Api::class)

package net.seatrace.stbluesentinel.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import net.seatrace.stbluesentinel.notifications.NotificationAccess
import net.seatrace.stbluesentinel.notifications.NotificationAccessChecker
import net.seatrace.stbluesentinel.ui.components.SectionCard
import net.seatrace.stbluesentinel.ui.components.StatusLine
import net.seatrace.stbluesentinel.ui.state.AlertFormat
import net.seatrace.stbluesentinel.ui.state.StatusLogic
import net.seatrace.stbluesentinel.ui.vm.HelpViewModel

@Composable
fun HelpScreen(onBack: () -> Unit, vm: HelpViewModel = viewModel()) {
    val context = LocalContext.current
    val health by vm.health.collectAsStateWithLifecycle()
    val rejections by vm.rejections.collectAsStateWithLifecycle()

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) vm.refresh() }
        owner.lifecycle.addObserver(obs); onDispose { owner.lifecycle.removeObserver(obs) }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { TopAppBar(title = { Text("Help & diagnostics") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) },
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

            SectionCard("Diagnostics") {
                StatusLine(if (health.notifications == NotificationAccess.GRANTED) "Notifications allowed" else "Notifications are not fully allowed", health.notifications == NotificationAccess.GRANTED)
                StatusLine("Push: ${StatusLogic.pushLabel(health.push)}", health.push.name == "ACTIVE")
                StatusLine("Push token ${if (vm.tokenPresent) "present" else "not yet received"}", vm.tokenPresent)
                StatusLine(
                    if (health.background.backgroundRestricted) "Background activity is RESTRICTED for this app" else "Background activity is not restricted",
                    !health.background.backgroundRestricted,
                )
                StatusLine(
                    "App standby bucket: ${StatusLogic.standbyBucketLabel(health.background.standbyBucket)}",
                    !StatusLogic.isStandbyConcerning(health.background.standbyBucket),
                )
                OutlinedButton(onClick = { context.startActivity(NotificationAccessChecker.settingsIntent(context)) }) { Text("Open notification settings") }
                OutlinedButton(onClick = {
                    context.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text("Open app settings (battery)") }
            }

            SectionCard("For reliable BlueSentinel notifications") {
                Bullet("Allow notifications.")
                Bullet("Do not disable STBlueSentinel notifications, and do not silence the “BlueSentinel Alerts” channel.")
                Bullet("If your device manufacturer provides aggressive battery optimisation, allow STBlueSentinel to run normally in the background (in app settings, set Battery to “Unrestricted” or “Optimized”, not “Restricted”).")
                Text("STBlueSentinel never asks for a battery-optimisation exemption: alerts arrive through Android's push service, which does not need one.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            SectionCard("Limits you should know about") {
                Bullet("Force Stop: if you force-stop STBlueSentinel from Android Settings, Android blocks all background activity, including push delivery, until you open the app again. This cannot be bypassed, and alerts sent in the meantime will not reach this phone.")
                Bullet("Short delivery window: live alerts expire after 5 minutes in transit. If this phone is offline or unreachable for longer, that alert is not delivered here (it remains in SeaTracePro).")
                Bullet("Delayed alerts: a verified alert that reaches this phone more than 15 minutes after it was signed is saved as DELAYED and does not raise a notification.")
                Bullet("If notifications are disabled in Android, STBlueSentinel can still save verified alerts to your history, but cannot show them.")
                Bullet("Some manufacturers add their own battery managers (see dontkillmyapp.com for your brand).")
            }

            SectionCard("Recent rejected deliveries") {
                if (rejections.isEmpty()) {
                    Text("None. Rejected deliveries (bad signature, stale, malformed) are listed here with the reason only; nothing from the payload is kept.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    rejections.forEach { r ->
                        Text(AlertFormat.utcFull(r.receivedAt) + " · " + r.reason.lowercase().replace('_', ' ') + (r.alertId?.let { " · alert $it" } ?: ""), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun Bullet(text: String) = Text("•  $text", style = MaterialTheme.typography.bodyMedium)
