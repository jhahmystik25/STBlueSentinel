@file:OptIn(ExperimentalMaterial3Api::class)

package net.seatrace.stbluesentinel.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import net.seatrace.stbluesentinel.core.model.Severity
import net.seatrace.stbluesentinel.data.db.AlertEntity
import net.seatrace.stbluesentinel.ui.components.SeverityBadge
import net.seatrace.stbluesentinel.ui.components.TagChip
import net.seatrace.stbluesentinel.ui.components.severityColors
import net.seatrace.stbluesentinel.ui.state.AlertFormat
import net.seatrace.stbluesentinel.ui.state.ViewFilter
import net.seatrace.stbluesentinel.ui.theme.StbColors
import net.seatrace.stbluesentinel.ui.vm.HistoryViewModel

@Composable
fun HistoryScreen(onBack: () -> Unit, onOpenAlert: (Long) -> Unit, vm: HistoryViewModel = viewModel()) {
    val alerts by vm.alerts.collectAsStateWithLifecycle()
    val filter by vm.filter.collectAsStateWithLifecycle()
    val counts by vm.counts.collectAsStateWithLifecycle()
    var confirmClear by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("BlueSentinel") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = {
                    IconButton(onClick = vm::markAllRead) { Icon(Icons.Filled.DoneAll, "Mark all alerts as read") }
                    IconButton(onClick = { confirmClear = true }) { Icon(Icons.Filled.DeleteSweep, "Clear alert history") }
                },
            )
        },
    ) { pad ->
        LazyColumn(Modifier.padding(pad), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW).forEach { s ->
                        Row(Modifier.fillMaxWidth()) {
                            Text(s.label.lowercase().replaceFirstChar { it.uppercase() }, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            Text("${counts[s] ?: 0}", fontWeight = FontWeight.Bold)
                        }
                    }
                    Text("Recent alerts", Modifier.padding(top = 12.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item { FilterChip(selected = filter.severities.isEmpty(), onClick = vm::clearSeverities, label = { Text("All severities") }) }
                        items(listOf(Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW)) { s ->
                            FilterChip(selected = s in filter.severities, onClick = { vm.toggleSeverity(s) }, label = { Text(s.label) })
                        }
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(ViewFilter.entries.toList()) { v ->
                            FilterChip(selected = filter.view == v, onClick = { vm.setView(v) }, label = { Text(v.label) })
                        }
                    }
                }
            }
            if (alerts.isEmpty()) {
                item { Text("No alerts match.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 24.dp)) }
            }
            items(alerts, key = { it.id }) { a -> AlertRow(a) { onOpenAlert(a.id) } }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear alert history?") },
            text = { Text("All stored alerts will be deleted from this phone. This cannot be undone.") },
            confirmButton = { TextButton(onClick = { vm.clearAll(); confirmClear = false }) { Text("Clear") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun AlertRow(a: AlertEntity, onClick: () -> Unit) {
    val sev = Severity.fromWire(a.severity) ?: Severity.LOW
    val delayed = a.deliveryStatus == "STALE"
    val prominent = !a.testAlert && (sev == Severity.CRITICAL || sev == Severity.HIGH)
    val border = when {
        a.testAlert -> BorderStroke(1.dp, StbColors.test)
        prominent -> BorderStroke(2.dp, severityColors(sev).container)
        else -> BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    }
    Card(onClick = onClick, border = border, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SeverityBadge(sev)
                if (a.testAlert) TagChip("TEST", StbColors.test)
                if (delayed) TagChip("DELAYED", StbColors.delayed)
                if (!a.read) TagChip("NEW", MaterialTheme.colorScheme.primary)
            }
            Text(
                (if (a.testAlert) "TEST — " else "") + a.title,
                style = if (prominent) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyLarge,
                fontWeight = if (prominent || !a.read) FontWeight.Bold else FontWeight.Normal,
            )
            a.shipName?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            Text(
                AlertFormat.utcCompact(a.receivedAt) + " · " + AlertFormat.alertTypeLabel(a.alertType),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
