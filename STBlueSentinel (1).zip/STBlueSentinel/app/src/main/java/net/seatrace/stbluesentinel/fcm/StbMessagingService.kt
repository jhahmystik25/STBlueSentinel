package net.seatrace.stbluesentinel.fcm

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.runBlocking
import net.seatrace.stbluesentinel.StbApplication
import net.seatrace.stbluesentinel.core.SafeLog
import net.seatrace.stbluesentinel.core.pipeline.ProcessResult
import net.seatrace.stbluesentinel.core.security.RejectReason
import java.lang.System.currentTimeMillis

/**
 * Background entry point. Android starts this process and calls [onMessageReceived] even when no
 * Activity exists (app closed, screen off, Doze maintenance window), as long as the user has not
 * force-stopped the app. No UI is involved:
 *
 *   FCM data message -> parse -> AlertProcessor (verify HMAC, dedupe, Room, notification)
 *
 * The gateway MUST send data-only messages (no `notification` block). A message with a notification
 * block is displayed by the system tray when the app is in the background and would bypass this
 * service - and therefore bypass verification and storage.
 */
class StbMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(message: RemoteMessage) {
        val container = (application as StbApplication).container
        when (val parsed = FcmEnvelopeParser.parse(message.data)) {
            FcmParseResult.NotBlueSentinel -> return // unrelated push: ignore, leave no trace
            is FcmParseResult.Invalid -> {
                recordInvalid(parsed.reason)
                SafeLog.w("Push rejected: ${parsed.reason}")
            }
            is FcmParseResult.Envelope -> {
                SafeLog.i("Alert received")
                // onMessageReceived runs off the main thread with a short time budget; the work is a
                // few ms of HMAC + one Room insert, and finishing it here keeps the process alive until done.
                val result = try {
                    runBlocking { container.processor.process(parsed.envelope) }
                } catch (_: Exception) {
                    SafeLog.w("Alert processing error") // no message/stack: they could echo payload content
                    return
                }
                logResult(result)
            }
        }
    }

    override fun onNewToken(token: String) {
        val container = (application as StbApplication).container
        container.deviceStore.fcmToken = token
        SafeLog.i("FCM token registered")
        // Future: POST container.deviceStore.registration() to the gateway's device-registration endpoint.
    }

    override fun onDeletedMessages() {
        // FCM dropped queued messages (too many pending / TTL). Live alerts are short-lived by design.
        SafeLog.w("FCM reported deleted messages")
    }

    private fun recordInvalid(reason: RejectReason) {
        try {
            val dao = (application as StbApplication).container.database.rejectionDao()
            runBlocking {
                dao.insert(net.seatrace.stbluesentinel.data.db.RejectionEntity(alertId = null, reason = reason.name, receivedAt = currentTimeMillis()))
                dao.prune(200)
            }
        } catch (_: Exception) { /* best effort */ }
    }

    private fun logResult(r: ProcessResult) = when (r) {
        is ProcessResult.Notified -> SafeLog.i("Signature verified; alert stored; notification generated")
        is ProcessResult.StoredSilently -> SafeLog.i("Signature verified; alert stored; no notification (${r.decision})")
        is ProcessResult.StoredNotificationBlocked -> SafeLog.w("Alert stored; Android did not post the notification")
        ProcessResult.Duplicate -> SafeLog.i("Duplicate ignored")
        is ProcessResult.Rejected -> SafeLog.w("Alert rejected: ${r.reason}")
        is ProcessResult.StorageFailed -> SafeLog.w("Alert storage failed")
    }
}
