package net.seatrace.stbluesentinel.ui.state

import net.seatrace.stbluesentinel.core.model.Severity

enum class ViewFilter(val label: String) { ALL("All"), REAL("Real"), TEST("Test"), DELAYED("Delayed") }

/** Empty [severities] means "every severity". INFO is grouped with LOW, matching the dashboard counts. */
data class AlertFilter(val severities: Set<Severity> = emptySet(), val view: ViewFilter = ViewFilter.ALL) {
    fun matches(severityWire: String, testAlert: Boolean, deliveryStatus: String): Boolean {
        val sev = Severity.fromWire(severityWire)?.let { if (it == Severity.INFO) Severity.LOW else it }
        if (severities.isNotEmpty() && sev !in severities) return false
        return when (view) {
            ViewFilter.ALL -> true
            ViewFilter.REAL -> !testAlert
            ViewFilter.TEST -> testAlert
            ViewFilter.DELAYED -> deliveryStatus == "STALE"
        }
    }

    fun toggle(severity: Severity): AlertFilter =
        copy(severities = if (severity in severities) severities - severity else severities + severity)
}
