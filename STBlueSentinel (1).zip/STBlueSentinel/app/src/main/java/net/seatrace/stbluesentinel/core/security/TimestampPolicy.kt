package net.seatrace.stbluesentinel.core.security

/** Result of the client-side freshness check. Not yet "verified": the HMAC has not been checked at this stage. */
enum class TimestampStatus { WITHIN_LIVE_WINDOW, STALE, REJECTED }

data class TimestampCheck(
    val status: TimestampStatus,
    /** The signing time exactly as parsed from X-SeaTrace-Timestamp (whole seconds), if valid. */
    val signedAtEpochSeconds: Long?,
    /** now - signedAt, clamped at 0 (tiny negative skew is treated as 0). Null when rejected as invalid. */
    val ageSeconds: Long?,
    val reason: RejectReason?,
)

/**
 * Independent client-side timestamp validation for the signed `X-SeaTrace-Timestamp` header.
 *
 * Layering (do not conflate the two):
 *  - The receiver GATEWAY enforces the documented strict 300-second replay window. That is the
 *    primary replay control and is never relaxed.
 *  - This client policy only tolerates legitimate FCM delivery/processing delay:
 *
 *      age < -60 s                 -> REJECTED  (future-dated beyond a tiny clock-skew allowance)
 *      -60 s <= age <= 15 min      -> WITHIN_LIVE_WINDOW  (may become VERIFIED after the HMAC check)
 *      15 min < age <= 24 h        -> STALE     (stored for history/audit, NEVER a live notification)
 *      age > 24 h                  -> REJECTED  (cannot be a legitimate delayed delivery)
 *
 * The time checked is the signing time from the header (the value covered by the HMAC), NOT the
 * body's `timestamp_utc`, which is the AIS report time and can legitimately be older.
 */
object TimestampPolicy {
    /** Documented gateway replay window. Informational here; enforced by the gateway. */
    const val GATEWAY_REPLAY_WINDOW_SECONDS = 300L

    const val LIVE_WINDOW_SECONDS = 15L * 60L
    const val FUTURE_SKEW_SECONDS = 60L

    /** Upper bound for keeping a validly-signed but delayed alert as STALE history. */
    const val MAX_STALE_AGE_SECONDS = 24L * 60L * 60L

    private const val MIN_PLAUSIBLE_EPOCH_SECONDS = 1_577_836_800L // 2020-01-01T00:00:00Z
    private val FORMAT = Regex("""\d{1,12}(\.\d{1,6})?""")

    fun evaluate(rawHeader: String?, nowEpochSeconds: Long): TimestampCheck {
        if (rawHeader.isNullOrEmpty()) return rejected(RejectReason.TIMESTAMP_MISSING)
        if (!FORMAT.matches(rawHeader)) return rejected(RejectReason.INVALID_TIMESTAMP)
        val signedAt = rawHeader.substringBefore('.').toLong()
        if (signedAt < MIN_PLAUSIBLE_EPOCH_SECONDS) return rejected(RejectReason.INVALID_TIMESTAMP)

        val age = nowEpochSeconds - signedAt
        return when {
            age < -FUTURE_SKEW_SECONDS -> TimestampCheck(TimestampStatus.REJECTED, signedAt, age, RejectReason.FUTURE_TIMESTAMP)
            age <= LIVE_WINDOW_SECONDS -> TimestampCheck(TimestampStatus.WITHIN_LIVE_WINDOW, signedAt, maxOf(age, 0L), null)
            age <= MAX_STALE_AGE_SECONDS -> TimestampCheck(TimestampStatus.STALE, signedAt, age, null)
            else -> TimestampCheck(TimestampStatus.REJECTED, signedAt, age, RejectReason.TIMESTAMP_TOO_OLD)
        }
    }

    private fun rejected(reason: RejectReason) = TimestampCheck(TimestampStatus.REJECTED, null, null, reason)
}
