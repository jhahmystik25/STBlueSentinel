package net.seatrace.stbluesentinel.ui.state

import net.seatrace.stbluesentinel.core.model.Severity

object AlertCounts {
    /** Dashboard classes: INFO is folded into LOW. Unknown severity strings are ignored, never miscounted. */
    fun fold(rows: List<Pair<String, Int>>): Map<Severity, Int> {
        val m = linkedMapOf(Severity.CRITICAL to 0, Severity.HIGH to 0, Severity.MEDIUM to 0, Severity.LOW to 0)
        rows.forEach { (wire, count) ->
            Severity.fromWire(wire)?.let { s ->
                val k = if (s == Severity.INFO) Severity.LOW else s
                m[k] = m.getValue(k) + count
            }
        }
        return m
    }
}
