package net.seatrace.stbluesentinel.notifications

object AppIntents {
    const val ACTION_OPEN_ALERT = "net.seatrace.stbluesentinel.action.OPEN_ALERT"
    /** Room row id of the alert to open (Long). Not the alert_id string, and no sensitive data. */
    const val EXTRA_ALERT_ROW_ID = "alert_row_id"
}
