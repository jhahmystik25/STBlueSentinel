package net.seatrace.stbluesentinel.notifications

import android.app.ActivityManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.PowerManager

/**
 * Read-only diagnostics about Android's background restrictions for THIS app. No permission is needed to read
 * them, and the app never asks for a battery-optimisation exemption: FCM high-priority delivery does not require one.
 */
data class BackgroundHealth(
    /** User chose "Restricted" in Settings > Apps > STBlueSentinel > Battery: Android blocks most background work. */
    val backgroundRestricted: Boolean,
    /** App Standby bucket (10 active ... 45 restricted), or null if unavailable. */
    val standbyBucket: Int?,
    val ignoringBatteryOptimizations: Boolean,
) {
    companion object {
        fun read(context: Context): BackgroundHealth {
            val am = context.getSystemService(ActivityManager::class.java)
            val usm = context.getSystemService(UsageStatsManager::class.java)
            val pm = context.getSystemService(PowerManager::class.java)
            return BackgroundHealth(
                backgroundRestricted = runCatching { am.isBackgroundRestricted }.getOrDefault(false),
                standbyBucket = runCatching { usm.appStandbyBucket }.getOrNull(),
                ignoringBatteryOptimizations = runCatching { pm.isIgnoringBatteryOptimizations(context.packageName) }.getOrDefault(false),
            )
        }
    }
}
