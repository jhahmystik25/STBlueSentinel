package net.seatrace.stbluesentinel.receiver

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.io.InterruptedIOException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLException
import kotlin.coroutines.resume

/**
 * Optional reachability probe for the user's receiver endpoint (see [ReceiverCheckResult] for what it does and
 * does not prove). Security properties: wss:// only (the URL is validated first), the DEFAULT OkHttp TLS stack
 * (system trust store, default hostname verification - no custom TrustManager/HostnameVerifier), no credentials,
 * no secret, and no frames are ever sent. The connection is closed immediately.
 */
class ReceiverChecker(private val clock: () -> Long = System::currentTimeMillis) {
    private val _state = MutableStateFlow<CheckState>(CheckState.Idle)
    val state: StateFlow<CheckState> = _state.asStateFlow()

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .build()

    suspend fun check(url: String): ReceiverCheckResult {
        require(url.startsWith("wss://")) { "wss:// only" }
        _state.value = CheckState.Checking
        val result = withTimeoutOrNull(12_000) { probe(url) } ?: ReceiverCheckResult.Timeout
        _state.value = CheckState.Done(result, clock())
        return result
    }

    private suspend fun probe(url: String): ReceiverCheckResult = suspendCancellableCoroutine { cont ->
        fun finish(r: ReceiverCheckResult) { if (cont.isActive) cont.resume(r) }
        val socket = client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.close(1000, null)
                finish(ReceiverCheckResult.Reachable(response.code))
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                finish(if (response != null) ReceiverCheckResult.Reachable(response.code) else classify(t))
            }
        })
        cont.invokeOnCancellation { socket.cancel() }
    }

    private fun classify(t: Throwable): ReceiverCheckResult {
        var e: Throwable? = t
        while (e != null) {
            when (e) {
                is UnknownHostException -> return ReceiverCheckResult.DnsFailure
                is SSLException -> return ReceiverCheckResult.TlsFailure
                is InterruptedIOException -> return ReceiverCheckResult.Timeout // includes SocketTimeoutException
            }
            e = e.cause
        }
        return ReceiverCheckResult.Error
    }
}
