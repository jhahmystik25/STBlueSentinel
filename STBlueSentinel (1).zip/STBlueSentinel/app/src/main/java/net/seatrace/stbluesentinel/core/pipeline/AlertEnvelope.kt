package net.seatrace.stbluesentinel.core.pipeline

/**
 * What the receiver gateway hands the app for one alert: the ORIGINAL `X-SeaTrace-*` header values
 * and the ORIGINAL frame bytes, untouched. None of this is secret (the signature is a MAC, not a key).
 */
class AlertEnvelope(
    val event: String?,
    val alertId: String?,
    val timestamp: String?,
    val signature: String?,
    val frame: ByteArray?,
)
