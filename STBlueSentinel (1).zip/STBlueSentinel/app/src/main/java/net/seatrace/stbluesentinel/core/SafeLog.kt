package net.seatrace.stbluesentinel.core

import android.util.Log
import net.seatrace.stbluesentinel.BuildConfig

/**
 * Release-safe logging. Call sites pass ONLY fixed event wording and non-sensitive identifiers
 * (alert id, reason enum, counts). The signing secret, FCM token, signature value and frame text
 * must never be passed in. Debug/info lines are stripped from release builds by R8 (see proguard-rules.pro).
 */
object SafeLog {
    private const val TAG = "STBlueSentinel"
    fun i(event: String) { if (BuildConfig.DEBUG) Log.i(TAG, event) }
    fun d(event: String) { if (BuildConfig.DEBUG) Log.d(TAG, event) }
    fun w(event: String) { Log.w(TAG, event) }
}
