package net.seatrace.stbluesentinel.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import net.seatrace.stbluesentinel.R
import net.seatrace.stbluesentinel.core.model.Severity
import net.seatrace.stbluesentinel.notifications.NotificationAccess
import net.seatrace.stbluesentinel.ui.NotificationPermissionCard
import net.seatrace.stbluesentinel.ui.components.KeyValueRow
import net.seatrace.stbluesentinel.ui.components.SectionCard
import net.seatrace.stbluesentinel.ui.components.SeverityBadge
import net.seatrace.stbluesentinel.ui.components.StatusLine
import net.seatrace.stbluesentinel.ui.state.AlertFormat
import net.seatrace.stbluesentinel.ui.state.SecurityLevel
import net.seatrace.stbluesentinel.ui.state.StatusLogic
import net.seatrace.stbluesentinel.ui.theme.StbColors
import net.seatrace.stbluesentinel.ui.vm.DashboardViewModel

@Composable
fun DashboardScreen(
    onViewAlerts: () -> Unit,
    onSettings: () -> Unit,
    onHelp: () -> Unit,
    onOpenAlert: (Long) -> Unit,
    vm: DashboardViewModel = viewModel(),
) {
    val security by vm.security.collectAsStateWithLifecycle()
    val receiver by vm.receiverStatus.collectAsStateWithLifecycle()
    val health by vm.health.collectAsStateWithLifecycle()
    val counts by vm.counts.collectAsStateWithLifecycle()
    val latest by vm.latest.collectAsStateWithLifecycle()
    val unread by vm.unread.collectAsStateWithLifecycle()

    // Re-read permission / push / battery state whenever the screen returns to the foreground.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) vm.refresh() }
        owner.lifecycle.addObserver(obs); onDispose { owner.lifecycle.removeObserver(obs) }
    }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // Header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(painterResource(R.drawable.seatrace_logo), stringResource(R.string.cd_seatrace_logo), Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(stringResource(R.string.app_name), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.brand_by_seatrace), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                TextButton(onClick = onHelp) { Icon(Icons.Filled.HelpOutline, null); Spacer(Modifier.width(4.dp)); Text("Help") }
            }

            // Security status: level is spelled out in words.
            val levelColor = when (security.level) {
                SecurityLevel.SECURE -> StbColors.ok
                SecurityLevel.ATTENTION -> StbColors.warn
                SecurityLevel.NOT_CONFIGURED -> MaterialTheme.colorScheme.error
            }
            SectionCard("Security", border = BorderStroke(1.5.dp, levelColor)) {
                Text("● ${security.level.label}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = levelColor)
                security.lines.forEach { StatusLine(it.text, it.ok) }
                if (security.level == SecurityLevel.NOT_CONFIGURED) {
                    Button(onClick = onSettings) { Text("Set up receiver & secret") }
                }
            }

            if (health.notifications != NotificationAccess.GRANTED) NotificationPermissionCard(vm.permissionPrefs)

            // Two clearly separate things: the receiver gateway, and push delivery to this phone.
            SectionCard("Connection") {
                KeyValueRow("Receiver", receiver.label)
                KeyValueRow("Push notifications", StatusLogic.pushLabel(health.push))
                Text(
                    "SeaTracePro delivers to your receiver gateway, which forwards verified alerts to this phone by push. This phone never connects to SeaTracePro directly.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            SectionCard("Alerts") {
                listOf(Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW).forEach { s ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        SeverityBadge(s)
                        Spacer(Modifier.weight(1f))
                        Text("${counts[s] ?: 0}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                }
                Text("Real alerts only; test alerts are not counted.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            SectionCard("Latest alert") {
                val a = latest
                if (a == null) {
                    Text("No alerts received yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Column(Modifier.fillMaxWidth().clickable { onOpenAlert(a.id) }, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SeverityBadge(Severity.fromWire(a.severity) ?: Severity.LOW, large = true)
                        Text(a.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        a.shipName?.let { Text(it) }
                        Text(
                            AlertFormat.utcShort(a.receivedAt) + " · " + AlertFormat.alertTypeLabel(a.alertType),
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = onViewAlerts, modifier = Modifier.weight(1f)) { Text(if (unread > 0) "View Alerts ($unread new)" else "View Alerts") }
                OutlinedButton(onClick = onSettings, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Settings, null); Spacer(Modifier.width(6.dp)); Text("Settings")
                }
            }
        }
    }
}
