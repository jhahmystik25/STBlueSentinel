@file:OptIn(ExperimentalMaterial3Api::class)

package net.seatrace.stbluesentinel.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import net.seatrace.stbluesentinel.core.model.Severity
import net.seatrace.stbluesentinel.data.db.AlertEntity
import net.seatrace.stbluesentinel.notifications.NotificationTextBuilder
import net.seatrace.stbluesentinel.ui.components.Banner
import net.seatrace.stbluesentinel.ui.components.KeyValueRow
import net.seatrace.stbluesentinel.ui.components.SectionCard
import net.seatrace.stbluesentinel.ui.components.SeverityBadge
import net.seatrace.stbluesentinel.ui.state.AlertFormat
import net.seatrace.stbluesentinel.ui.theme.StbColors
import net.seatrace.stbluesentinel.ui.vm.DetailViewModel

@Composable
fun DetailScreen(onBack: () -> Unit, vm: DetailViewModel = viewModel()) {
    val alert by vm.alert.collectAsStateWithLifecycle()
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Alert") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            )
        },
    ) { pad ->
        val a = alert
        if (a == null) {
            Text("This alert is no longer stored on this phone.", Modifier.padding(pad).padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            DetailContent(a, Modifier.padding(pad))
        }
    }
}

@Composable
private fun DetailContent(a: AlertEntity, modifier: Modifier) {
    val sev = Severity.fromWire(a.severity) ?: Severity.LOW
    val delayed = a.deliveryStatus == "STALE"
    var showRaw by remember { mutableStateOf(false) }

    Column(modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (a.testAlert) Banner(NotificationTextBuilder.TEST_TITLE, StbColors.test, Color(0xFF1A0B33))
        if (delayed) Banner(
            "DELAYED ALERT — signed ${AlertFormat.duration(a.deliveryAgeSeconds)} before it reached this phone. Shown for the record; it is not a live alert.",
            StbColors.delayed, Color(0xFF2A1A00),
        )

        SectionCard("Alert") {
            SeverityBadge(sev, large = true)
            Text(a.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            a.message?.let { Text(it, style = MaterialTheme.typography.bodyLarge) }
            a.testNotice?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = StbColors.test) }
            KeyValueRow("Type", AlertFormat.alertTypeLabel(a.alertType))
            KeyValueRow("Alert ID", a.alertId)
            a.timestampUtc?.let { KeyValueRow("Event time", AlertFormat.utcFull(it)) }
            a.createdUtc?.let { KeyValueRow("Created", AlertFormat.utcFull(it)) }
            KeyValueRow("Signed", AlertFormat.utcFull(a.signedAt * 1000))
            KeyValueRow("Received", AlertFormat.utcFull(a.receivedAt))
            // "Verified" is only ever shown for a row that passed the HMAC check (the only way a row is stored).
            KeyValueRow("Verification", if (a.verified) "Signature verified (HMAC-SHA256)" else "Not verified")
        }

        val vessel = buildList {
            a.shipName?.let { add("Ship name" to it) }
            a.mmsi?.let { add("MMSI" to it.toString()) }
            a.imo?.let { add("IMO" to it.toString()) }
            a.shipId?.let { add("Ship ID" to it.toString()) }
            a.latitude?.let { add("Latitude" to AlertFormat.latitude(it)) }
            a.longitude?.let { add("Longitude" to AlertFormat.longitude(it)) }
            a.speedKnots?.let { add("Speed" to AlertFormat.speedKnots(it)) }
            a.courseDeg?.let { add("Course" to AlertFormat.courseDegrees(it)) }
            a.lastSeenUtc?.let { add("Last seen" to AlertFormat.utcFull(it)) }
        }
        if (vessel.isNotEmpty()) SectionCard("Vessel") { vessel.forEach { (k, v) -> KeyValueRow(k, v) } }

        val threat = buildList {
            a.threatState?.let { add("State" to it) }
            a.areaLabel?.let { add("Area" to it) }
            a.nearestIncidentKm?.let { add("Nearest incident" to AlertFormat.kilometres(it)) }
            a.incidentsWithinRadius?.let { add("Incidents in radius" to it.toString()) }
            a.radiusKm?.let { add("Radius" to AlertFormat.kilometres(it)) }
            a.datasetLatestIncidentDate?.let { add("Dataset latest" to it) }
        }
        if (threat.isNotEmpty()) SectionCard("Threat") { threat.forEach { (k, v) -> KeyValueRow(k, v) } }

        val incident = buildList {
            a.nearestIncidentDate?.let { add("Date" to it) }
            a.nearestIncidentAttackType?.let { add("Attack type" to it) }
            a.nearestIncidentCountry?.let { add("Country" to it) }
            a.nearestIncidentLocation?.let { add("Location" to it) }
            a.nearestIncidentDistanceKm?.let { add("Distance" to AlertFormat.kilometres(it)) }
        }
        if (incident.isNotEmpty()) SectionCard("Nearest incident") { incident.forEach { (k, v) -> KeyValueRow(k, v) } }

        SectionCard("Diagnostics") {
            TextButton(onClick = { showRaw = !showRaw }) { Text(if (showRaw) "Hide raw payload" else "Show raw payload") }
            if (showRaw) {
                SelectionContainer {
                    Text(a.rawPayload, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}
