package net.seatrace.stbluesentinel.notifications

import net.seatrace.stbluesentinel.core.model.DeliveryStatus
import net.seatrace.stbluesentinel.core.model.Severity

/** User notification preferences (non-secret). */
interface NotificationPreferences {
    val masterEnabled: Boolean
    val testAlertsEnabled: Boolean
    fun isSeverityEnabled(severity: Severity): Boolean
}

enum class NotifyDecision { NOTIFY, SKIP_STALE, SKIP_MASTER_DISABLED, SKIP_SEVERITY_DISABLED, SKIP_TEST_DISABLED }

/**
 * The single place that decides whether a stored alert may raise a notification.
 *  - Only VERIFIED alerts can ever notify. STALE (delayed past 15 min) never does, whatever the preferences.
 *  - Preferences only suppress notifications; they never affect storage/history.
 *  - Test alerts follow only the "test alerts" switch; INFO follows the LOW switch (INFO is never delivered externally anyway).
 */
object NotificationPolicy {
    fun decide(status: DeliveryStatus, severity: Severity, isTest: Boolean, prefs: NotificationPreferences): NotifyDecision {
        if (status != DeliveryStatus.VERIFIED) return NotifyDecision.SKIP_STALE
        if (!prefs.masterEnabled) return NotifyDecision.SKIP_MASTER_DISABLED
        if (isTest) return if (prefs.testAlertsEnabled) NotifyDecision.NOTIFY else NotifyDecision.SKIP_TEST_DISABLED
        val key = if (severity == Severity.INFO) Severity.LOW else severity
        return if (prefs.isSeverityEnabled(key)) NotifyDecision.NOTIFY else NotifyDecision.SKIP_SEVERITY_DISABLED
    }
}
