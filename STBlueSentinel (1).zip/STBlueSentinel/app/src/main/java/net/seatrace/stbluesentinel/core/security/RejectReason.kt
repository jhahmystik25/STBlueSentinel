package net.seatrace.stbluesentinel.core.security

/**
 * Why an incoming alert was NOT accepted. Recorded internally (reason + alert id only -
 * never the payload, headers or secret) and surfaced to the user in friendly wording.
 */
enum class RejectReason {
    MISSING_HEADER,
    WRONG_EVENT,
    FRAME_MISSING,
    FRAME_TOO_LARGE,
    TIMESTAMP_MISSING,
    INVALID_TIMESTAMP,
    FUTURE_TIMESTAMP,
    TIMESTAMP_TOO_OLD,
    SECRET_NOT_CONFIGURED,
    SIGNATURE_MISSING,
    SIGNATURE_MALFORMED,
    SIGNATURE_WRONG_ALGORITHM,
    SIGNATURE_MISMATCH,
    MALFORMED_JSON,
    UNSUPPORTED_SCHEMA,
    INVALID_SCHEMA,
    ALERT_ID_MISMATCH,
    INVALID_PUSH_PAYLOAD,
    UNSUPPORTED_PUSH_VERSION,
    PUSH_PAYLOAD_TOO_LARGE,
}
