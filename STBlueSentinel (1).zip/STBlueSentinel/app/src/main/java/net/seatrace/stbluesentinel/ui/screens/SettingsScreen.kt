@file:OptIn(ExperimentalMaterial3Api::class)

package net.seatrace.stbluesentinel.ui.screens

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.os.Build
import android.os.PersistableBundle
import android.view.WindowManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import net.seatrace.stbluesentinel.BuildConfig
import net.seatrace.stbluesentinel.core.model.Severity
import net.seatrace.stbluesentinel.core.security.SaveResult
import net.seatrace.stbluesentinel.receiver.CheckState
import net.seatrace.stbluesentinel.receiver.UrlValidation
import net.seatrace.stbluesentinel.ui.NotificationPermissionCard
import net.seatrace.stbluesentinel.ui.components.KeyValueRow
import net.seatrace.stbluesentinel.ui.components.SectionCard
import net.seatrace.stbluesentinel.ui.components.StatusLine
import net.seatrace.stbluesentinel.ui.findActivity
import net.seatrace.stbluesentinel.ui.state.StatusLogic
import net.seatrace.stbluesentinel.ui.vm.SettingsViewModel

private enum class Confirm { CLEAR_SECRET, CLEAR_ALERTS, RESET }

@Composable
fun SettingsScreen(onBack: () -> Unit, onHelp: () -> Unit, vm: SettingsViewModel = viewModel()) {
    val context = LocalContext.current
    val cfg by vm.config.collectAsStateWithLifecycle()
    val check by vm.checkState.collectAsStateWithLifecycle()
    val health by vm.health.collectAsStateWithLifecycle()

    // Keep the screen out of screenshots / the recents thumbnail while the secret field can be on screen.
    DisposableEffect(Unit) {
        val window = context.findActivity()?.window
        window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) vm.refresh() }
        owner.lifecycle.addObserver(obs); onDispose { owner.lifecycle.removeObserver(obs) }
    }

    var urlText by remember(cfg.receiverUrl) { mutableStateOf(cfg.receiverUrl ?: "wss://") }
    var urlMsg by remember { mutableStateOf<Pair<String, Boolean>?>(null) } // text, isError
    // Typed secret lives only in memory (plain `remember`, NOT rememberSaveable, so it never enters saved instance state).
    var secretText by remember { mutableStateOf("") }
    var showSecret by remember { mutableStateOf(false) }
    var secretMsg by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    var confirm by remember { mutableStateOf<Confirm?>(null) }
    var copied by remember { mutableStateOf(false) }

    // Notification switches mirror SharedPreferences (read synchronously by the background path).
    val prefs = vm.prefs
    var master by remember { mutableStateOf(prefs.masterEnabled) }
    var test by remember { mutableStateOf(prefs.testAlertsEnabled) }
    val sev = remember { mutableStateOf(Severity.entries.associateWith { prefs.isSeverityEnabled(it) }) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { TopAppBar(title = { Text("Settings") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }) },
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

            SectionCard("Receiver") {
                OutlinedTextField(
                    value = urlText, onValueChange = { urlText = it; urlMsg = null },
                    label = { Text("Receiver URL") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, autoCorrectEnabled = false),
                    isError = urlMsg?.second == true,
                    supportingText = { Text(urlMsg?.first ?: "Your public wss:// endpoint that SeaTracePro delivers to. No credentials or query parameters.") },
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = {
                        urlMsg = when (val r = vm.saveUrl(urlText)) {
                            is UrlValidation.Valid -> { urlText = r.normalized; "Saved." to false }
                            is UrlValidation.Invalid -> r.error.message to true
                        }
                    }) { Text("Save") }
                    OutlinedButton(onClick = vm::testConnection, enabled = cfg.receiverUrlValid && check !is CheckState.Checking) {
                        Text(if (check is CheckState.Checking) "Testing…" else "Test connection")
                    }
                }
                (check as? CheckState.Done)?.let { StatusLine(it.result.userMessage(), it.result is net.seatrace.stbluesentinel.receiver.ReceiverCheckResult.Reachable) }
                Text(
                    "The test checks that your receiver is reachable over TLS from this phone. It does not prove SeaTracePro can deliver; use the test notification in SeaTracePro for that.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            SectionCard("Security") {
                OutlinedTextField(
                    value = secretText, onValueChange = { secretText = it; secretMsg = null },
                    label = { Text("BlueSentinel Signing Secret") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (showSecret) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, autoCorrectEnabled = false),
                    trailingIcon = {
                        IconButton(onClick = { showSecret = !showSecret }) {
                            Icon(if (showSecret) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, if (showSecret) "Hide secret" else "Show secret")
                        }
                    },
                    isError = secretMsg?.second == true,
                    supportingText = { Text(secretMsg?.first ?: "Used to verify the X-SeaTrace-Signature HMAC-SHA256 header.") },
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(enabled = secretText.isNotBlank(), onClick = {
                        secretMsg = when (vm.saveSecret(secretText)) {
                            SaveResult.Saved -> { secretText = ""; showSecret = false; "Secret saved securely." to false }
                            SaveResult.Invalid -> "The secret must be 16–256 visible characters with no spaces." to true
                            SaveResult.StorageError -> "Could not store the secret securely on this device." to true
                        }
                    }) { Text("Save securely") }
                    OutlinedButton(enabled = cfg.hasSecret, onClick = { confirm = Confirm.CLEAR_SECRET }) { Text("Clear secret") }
                }
                StatusLine(
                    if (cfg.hasSecret) "A signing secret is stored in the Android Keystore. It is never shown again." else "No signing secret saved. Alerts cannot be verified until you add one.",
                    cfg.hasSecret,
                )
            }

            SectionCard("Notifications") {
                SwitchRow("Enable notifications", master) { master = it; prefs.masterEnabled = it }
                listOf(Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW).forEach { s ->
                    SwitchRow(s.label.lowercase().replaceFirstChar { it.uppercase() }, sev.value.getValue(s) && master, enabled = master) {
                        prefs.setSeverityEnabled(s, it); sev.value = sev.value + (s to it)
                    }
                }
                SwitchRow("Test alerts", test && master, enabled = master) { test = it; prefs.testAlertsEnabled = it }
                Text(
                    "Switches only control Android notifications. Verified alerts are always saved to your history.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                NotificationPermissionCard(prefs)
            }

            SectionCard("Background alerts") {
                StatusLine(
                    if (health.backgroundReady) "Background notifications: Enabled" else "Background notifications: Needs attention",
                    health.backgroundReady,
                )
                KeyValueRow("Push", StatusLogic.pushLabel(health.push))
                OutlinedButton(onClick = onHelp) { Text("Help & diagnostics") }
            }

            SectionCard("This device") {
                SelectionContainer { KeyValueRow("Device ID", vm.deviceId) }
                val token = vm.fcmToken
                Text(
                    "Your receiver operator needs the push token to send alerts to this phone. Treat it as private.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedButton(enabled = token != null, onClick = {
                    val cm = context.getSystemService(ClipboardManager::class.java)
                    val clip = ClipData.newPlainText("STBlueSentinel push token", token)
                    if (Build.VERSION.SDK_INT >= 33) clip.description.extras = PersistableBundle().apply { putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true) }
                    cm.setPrimaryClip(clip); copied = true
                }) { Text(if (token == null) "Push token not available yet" else "Copy push token") }
                if (copied) Text("Copied.", style = MaterialTheme.typography.bodySmall)
            }

            SectionCard("Data") {
                OutlinedButton(onClick = { confirm = Confirm.CLEAR_ALERTS }) { Text("Clear alert history") }
                OutlinedButton(onClick = { confirm = Confirm.RESET }) { Text("Reset application") }
            }

            HorizontalDivider()
            Text("STBlueSentinel ${BuildConfig.VERSION_NAME} · net.seatrace.stbluesentinel", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    confirm?.let { what ->
        val (title, body) = when (what) {
            Confirm.CLEAR_SECRET -> "Clear signing secret?" to "Alerts cannot be verified, and will be rejected, until you save a secret again."
            Confirm.CLEAR_ALERTS -> "Clear alert history?" to "All stored alerts will be deleted from this phone."
            Confirm.RESET -> "Reset application?" to "Deletes the signing secret, receiver address, settings, alert history and device identity."
        }
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(title) }, text = { Text(body) },
            confirmButton = {
                TextButton(onClick = {
                    when (what) {
                        Confirm.CLEAR_SECRET -> vm.clearSecret()
                        Confirm.CLEAR_ALERTS -> vm.clearAlerts()
                        Confirm.RESET -> { vm.resetApplication(); master = true; test = true; sev.value = Severity.entries.associateWith { true }; secretText = "" }
                    }
                    confirm = null
                }) { Text("Confirm") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}
