package net.seatrace.stbluesentinel

import android.app.Application
import net.seatrace.stbluesentinel.notifications.NotificationChannels
import net.seatrace.stbluesentinel.push.PushSetup

/**
 * Process entry point. Android runs this whenever it starts our process - including when FCM wakes
 * the app with the UI closed - so everything the background path needs is created here or lazily
 * from [container], never from an Activity.
 */
open class StbApplication : Application() {
    val container: AppContainer by lazy { createContainer() }

    /** Overridden only by tests (to inject a fake secret store); production always uses the Keystore-backed container. */
    protected open fun createContainer(): AppContainer = AppContainer(this)

    override fun onCreate() {
        super.onCreate()
        NotificationChannels.create(this)            // idempotent
        PushSetup.refreshToken(this, container.deviceStore)
    }
}
