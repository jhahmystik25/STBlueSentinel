package net.seatrace.stbluesentinel.notifications

/** What the UI should offer the user for notification access. Delivery is never claimed as guaranteed in any state except GRANTED. */
enum class NotificationAccess {
    /** Allowed app-wide and the main alert channel is not blocked. */
    GRANTED,
    /** Android 13+: permission not granted but the system prompt can still be shown (after our explanation). */
    CAN_REQUEST,
    /** Disabled in a way only Android Settings can fix (denied twice, "don't ask again", or turned off). */
    OPEN_SETTINGS,
    /** App notifications are on but the user silenced the main "BlueSentinel Alerts" channel. */
    CHANNEL_BLOCKED,
}
