package net.seatrace.stbluesentinel.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import net.seatrace.stbluesentinel.R
import net.seatrace.stbluesentinel.core.model.Severity

/**
 * Channels (importance is fixed once created - users tune sound/vibration per channel in Android Settings):
 *  - "BlueSentinel Alerts"      HIGH    critical + high   (heads-up)
 *  - "BlueSentinel Updates"     DEFAULT medium + low + info
 *  - "BlueSentinel Test Alerts" DEFAULT notification_test / "test": true (never shares a channel with real incidents)
 * None bypass Do Not Disturb; that is the user's choice to grant.
 */
object NotificationChannels {
    const val ALERTS = "bluesentinel_alerts"
    const val UPDATES = "bluesentinel_updates"
    const val TESTS = "bluesentinel_tests"

    fun channelFor(severity: Severity, isTest: Boolean): String = when {
        isTest -> TESTS
        severity == Severity.CRITICAL || severity == Severity.HIGH -> ALERTS
        else -> UPDATES
    }

    fun create(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)
        fun channel(id: String, nameRes: Int, descRes: Int, importance: Int) =
            NotificationChannel(id, context.getString(nameRes), importance).apply {
                description = context.getString(descRes)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PRIVATE
                setShowBadge(true)
            }
        nm.createNotificationChannels(
            listOf(
                channel(ALERTS, R.string.channel_alerts_name, R.string.channel_alerts_desc, NotificationManager.IMPORTANCE_HIGH),
                channel(UPDATES, R.string.channel_updates_name, R.string.channel_updates_desc, NotificationManager.IMPORTANCE_DEFAULT),
                channel(TESTS, R.string.channel_tests_name, R.string.channel_tests_desc, NotificationManager.IMPORTANCE_DEFAULT),
            ),
        )
    }

    /** True if the user has switched this specific channel off in Android Settings. */
    fun isBlocked(context: Context, channelId: String): Boolean =
        context.getSystemService(NotificationManager::class.java).getNotificationChannel(channelId)
            ?.importance == NotificationManager.IMPORTANCE_NONE
}
