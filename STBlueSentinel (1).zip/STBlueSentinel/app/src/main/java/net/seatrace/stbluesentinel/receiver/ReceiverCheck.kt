package net.seatrace.stbluesentinel.receiver

/**
 * Result of the optional "Test connection" action. IMPORTANT semantics: this checks that the receiver's public
 * wss:// endpoint is reachable from THIS phone (DNS, TLS certificate validation, WebSocket upgrade). It does not
 * and cannot prove SeaTracePro can deliver alerts: the phone is never a SeaTracePro WebSocket client.
 * An HTTP rejection (e.g. 401/403 because the probe carries no signed X-SeaTrace-* headers) is the EXPECTED reply
 * from a correctly secured gateway and counts as reachable.
 */
sealed interface ReceiverCheckResult {
    data class Reachable(val httpStatus: Int?) : ReceiverCheckResult
    data object DnsFailure : ReceiverCheckResult
    data object TlsFailure : ReceiverCheckResult
    data object Timeout : ReceiverCheckResult
    data object Error : ReceiverCheckResult

    fun userMessage(): String = when (this) {
        is Reachable -> "Receiver reachable. DNS and TLS are valid." +
            (if (httpStatus != null && httpStatus != 101) " It refused an unsigned probe (HTTP $httpStatus), as a secured gateway should." else "")
        DnsFailure -> "The receiver's hostname could not be resolved. Check the address and your network connection."
        TlsFailure -> "The receiver's TLS certificate could not be validated. A valid, publicly trusted certificate is required."
        Timeout -> "The receiver did not respond in time."
        Error -> "Could not connect to the receiver."
    }
}

sealed interface CheckState {
    data object Idle : CheckState
    data object Checking : CheckState
    data class Done(val result: ReceiverCheckResult, val atMillis: Long) : CheckState
}
