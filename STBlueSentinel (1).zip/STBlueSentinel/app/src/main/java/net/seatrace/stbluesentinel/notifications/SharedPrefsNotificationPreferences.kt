package net.seatrace.stbluesentinel.notifications

import android.content.Context
import net.seatrace.stbluesentinel.core.model.Severity

/** Non-secret notification switches. Synchronous reads so the FCM background path never waits on a UI layer. */
class SharedPrefsNotificationPreferences(context: Context) : NotificationPreferences {
    private val prefs = context.applicationContext.getSharedPreferences("stb_notification_prefs", Context.MODE_PRIVATE)

    override var masterEnabled: Boolean
        get() = prefs.getBoolean(K_MASTER, true)
        set(v) = prefs.edit().putBoolean(K_MASTER, v).apply()

    override var testAlertsEnabled: Boolean
        get() = prefs.getBoolean(K_TEST, true)
        set(v) = prefs.edit().putBoolean(K_TEST, v).apply()

    override fun isSeverityEnabled(severity: Severity): Boolean = prefs.getBoolean("sev_${severity.wire}", true)
    fun setSeverityEnabled(severity: Severity, enabled: Boolean) = prefs.edit().putBoolean("sev_${severity.wire}", enabled).apply()

    /** Set when the user has been shown the Android runtime-permission prompt (used to tell "never asked" from "denied"). */
    var permissionRequested: Boolean
        get() = prefs.getBoolean(K_ASKED, false)
        set(v) = prefs.edit().putBoolean(K_ASKED, v).apply()

    fun clear() = prefs.edit().clear().apply()

    private companion object { const val K_MASTER = "master"; const val K_TEST = "test_alerts"; const val K_ASKED = "permission_requested" }
}
