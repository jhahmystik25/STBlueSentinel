package net.seatrace.stbluesentinel.core.model

/** Documented severities (lower-case on the wire). Severity is always shown with text + icon, never colour alone. */
enum class Severity(val wire: String, val label: String) {
    INFO("info", "INFO"),
    LOW("low", "LOW"),
    MEDIUM("medium", "MEDIUM"),
    HIGH("high", "HIGH"),
    CRITICAL("critical", "CRITICAL");

    companion object {
        fun fromWire(value: String?): Severity? = value?.lowercase()?.let { v -> entries.firstOrNull { it.wire == v } }
    }
}

/**
 * The documented alert types only. A type not in this list (e.g. added in a later schema 1.x) maps
 * to [UNKNOWN] so a correctly-signed alert is never silently dropped; the raw string is kept in the
 * database. `position_update` is intentionally absent: it is not delivered externally.
 */
enum class AlertType(val wire: String) {
    DANGER_ZONE_ENTRY("danger_zone_entry"),
    THREAT_AREA_DETECTED("threat_area_detected"),
    DANGER_ZONE_APPROACH("danger_zone_approach"),
    DANGER_ZONE_EXIT("danger_zone_exit"),
    NEW_INCIDENT_NEARBY("new_incident_nearby"),
    TRANSMISSION_LOST("transmission_lost"),
    TRANSMISSION_RESUMED("transmission_resumed"),
    SPEED_CHANGE("speed_change"),
    COURSE_CHANGE("course_change"),
    DISTRESS_STATUS("distress_status"),
    NOTIFICATION_TEST("notification_test"),
    UNKNOWN("");

    companion object {
        fun fromWire(value: String?): AlertType = entries.firstOrNull { it != UNKNOWN && it.wire == value } ?: UNKNOWN
    }
}

/** Final disposition of an incoming alert. Only [VERIFIED] may ever raise a live-security notification. */
enum class DeliveryStatus { VERIFIED, STALE, REJECTED }
