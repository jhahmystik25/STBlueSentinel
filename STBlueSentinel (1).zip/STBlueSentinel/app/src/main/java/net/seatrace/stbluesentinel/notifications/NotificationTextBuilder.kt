package net.seatrace.stbluesentinel.notifications

import net.seatrace.stbluesentinel.core.model.Severity

data class NotificationText(
    val title: String,
    val body: String,
    val bigText: String,
    /** Shown on a locked screen when the user hides sensitive content: no vessel or position data. */
    val publicTitle: String,
    val publicBody: String,
)

/** Pure text builder so wording (and the real-vs-test distinction) is unit-testable. Severity is always spelled out - never colour alone. */
object NotificationTextBuilder {
    const val TEST_TITLE = "TEST ALERT — NOT A REAL INCIDENT"

    fun build(
        severity: Severity,
        isTest: Boolean,
        alertTitle: String,
        shipName: String?,
        areaLabel: String?,
        testNotice: String?,
    ): NotificationText {
        fun lines(vararg l: String?) = l.filter { !it.isNullOrBlank() }.joinToString("\n")
        return if (isTest) {
            NotificationText(
                title = TEST_TITLE,
                body = alertTitle,
                bigText = lines(alertTitle, testNotice, shipName, "Test notification only. Tap for details."),
                publicTitle = "BlueSentinel test alert",
                publicBody = "Not a real incident.",
            )
        } else {
            val label = "BlueSentinel — ${severity.label}"
            NotificationText(
                title = label,
                body = alertTitle,
                bigText = lines(alertTitle, shipName, areaLabel, "Tap for details."),
                publicTitle = label,
                publicBody = "New alert. Unlock to view details.",
            )
        }
    }
}
