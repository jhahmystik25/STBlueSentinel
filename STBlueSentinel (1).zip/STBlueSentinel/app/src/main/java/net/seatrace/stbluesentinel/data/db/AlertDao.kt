package net.seatrace.stbluesentinel.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

data class SeverityCount(val severity: String, val count: Int)

@Dao
interface AlertDao {
    /**
     * Atomic dedupe: returns the new row id, or -1 if an alert with the same alert_id already exists
     * (the unique index makes the insert a no-op). Callers notify ONLY when the result is >= 0.
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(alert: AlertEntity): Long

    @Query("SELECT EXISTS(SELECT 1 FROM alerts WHERE alert_id = :alertId)")
    suspend fun exists(alertId: String): Boolean

    @Query("SELECT * FROM alerts ORDER BY received_at DESC, id DESC")
    fun observeAll(): Flow<List<AlertEntity>>

    @Query("SELECT * FROM alerts WHERE id = :id")
    fun observeById(id: Long): Flow<AlertEntity?>

    @Query("SELECT * FROM alerts WHERE id = :id")
    suspend fun getById(id: Long): AlertEntity?

    @Query("SELECT * FROM alerts WHERE alert_id = :alertId")
    suspend fun getByAlertId(alertId: String): AlertEntity?

    @Query("SELECT * FROM alerts WHERE test_alert = 0 ORDER BY received_at DESC, id DESC LIMIT 1")
    fun observeLatestReal(): Flow<AlertEntity?>

    /** Real (non-test) alert counts per severity for the dashboard. */
    @Query("SELECT severity, COUNT(*) AS count FROM alerts WHERE test_alert = 0 GROUP BY severity")
    fun observeSeverityCounts(): Flow<List<SeverityCount>>

    @Query("SELECT COUNT(*) FROM alerts WHERE read = 0")
    fun observeUnreadCount(): Flow<Int>

    @Query("UPDATE alerts SET read = 1 WHERE id = :id")
    suspend fun markRead(id: Long)

    @Query("UPDATE alerts SET read = 1")
    suspend fun markAllRead()

    @Query("DELETE FROM alerts")
    suspend fun clearAll()
}

@Dao
interface RejectionDao {
    @Insert
    suspend fun insert(rejection: RejectionEntity)

    /** Keep the audit trail bounded. */
    @Query("DELETE FROM rejections WHERE id NOT IN (SELECT id FROM rejections ORDER BY id DESC LIMIT :keep)")
    suspend fun prune(keep: Int)

    @Query("SELECT * FROM rejections ORDER BY id DESC LIMIT :limit")
    fun observeRecent(limit: Int): Flow<List<RejectionEntity>>

    @Query("SELECT COUNT(*) FROM rejections")
    fun observeCount(): Flow<Int>

    @Query("DELETE FROM rejections")
    suspend fun clearAll()
}
