package net.seatrace.stbluesentinel.push

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import net.seatrace.stbluesentinel.core.SafeLog

object PushSetup {
    /** False when google-services.json was not supplied at build time: push cannot work, and the UI says so. */
    fun isConfigured(context: Context): Boolean =
        try { FirebaseApp.getApps(context.applicationContext).isNotEmpty() } catch (_: Exception) { false }

    fun status(context: Context, store: DeviceStore): PushStatus = when {
        !isConfigured(context) -> PushStatus.NOT_CONFIGURED
        store.fcmToken.isNullOrEmpty() -> PushStatus.TOKEN_PENDING
        else -> PushStatus.ACTIVE
    }

    /** Fetches the current token (also handles first run and token refresh gaps). Failures are non-fatal; FCM retries on its own. */
    fun refreshToken(context: Context, store: DeviceStore) {
        if (!isConfigured(context)) { SafeLog.w("Push not configured: google-services.json missing"); return }
        try {
            FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                if (task.isSuccessful && !task.result.isNullOrEmpty()) {
                    store.fcmToken = task.result
                    SafeLog.i("FCM token registered")
                } else {
                    SafeLog.w("FCM token fetch failed") // never include the exception message
                }
            }
        } catch (_: Exception) {
            SafeLog.w("FCM unavailable")
        }
    }
}
