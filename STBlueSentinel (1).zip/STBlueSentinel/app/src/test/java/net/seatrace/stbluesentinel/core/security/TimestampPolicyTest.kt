package net.seatrace.stbluesentinel.core.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TimestampPolicyTest {
    private val signed = 1_790_000_000L
    private fun at(age: Long, header: String = signed.toString()) = TimestampPolicy.evaluate(header, signed + age)

    @Test fun policyConstants_matchTheAgreedDesign() {
        assertEquals(300L, TimestampPolicy.GATEWAY_REPLAY_WINDOW_SECONDS)   // gateway rule, unchanged
        assertEquals(900L, TimestampPolicy.LIVE_WINDOW_SECONDS)             // 15 minutes
        assertEquals(60L, TimestampPolicy.FUTURE_SKEW_SECONDS)
    }

    @Test fun freshAlert_isWithinLiveWindow() {
        val c = at(5)
        assertEquals(TimestampStatus.WITHIN_LIVE_WINDOW, c.status); assertEquals(5L, c.ageSeconds); assertNull(c.reason)
    }

    @Test fun delayedFcmUpTo15Minutes_isStillLive() {
        assertEquals(TimestampStatus.WITHIN_LIVE_WINDOW, at(300).status)   // old 5-minute boundary: fine on the client
        assertEquals(TimestampStatus.WITHIN_LIVE_WINDOW, at(899).status)
        assertEquals(TimestampStatus.WITHIN_LIVE_WINDOW, at(900).status)   // inclusive boundary
    }

    @Test fun olderThan15Minutes_isStale_notLive() {
        val c = at(901)
        assertEquals(TimestampStatus.STALE, c.status); assertNull(c.reason)
    }

    @Test fun twoHourOldAlert_isNotTreatedAsLive() {
        assertEquals(TimestampStatus.STALE, at(2 * 60 * 60).status)
    }

    @Test fun olderThan24Hours_isRejected() {
        assertEquals(TimestampStatus.STALE, at(86_400).status)
        val c = at(86_401)
        assertEquals(TimestampStatus.REJECTED, c.status); assertEquals(RejectReason.TIMESTAMP_TOO_OLD, c.reason)
    }

    @Test fun smallClockSkewIntoTheFuture_isTolerated_andAgeClampedToZero() {
        val c = at(-60)
        assertEquals(TimestampStatus.WITHIN_LIVE_WINDOW, c.status); assertEquals(0L, c.ageSeconds)
    }

    @Test fun futureDatedBeyondSkew_isRejected() {
        val c = at(-61)
        assertEquals(TimestampStatus.REJECTED, c.status); assertEquals(RejectReason.FUTURE_TIMESTAMP, c.reason)
        assertEquals(RejectReason.FUTURE_TIMESTAMP, at(-3600).reason)
    }

    @Test fun missingTimestamp_isRejected() {
        assertEquals(RejectReason.TIMESTAMP_MISSING, TimestampPolicy.evaluate(null, signed).reason)
        assertEquals(RejectReason.TIMESTAMP_MISSING, TimestampPolicy.evaluate("", signed).reason)
    }

    @Test fun invalidTimestamps_areRejected() {
        listOf("abc", "-5", "1790000000x", " 1790000000", "1790000000 ", "1.790e9", "0", "12345", "99999999999999", "NaN", "1790000000.")
            .forEach { assertEquals("header='$it'", RejectReason.INVALID_TIMESTAMP, TimestampPolicy.evaluate(it, signed).reason) }
    }

    @Test fun fractionalSecondsAreAccepted_asDocumentedReferenceVerifiersParseFloats() {
        assertEquals(TimestampStatus.WITHIN_LIVE_WINDOW, at(3, "1790000000.250").status)
    }
}
