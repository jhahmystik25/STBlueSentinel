package net.seatrace.stbluesentinel.notifications

import android.Manifest
import android.app.Application
import android.app.NotificationManager
import android.provider.Settings
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf

@RunWith(RobolectricTestRunner::class)
class NotificationAccessCheckerTest {
    private val app: Application = ApplicationProvider.getApplicationContext()
    private val shadowManager get() = shadowOf(app.getSystemService(NotificationManager::class.java))

    @Before fun setUp() = NotificationChannels.create(app)

    @Test fun allowed_isGranted() {
        shadowOf(app).grantPermissions(Manifest.permission.POST_NOTIFICATIONS)
        assertEquals(NotificationAccess.GRANTED, NotificationAccessChecker.evaluate(app, null, alreadyRequested = false))
    }

    @Test fun neverAsked_canRequest_afterTheExplanationIsShown() {
        shadowManager.setNotificationsEnabled(false); shadowOf(app).denyPermissions(Manifest.permission.POST_NOTIFICATIONS)
        assertEquals(NotificationAccess.CAN_REQUEST, NotificationAccessChecker.evaluate(app, null, alreadyRequested = false))
    }

    @Test fun askedAndDenied_withNoWayToAskAgain_sendsTheUserToSettings() {
        shadowManager.setNotificationsEnabled(false); shadowOf(app).denyPermissions(Manifest.permission.POST_NOTIFICATIONS)
        assertEquals(NotificationAccess.OPEN_SETTINGS, NotificationAccessChecker.evaluate(app, null, alreadyRequested = true))
    }

    @Test fun silencedAlertChannel_isReportedSeparatelyFromAppLevelNotifications() {
        shadowOf(app).grantPermissions(Manifest.permission.POST_NOTIFICATIONS)
        val m = app.getSystemService(NotificationManager::class.java)
        m.deleteNotificationChannel(NotificationChannels.ALERTS)
        m.createNotificationChannel(android.app.NotificationChannel(NotificationChannels.ALERTS, "x", NotificationManager.IMPORTANCE_NONE))
        assertEquals(NotificationAccess.CHANNEL_BLOCKED, NotificationAccessChecker.evaluate(app, null, alreadyRequested = true))
    }

    @Test fun settingsIntentTargetsThisAppsNotificationPage() {
        val i = NotificationAccessChecker.settingsIntent(app)
        assertEquals(Settings.ACTION_APP_NOTIFICATION_SETTINGS, i.action); assertEquals(app.packageName, i.getStringExtra(Settings.EXTRA_APP_PACKAGE))
    }
}
