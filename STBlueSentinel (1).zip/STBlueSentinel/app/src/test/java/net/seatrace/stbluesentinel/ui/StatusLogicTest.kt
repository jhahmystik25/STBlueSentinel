package net.seatrace.stbluesentinel.ui

import net.seatrace.stbluesentinel.notifications.NotificationAccess
import net.seatrace.stbluesentinel.push.PushStatus
import net.seatrace.stbluesentinel.receiver.CheckState
import net.seatrace.stbluesentinel.receiver.ReceiverCheckResult
import net.seatrace.stbluesentinel.ui.state.ReceiverStatus
import net.seatrace.stbluesentinel.ui.state.SecurityLevel
import net.seatrace.stbluesentinel.ui.state.StatusLogic
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StatusLogicTest {
    private fun sec(url: Boolean = true, secret: Boolean = true, push: PushStatus = PushStatus.ACTIVE, n: NotificationAccess = NotificationAccess.GRANTED) =
        StatusLogic.security(url, secret, push, n)

    @Test fun fullyReady_isSecure_withAllFourLinesOk() {
        val s = sec(); assertEquals(SecurityLevel.SECURE, s.level); assertTrue(s.lines.all { it.ok })
        assertEquals("Background alerts enabled", s.lines.last().text)
    }

    @Test fun missingSecretOrUrl_isNotConfigured_neverSecure() {
        assertEquals(SecurityLevel.NOT_CONFIGURED, sec(secret = false).level)
        assertEquals(SecurityLevel.NOT_CONFIGURED, sec(url = false).level)
        assertFalse(sec(secret = false).lines.first().ok)
    }

    @Test fun configuredButPushOrNotificationsBroken_isAttention_andSaysWhy() {
        assertEquals(SecurityLevel.ATTENTION, sec(push = PushStatus.NOT_CONFIGURED).level)
        assertTrue(sec(push = PushStatus.NOT_CONFIGURED).lines.last().text.contains("push is not configured"))
        assertEquals(SecurityLevel.ATTENTION, sec(push = PushStatus.TOKEN_PENDING).level)
        assertTrue(sec(n = NotificationAccess.OPEN_SETTINGS).lines.last().text.contains("notifications are disabled"))
        assertTrue(sec(n = NotificationAccess.CHANNEL_BLOCKED).lines.last().text.contains("silenced"))
    }

    @Test fun receiverStatus_neverClaimsConnectedWithoutASuccessfulCheck() {
        assertEquals(ReceiverStatus.NOT_CONFIGURED, StatusLogic.receiverStatus(false, CheckState.Idle, false))
        assertEquals(ReceiverStatus.WAITING, StatusLogic.receiverStatus(true, CheckState.Idle, false))
        assertEquals(ReceiverStatus.CONNECTING, StatusLogic.receiverStatus(true, CheckState.Checking, false))
        assertEquals(ReceiverStatus.CONNECTED, StatusLogic.receiverStatus(true, CheckState.Done(ReceiverCheckResult.Reachable(401), 1), false))
        assertEquals(ReceiverStatus.DISCONNECTED, StatusLogic.receiverStatus(true, CheckState.Done(ReceiverCheckResult.Timeout, 1), false))
        assertEquals(ReceiverStatus.CONNECTION_ERROR, StatusLogic.receiverStatus(true, CheckState.Done(ReceiverCheckResult.TlsFailure, 1), false))
        assertEquals(ReceiverStatus.CONNECTION_ERROR, StatusLogic.receiverStatus(true, CheckState.Done(ReceiverCheckResult.DnsFailure, 1), false))
    }

    @Test fun signatureFailure_takesPrecedence_afterConnectingState() {
        val ok = CheckState.Done(ReceiverCheckResult.Reachable(101), 1)
        assertEquals(ReceiverStatus.VERIFICATION_FAILED, StatusLogic.receiverStatus(true, ok, true))
        assertEquals(ReceiverStatus.CONNECTING, StatusLogic.receiverStatus(true, CheckState.Checking, true))
    }

    @Test fun reachableMessage_explainsExpectedRejectionOfUnsignedProbe() {
        assertTrue(ReceiverCheckResult.Reachable(401).userMessage().contains("refused an unsigned probe"))
        assertFalse(ReceiverCheckResult.Reachable(101).userMessage().contains("refused"))
    }

    @Test fun standbyBuckets() {
        assertEquals("Active", StatusLogic.standbyBucketLabel(10)); assertEquals("Rare", StatusLogic.standbyBucketLabel(40))
        assertEquals("Restricted", StatusLogic.standbyBucketLabel(45)); assertEquals("Unknown", StatusLogic.standbyBucketLabel(null))
        assertFalse(StatusLogic.isStandbyConcerning(30)); assertTrue(StatusLogic.isStandbyConcerning(40)); assertFalse(StatusLogic.isStandbyConcerning(null))
    }
}
