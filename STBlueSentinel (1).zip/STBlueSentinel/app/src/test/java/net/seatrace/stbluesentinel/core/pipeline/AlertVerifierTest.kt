package net.seatrace.stbluesentinel.core.pipeline

import net.seatrace.stbluesentinel.core.model.DeliveryStatus
import net.seatrace.stbluesentinel.core.security.RejectReason
import net.seatrace.stbluesentinel.core.security.SignatureVerifier
import net.seatrace.stbluesentinel.core.security.TestVectors
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AlertVerifierTest {
    private val secret = TestVectors.SECRET_BYTES
    private val signedAt = TestVectors.TIMESTAMP.toLong()

    private fun verifier(now: Long = TestVectors.NOW, provider: () -> ByteArray? = { secret.copyOf() }) =
        AlertVerifier(secretProvider = provider, nowEpochSeconds = { now })

    /** Builds a correctly signed envelope for an arbitrary frame text. */
    private fun signed(
        frame: String = TestVectors.FRAME,
        ts: String = TestVectors.TIMESTAMP,
        alertId: String? = "12345",
        event: String? = "vessel_alert",
    ): AlertEnvelope {
        val bytes = frame.toByteArray(Charsets.UTF_8)
        val sig = "sha256=" + SignatureVerifier.computeHex(secret, ts, bytes)
        return AlertEnvelope(event, alertId, ts, sig, bytes)
    }

    private fun minimalFrame(extra: String = "", id: String = "12345", type: String = "speed_change", severity: String = "low") =
        """{"schema_version":"1.0","source":"seatracepro","product":"bluesentinel","event":"vessel_alert",""" +
            """"alert_id":"$id","alert_type":"$type","severity":"$severity","title":"T"$extra}"""

    private fun rejected(o: VerificationOutcome) = (o as VerificationOutcome.Rejected)
    private fun accepted(o: VerificationOutcome) = (o as VerificationOutcome.Accepted)

    @Test fun validFreshAlert_isVerified_andUsesExactFrameText() {
        val out = accepted(verifier().verify(signed()))
        assertEquals(DeliveryStatus.VERIFIED, out.status)
        assertEquals(TestVectors.FRAME, out.rawFrame)          // stored byte-for-byte, not re-serialised
        assertEquals("12345", out.alert.alertId)
        assertEquals("MV \u00C5LESUND", out.alert.vessel?.shipName)
    }

    @Test fun delayedBeyond15Minutes_isStale_notVerified() {
        val out = accepted(verifier(now = signedAt + 901).verify(signed()))
        assertEquals(DeliveryStatus.STALE, out.status)
    }

    @Test fun twoHourOldAlert_isStale_neverLive() {
        assertEquals(DeliveryStatus.STALE, accepted(verifier(now = signedAt + 7200).verify(signed())).status)
    }

    @Test fun staleAlertStillRequiresValidHmac() {
        val tampered = signed().let { AlertEnvelope(it.event, it.alertId, it.timestamp, "sha256=" + "0".repeat(64), it.frame) }
        assertEquals(RejectReason.SIGNATURE_MISMATCH, rejected(verifier(now = signedAt + 3600).verify(tampered)).reason)
    }

    @Test fun futureDatedBeyondSkew_isRejected() =
        assertEquals(RejectReason.FUTURE_TIMESTAMP, rejected(verifier(now = signedAt - 120).verify(signed())).reason)

    @Test fun olderThan24h_isRejected() =
        assertEquals(RejectReason.TIMESTAMP_TOO_OLD, rejected(verifier(now = signedAt + 86_401).verify(signed())).reason)

    @Test fun modifiedFrame_isRejected() {
        val e = signed()
        val modified = AlertEnvelope(e.event, e.alertId, e.timestamp, e.signature, TestVectors.FRAME.replace("high", "low").toByteArray())
        assertEquals(RejectReason.SIGNATURE_MISMATCH, rejected(verifier().verify(modified)).reason)
    }

    @Test fun missingSignature_missingTimestamp_missingHeaders_areRejected() {
        val e = signed()
        assertEquals(RejectReason.SIGNATURE_MISSING, rejected(verifier().verify(AlertEnvelope(e.event, e.alertId, e.timestamp, null, e.frame))).reason)
        assertEquals(RejectReason.TIMESTAMP_MISSING, rejected(verifier().verify(AlertEnvelope(e.event, e.alertId, null, e.signature, e.frame))).reason)
        assertEquals(RejectReason.MISSING_HEADER, rejected(verifier().verify(AlertEnvelope(e.event, null, e.timestamp, e.signature, e.frame))).reason)
        assertEquals(RejectReason.MISSING_HEADER, rejected(verifier().verify(AlertEnvelope(null, e.alertId, e.timestamp, e.signature, e.frame))).reason)
        assertEquals(RejectReason.FRAME_MISSING, rejected(verifier().verify(AlertEnvelope(e.event, e.alertId, e.timestamp, e.signature, null))).reason)
    }

    @Test fun wrongEventHeader_isRejected() =
        assertEquals(RejectReason.WRONG_EVENT, rejected(verifier().verify(signed(event = "something_else"))).reason)

    @Test fun oversizedFrame_isRejected() {
        val big = minimalFrame(extra = ""","pad":"${"x".repeat(AlertVerifier.MAX_FRAME_BYTES)}"""")
        assertEquals(RejectReason.FRAME_TOO_LARGE, rejected(verifier().verify(signed(big))).reason)
    }

    @Test fun noSecretConfigured_isRejected_notVerified() =
        assertEquals(RejectReason.SECRET_NOT_CONFIGURED, rejected(verifier(provider = { null }).verify(signed())).reason)

    @Test fun secretBytesAreZeroedAfterUse() {
        val handed = secret.copyOf()
        verifier(provider = { handed }).verify(signed())
        assertTrue(handed.all { it == 0.toByte() })
    }

    @Test fun malformedJson_afterValidSignature_isRejected() =
        assertEquals(RejectReason.MALFORMED_JSON, rejected(verifier().verify(signed("{not json"))).reason)

    @Test fun invalidUtf8_afterValidSignature_isRejected() {
        val bad = byteArrayOf(0x7B, 0xC3.toByte(), 0x28, 0x7D) // "{" + invalid 2-byte sequence + "}"
        val sig = "sha256=" + SignatureVerifier.computeHex(secret, TestVectors.TIMESTAMP, bad)
        val out = verifier().verify(AlertEnvelope("vessel_alert", "12345", TestVectors.TIMESTAMP, sig, bad))
        assertEquals(RejectReason.MALFORMED_JSON, rejected(out).reason)
    }

    @Test fun optionalFieldsMissing_parsesSuccessfully() {
        val out = accepted(verifier().verify(signed(minimalFrame())))
        assertNull(out.alert.vessel); assertNull(out.alert.threat); assertNull(out.alert.message); assertNull(out.alert.timestampUtc)
    }

    @Test fun unknownFields_areIgnored() {
        val frame = minimalFrame(extra = ""","future_top":{"a":1},"vessel":{"mmsi":123456789,"new_vessel_field":[1,2]},"threat":{"state":"INSIDE","x":true}""")
        val out = accepted(verifier().verify(signed(frame)))
        assertEquals(123456789L, out.alert.vessel?.mmsi); assertEquals("INSIDE", out.alert.threat?.state)
    }

    @Test fun alertIdHeaderMustMatchBody() =
        assertEquals(RejectReason.ALERT_ID_MISMATCH, rejected(verifier().verify(signed(minimalFrame(id = "999"), alertId = "12345"))).reason)

    @Test fun invalidSeverity_orSchema_isRejected() {
        assertEquals(RejectReason.INVALID_SCHEMA, rejected(verifier().verify(signed(minimalFrame(severity = "apocalyptic")))).reason)
        assertEquals(RejectReason.UNSUPPORTED_SCHEMA, rejected(verifier().verify(signed(minimalFrame().replace("\"1.0\"", "\"2.0\"")))).reason)
        assertEquals(RejectReason.INVALID_SCHEMA, rejected(verifier().verify(signed(minimalFrame().replace("seatracepro", "other")))).reason)
    }

    @Test fun laterMinorSchemaVersion_isAccepted() =
        assertEquals(DeliveryStatus.VERIFIED, accepted(verifier().verify(signed(minimalFrame().replace("\"1.0\"", "\"1.3\"")))).status)

    @Test fun unknownAlertType_isKeptNotDropped() =
        assertEquals("brand_new_type", accepted(verifier().verify(signed(minimalFrame(type = "brand_new_type")))).alert.alertType)

    @Test fun notificationTest_isMarkedAsTestAlert() {
        val frame = minimalFrame(extra = ""","test":true,"test_notice":"Dummy message","vessel":{"ship_name":"TEST VESSEL"}""", type = "notification_test", severity = "info")
        val out = accepted(verifier().verify(signed(frame)))
        assertTrue(out.alert.isTest); assertEquals("Dummy message", out.alert.testNotice)
    }

    @Test fun alertTypeNotificationTest_isTestEvenWithoutTestFlag() =
        assertTrue(accepted(verifier().verify(signed(minimalFrame(type = "notification_test", severity = "info")))).alert.isTest)
}
