package net.seatrace.stbluesentinel.notifications

import android.Manifest
import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import androidx.test.core.app.ApplicationProvider
import net.seatrace.stbluesentinel.MainActivity
import net.seatrace.stbluesentinel.testutil.alertEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf

@RunWith(RobolectricTestRunner::class)
class AndroidAlertNotifierTest {
    private val app: Application = ApplicationProvider.getApplicationContext()
    private val manager get() = app.getSystemService(NotificationManager::class.java)
    private val shadowManager get() = shadowOf(manager)
    private val notifier get() = AndroidNotifierHolder.create(app)

    @Before fun setUp() {
        shadowOf(app).grantPermissions(Manifest.permission.POST_NOTIFICATIONS)
        NotificationChannels.create(app)
    }

    private fun title(n: Notification) = n.extras.getCharSequence(Notification.EXTRA_TITLE).toString()

    @Test fun threeChannelsExist_withTheDesignedImportance_andPrivateLockScreen() {
        fun ch(id: String) = manager.getNotificationChannel(id)!!
        assertEquals("BlueSentinel Alerts", ch(NotificationChannels.ALERTS).name); assertEquals(NotificationManager.IMPORTANCE_HIGH, ch(NotificationChannels.ALERTS).importance)
        assertEquals(NotificationManager.IMPORTANCE_DEFAULT, ch(NotificationChannels.UPDATES).importance)
        assertEquals("BlueSentinel Test Alerts", ch(NotificationChannels.TESTS).name)
        listOf(NotificationChannels.ALERTS, NotificationChannels.UPDATES, NotificationChannels.TESTS)
            .forEach { assertEquals(Notification.VISIBILITY_PRIVATE, ch(it).lockscreenVisibility) }
    }

    @Test fun highAlert_postsToTheAlertsChannel_withSeverityWrittenInTheTitle() {
        assertTrue(notifier.notify(alertEntity("1", "high").copy(id = 7, shipName = "MV EXAMPLE", areaLabel = "Near Lagos (NGA)", title = "Entered high-incident area")))
        val n = shadowManager.getNotification(7)!!
        assertEquals("BlueSentinel — HIGH", title(n)); assertEquals(NotificationChannels.ALERTS, n.channelId)
        assertEquals("Entered high-incident area\nMV EXAMPLE\nNear Lagos (NGA)\nTap for details.", n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT).toString())
    }

    @Test fun criticalGoesToAlertsChannel_mediumAndLowToUpdates() {
        notifier.notify(alertEntity("c", "critical").copy(id = 1)); notifier.notify(alertEntity("m", "medium").copy(id = 2)); notifier.notify(alertEntity("l", "low").copy(id = 3))
        assertEquals(NotificationChannels.ALERTS, shadowManager.getNotification(1)!!.channelId)
        assertEquals(NotificationChannels.UPDATES, shadowManager.getNotification(2)!!.channelId)
        assertEquals(NotificationChannels.UPDATES, shadowManager.getNotification(3)!!.channelId)
    }

    @Test fun testAlert_usesItsOwnChannel_andIsUnmistakablyNotARealIncident() {
        notifier.notify(alertEntity("t", "info", test = true).copy(id = 9))
        val n = shadowManager.getNotification(9)!!
        assertEquals(NotificationTextBuilder.TEST_TITLE, title(n)); assertEquals(NotificationChannels.TESTS, n.channelId)
        assertFalse(title(n).contains("BlueSentinel —"))
        assertTrue(n.extras.getCharSequence(Notification.EXTRA_SUB_TEXT).toString().contains("not a real incident"))
    }

    @Test fun tappingOpensTheMainActivity_withTheRowIdAndNothingSensitive() {
        notifier.notify(alertEntity("1").copy(id = 42, shipName = "MV SECRETSHIP"))
        val intent = shadowOf(shadowManager.getNotification(42)!!.contentIntent).savedIntent
        assertEquals(MainActivity::class.java.name, intent.component!!.className)
        assertEquals(AppIntents.ACTION_OPEN_ALERT, intent.action); assertEquals(42L, intent.getLongExtra(AppIntents.EXTRA_ALERT_ROW_ID, -1))
        assertEquals(setOf(AppIntents.EXTRA_ALERT_ROW_ID), intent.extras!!.keySet())
    }

    @Test fun lockScreenPublicVersion_hasNoVesselOrAreaData() {
        notifier.notify(alertEntity("1", "critical").copy(id = 5, shipName = "MV SECRETSHIP", areaLabel = "Gulf of Guinea"))
        val pub = shadowManager.getNotification(5)!!.publicVersion
        assertNotNull(pub)
        val text = title(pub) + " " + pub.extras.getCharSequence(Notification.EXTRA_TEXT)
        assertFalse(text.contains("SECRETSHIP")); assertFalse(text.contains("Guinea")); assertTrue(text.contains("CRITICAL"))
    }

    @Test fun notificationsDisabledInAndroid_nothingIsPosted_andCallerIsToldSo() {
        shadowManager.setNotificationsEnabled(false)
        assertFalse(notifier.notify(alertEntity("1").copy(id = 1)))
        assertTrue(shadowManager.allNotifications.isEmpty())
    }

    @Test fun permissionDenied_nothingIsPosted() {
        shadowOf(app).denyPermissions(Manifest.permission.POST_NOTIFICATIONS)
        assertFalse(notifier.notify(alertEntity("1").copy(id = 1)))
        assertTrue(shadowManager.allNotifications.isEmpty())
    }

    @Test fun notificationIdIsTheRowId_soOneRowCanNeverProduceTwoNotifications() {
        notifier.notify(alertEntity("1").copy(id = 3)); notifier.notify(alertEntity("1").copy(id = 3))
        assertEquals(1, shadowManager.allNotifications.size)
    }

    @Test fun channelBlockedByUser_isDetected() {
        manager.deleteNotificationChannel(NotificationChannels.ALERTS)
        manager.createNotificationChannel(NotificationChannel(NotificationChannels.ALERTS, "x", NotificationManager.IMPORTANCE_NONE))
        assertTrue(NotificationChannels.isBlocked(app, NotificationChannels.ALERTS))
        assertFalse(NotificationChannels.isBlocked(app, NotificationChannels.UPDATES))
    }
}

private object AndroidNotifierHolder { fun create(app: Application) = AndroidAlertNotifier(app) }
