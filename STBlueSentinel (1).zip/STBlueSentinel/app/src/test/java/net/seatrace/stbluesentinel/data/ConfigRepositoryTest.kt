package net.seatrace.stbluesentinel.data

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import net.seatrace.stbluesentinel.core.security.SaveResult
import net.seatrace.stbluesentinel.receiver.UrlError
import net.seatrace.stbluesentinel.receiver.UrlValidation
import net.seatrace.stbluesentinel.testutil.FakeSecretStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class ConfigRepositoryTest {
    private val ctx: Context = ApplicationProvider.getApplicationContext()
    private lateinit var secrets: FakeSecretStore
    private lateinit var repo: ConfigRepository

    @Before fun setUp() {
        ctx.getSharedPreferences("stb_config", Context.MODE_PRIVATE).edit().clear().commit()
        secrets = FakeSecretStore(); repo = ConfigRepository(ctx, secrets)
    }

    @Test fun startsNotConfigured() = with(repo.state.value) { assertNull(receiverUrl); assertFalse(receiverUrlValid); assertFalse(hasSecret) }

    @Test fun validUrl_isPersisted_andSurvivesANewRepository() {
        assertTrue(repo.saveReceiverUrl("wss://alerts.example.com/bs") is UrlValidation.Valid)
        assertTrue(repo.state.value.receiverUrlValid)
        assertEquals("wss://alerts.example.com/bs", ConfigRepository(ctx, secrets).state.value.receiverUrl)
    }

    @Test fun invalidUrl_isRefused_andNothingIsPersisted() {
        val r = repo.saveReceiverUrl("ws://alerts.example.com/bs")
        assertEquals(UrlError.NOT_WSS, (r as UrlValidation.Invalid).error)
        assertNull(repo.state.value.receiverUrl); assertNull(ConfigRepository(ctx, secrets).state.value.receiverUrl)
        assertTrue(repo.saveReceiverUrl("wss://user:pw@alerts.example.com/bs") is UrlValidation.Invalid)
        assertTrue(repo.saveReceiverUrl("wss://alerts.example.com/bs?token=abc") is UrlValidation.Invalid)
    }

    @Test fun aFailedSaveDoesNotEraseAPreviouslyValidUrl() {
        repo.saveReceiverUrl("wss://alerts.example.com/bs"); repo.saveReceiverUrl("http://nope")
        assertEquals("wss://alerts.example.com/bs", repo.state.value.receiverUrl)
    }

    @Test fun secretLifecycle_savedClearedAndValidated() {
        assertEquals(SaveResult.Invalid, repo.saveSecret("short")); assertFalse(repo.state.value.hasSecret)
        assertEquals(SaveResult.Saved, repo.saveSecret("x".repeat(32))); assertTrue(repo.state.value.hasSecret)
        repo.clearSecret(); assertFalse(repo.state.value.hasSecret)
    }

    @Test fun uiStateNeverCarriesTheSecret() {
        repo.saveSecret("topsecretvalue-0123456789")
        assertFalse(repo.state.value.toString().contains("topsecret"))
        val names = ConfigSnapshot::class.java.declaredFields.map { it.name.lowercase() }
        assertEquals(listOf("receiverurl", "receiverurlvalid", "hassecret"), names)
    }

    @Test fun resetClearsEverything() {
        repo.saveReceiverUrl("wss://alerts.example.com/bs"); repo.saveSecret("x".repeat(32)); repo.resetAll()
        with(repo.state.value) { assertNull(receiverUrl); assertFalse(hasSecret) }
    }
}
