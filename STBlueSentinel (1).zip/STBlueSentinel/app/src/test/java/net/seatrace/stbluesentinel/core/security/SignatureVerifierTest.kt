package net.seatrace.stbluesentinel.core.security

import net.seatrace.stbluesentinel.core.security.TestVectors.FRAME
import net.seatrace.stbluesentinel.core.security.TestVectors.FRAME_BYTES
import net.seatrace.stbluesentinel.core.security.TestVectors.SECRET_BYTES
import net.seatrace.stbluesentinel.core.security.TestVectors.SIGNATURE_HEADER
import net.seatrace.stbluesentinel.core.security.TestVectors.TIMESTAMP
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SignatureVerifierTest {
    private fun verify(
        secret: ByteArray = SECRET_BYTES,
        ts: String = TIMESTAMP,
        frame: ByteArray = FRAME_BYTES,
        sig: String? = SIGNATURE_HEADER,
    ) = SignatureVerifier.verify(secret, ts, frame, sig)

    @Test fun knownSecretTimestampAndExactFrame_producesExpectedSignature() {
        assertEquals(TestVectors.EXPECTED_HEX, SignatureVerifier.computeHex(SECRET_BYTES, TIMESTAMP, FRAME_BYTES))
    }

    @Test fun validSignature_isAccepted() = assertEquals(SignatureResult.VALID, verify())

    @Test fun uppercaseHex_isAcceptedAsTheSameMac() =
        assertEquals(SignatureResult.VALID, verify(sig = "sha256=" + TestVectors.EXPECTED_HEX.uppercase()))

    @Test fun modifiedFrame_isRejected() =
        assertEquals(SignatureResult.MISMATCH, verify(frame = FRAME.replace("high", "low").toByteArray()))

    @Test fun singleChangedByteInFrame_isRejected() {
        val tampered = FRAME_BYTES.copyOf().also { it[it.size / 2] = (it[it.size / 2] + 1).toByte() }
        assertEquals(SignatureResult.MISMATCH, verify(frame = tampered))
    }

    @Test fun reserialisedOrReformattedJson_isRejected_becauseVerificationUsesExactFrameText() {
        // Semantically identical JSON with different whitespace must NOT verify.
        val pretty = FRAME.replace(",\"source\"", ", \"source\"")
        assertEquals(SignatureResult.MISMATCH, verify(frame = pretty.toByteArray()))
    }

    @Test fun modifiedTimestamp_isRejected() = assertEquals(SignatureResult.MISMATCH, verify(ts = "1790000001"))

    @Test fun wrongSecret_isRejected() =
        assertEquals(SignatureResult.MISMATCH, verify(secret = "another-secret-value-0123456789".toByteArray()))

    @Test fun missingSignature_isRejected() {
        assertEquals(SignatureResult.MISSING, verify(sig = null))
        assertEquals(SignatureResult.MISSING, verify(sig = ""))
        assertEquals(SignatureResult.MISSING, verify(sig = "   "))
    }

    @Test fun missingPrefixSeparator_isMalformed() =
        assertEquals(SignatureResult.MALFORMED, verify(sig = TestVectors.EXPECTED_HEX))

    @Test fun wrongAlgorithmPrefix_isRejected() {
        assertEquals(SignatureResult.WRONG_ALGORITHM, verify(sig = "sha1=" + TestVectors.EXPECTED_HEX))
        assertEquals(SignatureResult.WRONG_ALGORITHM, verify(sig = "SHA256=" + TestVectors.EXPECTED_HEX))
        assertEquals(SignatureResult.WRONG_ALGORITHM, verify(sig = "md5=" + TestVectors.EXPECTED_HEX))
    }

    @Test fun malformedHex_isRejected() {
        assertEquals(SignatureResult.MALFORMED, verify(sig = "sha256="))
        assertEquals(SignatureResult.MALFORMED, verify(sig = "sha256=abc123"))
        assertEquals(SignatureResult.MALFORMED, verify(sig = "sha256=" + "z".repeat(64)))
        assertEquals(SignatureResult.MALFORMED, verify(sig = SIGNATURE_HEADER + "00"))
    }

    @Test fun headerWithStrayWhitespace_isNeverAccepted() {
        assertTrue(verify(sig = " $SIGNATURE_HEADER") != SignatureResult.VALID)
        assertTrue(verify(sig = "$SIGNATURE_HEADER ") != SignatureResult.VALID)
    }

    @Test(expected = IllegalArgumentException::class)
    fun emptySecret_isRefused() {
        verify(secret = ByteArray(0))
    }
}
