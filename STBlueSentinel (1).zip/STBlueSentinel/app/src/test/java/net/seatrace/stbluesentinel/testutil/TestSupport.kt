package net.seatrace.stbluesentinel.testutil

import android.content.Context
import net.seatrace.stbluesentinel.AppContainer
import net.seatrace.stbluesentinel.StbApplication
import net.seatrace.stbluesentinel.core.pipeline.AlertEnvelope
import net.seatrace.stbluesentinel.core.security.SaveResult
import net.seatrace.stbluesentinel.core.security.SecretPolicy
import net.seatrace.stbluesentinel.core.security.SecretStore
import net.seatrace.stbluesentinel.core.security.SignatureVerifier
import net.seatrace.stbluesentinel.core.security.TestVectors
import net.seatrace.stbluesentinel.data.db.AlertEntity
import net.seatrace.stbluesentinel.fcm.FcmContract
import java.util.Base64

/** In-memory secret store (the Android Keystore is not available under Robolectric; it is covered by the instrumented tests). */
class FakeSecretStore : SecretStore {
    private var value: ByteArray? = null
    override fun hasSecret() = value != null
    override fun save(secret: String): SaveResult {
        val n = SecretPolicy.normalize(secret) ?: return SaveResult.Invalid
        value = n.toByteArray(Charsets.UTF_8); return SaveResult.Saved
    }
    override fun load(): ByteArray? = value?.copyOf()
    override fun clear() { value = null }
}

/** Application used by Robolectric tests: identical wiring, but a fake secret store. */
class TestStbApplication : StbApplication() {
    override fun createContainer() = AppContainer(this) { _: Context -> secrets }
    companion object { val secrets = FakeSecretStore() }
}

object Signed {
    fun frame(id: String, severity: String = "high", type: String = "danger_zone_entry", extra: String = "") =
        """{"schema_version":"1.0","source":"seatracepro","product":"bluesentinel","event":"vessel_alert","alert_id":"$id","alert_type":"$type","severity":"$severity","title":"Entered high-incident area","message":"MV EXAMPLE entered an area.","vessel":{"mmsi":123456789,"ship_name":"MV EXAMPLE"},"threat":{"state":"INSIDE","area_label":"Near Lagos (NGA)"}$extra}"""

    fun envelope(frame: String, ts: String, secret: ByteArray = TestVectors.SECRET_BYTES): AlertEnvelope {
        val bytes = frame.toByteArray(Charsets.UTF_8)
        val id = Regex("\"alert_id\":\"([^\"]+)\"").find(frame)!!.groupValues[1]
        return AlertEnvelope("vessel_alert", id, ts, "sha256=" + SignatureVerifier.computeHex(secret, ts, bytes), bytes)
    }

    /** The data map exactly as the gateway contract (docs/FCM_CONTRACT.md) defines it. */
    fun fcmData(e: AlertEnvelope): Map<String, String> = mapOf(
        FcmContract.KEY_VERSION to FcmContract.VERSION, FcmContract.KEY_EVENT to e.event!!, FcmContract.KEY_ALERT_ID to e.alertId!!,
        FcmContract.KEY_TIMESTAMP to e.timestamp!!, FcmContract.KEY_SIGNATURE to e.signature!!,
        FcmContract.KEY_FRAME to Base64.getEncoder().encodeToString(e.frame),
    )
}

fun alertEntity(
    alertId: String, severity: String = "high", test: Boolean = false, receivedAt: Long = 1_000L, read: Boolean = false,
    delivery: String = "VERIFIED", title: String = "Title",
) = AlertEntity(
    alertId = alertId, alertType = "danger_zone_entry", severity = severity, title = title, message = null, schemaVersion = "1.0",
    source = "seatracepro", product = "bluesentinel", timestampUtc = null, createdUtc = null, receivedAt = receivedAt, verified = true,
    deliveryStatus = delivery, signedAt = 1_790_000_000L, deliveryAgeSeconds = 5, testAlert = test, testNotice = null,
    shipId = null, mmsi = null, shipName = null, imo = null, latitude = null, longitude = null, speedKnots = null, courseDeg = null,
    lastSeenUtc = null, threatState = null, areaLabel = null, nearestIncidentKm = null, incidentsWithinRadius = null, radiusKm = null,
    datasetLatestIncidentDate = null, nearestIncidentDate = null, nearestIncidentAttackType = null, nearestIncidentCountry = null,
    nearestIncidentLocation = null, nearestIncidentDistanceKm = null, rawPayload = "{}", read = read,
)
