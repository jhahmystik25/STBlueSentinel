package net.seatrace.stbluesentinel.notifications

import net.seatrace.stbluesentinel.core.model.DeliveryStatus
import net.seatrace.stbluesentinel.core.model.Severity
import org.junit.Assert.assertEquals
import org.junit.Test

class NotificationPolicyTest {
    private class Prefs(
        override val masterEnabled: Boolean = true,
        override val testAlertsEnabled: Boolean = true,
        val enabled: Set<Severity> = Severity.entries.toSet(),
    ) : NotificationPreferences {
        override fun isSeverityEnabled(severity: Severity) = severity in enabled
    }

    private fun decide(status: DeliveryStatus = DeliveryStatus.VERIFIED, sev: Severity = Severity.HIGH, test: Boolean = false, p: Prefs = Prefs()) =
        NotificationPolicy.decide(status, sev, test, p)

    @Test fun verifiedLiveAlert_notifies() = assertEquals(NotifyDecision.NOTIFY, decide())

    @Test fun staleAlert_neverNotifies_evenCriticalWithEverythingEnabled() {
        Severity.entries.forEach { assertEquals(NotifyDecision.SKIP_STALE, decide(DeliveryStatus.STALE, it)) }
        assertEquals(NotifyDecision.SKIP_STALE, decide(DeliveryStatus.STALE, Severity.CRITICAL, test = true))
    }

    @Test fun rejectedStatus_neverNotifies() = assertEquals(NotifyDecision.SKIP_STALE, decide(DeliveryStatus.REJECTED))

    @Test fun masterSwitchOff_suppressesEverything() {
        val p = Prefs(masterEnabled = false)
        assertEquals(NotifyDecision.SKIP_MASTER_DISABLED, decide(p = p))
        assertEquals(NotifyDecision.SKIP_MASTER_DISABLED, decide(test = true, p = p))
    }

    @Test fun perSeverityPreference_isHonoured() {
        val p = Prefs(enabled = setOf(Severity.CRITICAL, Severity.HIGH))
        assertEquals(NotifyDecision.NOTIFY, decide(sev = Severity.CRITICAL, p = p))
        assertEquals(NotifyDecision.SKIP_SEVERITY_DISABLED, decide(sev = Severity.MEDIUM, p = p))
        assertEquals(NotifyDecision.SKIP_SEVERITY_DISABLED, decide(sev = Severity.LOW, p = p))
    }

    @Test fun infoFollowsTheLowSwitch() {
        assertEquals(NotifyDecision.NOTIFY, decide(sev = Severity.INFO, p = Prefs(enabled = setOf(Severity.LOW))))
        assertEquals(NotifyDecision.SKIP_SEVERITY_DISABLED, decide(sev = Severity.INFO, p = Prefs(enabled = setOf(Severity.HIGH))))
    }

    @Test fun testAlerts_followOnlyTheTestSwitch() {
        assertEquals(NotifyDecision.NOTIFY, decide(sev = Severity.INFO, test = true, p = Prefs(enabled = emptySet())))
        assertEquals(NotifyDecision.SKIP_TEST_DISABLED, decide(sev = Severity.INFO, test = true, p = Prefs(testAlertsEnabled = false)))
    }
}
