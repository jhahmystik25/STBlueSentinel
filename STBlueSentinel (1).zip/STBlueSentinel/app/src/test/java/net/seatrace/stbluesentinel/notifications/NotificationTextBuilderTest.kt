package net.seatrace.stbluesentinel.notifications

import net.seatrace.stbluesentinel.core.model.Severity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NotificationTextBuilderTest {
    @Test fun realAlert_matchesTheSpecifiedLayout() {
        val t = NotificationTextBuilder.build(Severity.HIGH, false, "Entered high-incident area", "MV EXAMPLE", "Near Lagos (NGA)", null)
        assertEquals("BlueSentinel — HIGH", t.title)
        assertEquals("Entered high-incident area", t.body)
        assertEquals("Entered high-incident area\nMV EXAMPLE\nNear Lagos (NGA)\nTap for details.", t.bigText)
    }

    @Test fun severityIsAlwaysSpelledOut_neverColourOnly() =
        Severity.entries.forEach { assertTrue(NotificationTextBuilder.build(it, false, "x", null, null, null).title.contains(it.label)) }

    @Test fun missingVesselAndArea_areOmitted_notFaked() {
        val t = NotificationTextBuilder.build(Severity.LOW, false, "Speed change", null, "  ", null)
        assertEquals("Speed change\nTap for details.", t.bigText)
    }

    @Test fun testAlert_isClearlyDistinguishedFromARealIncident() {
        val t = NotificationTextBuilder.build(Severity.INFO, true, "BlueSentinel test", "TEST VESSEL", null, "Dummy data")
        assertEquals("TEST ALERT — NOT A REAL INCIDENT", t.title)
        assertFalse(t.title.contains("INFO")); assertFalse(t.title.contains("BlueSentinel —"))
        assertTrue(t.bigText.contains("Test notification only"))
        assertEquals("Not a real incident.", t.publicBody)
    }

    @Test fun lockScreenPublicVersion_leaksNoVesselOrPosition() {
        val t = NotificationTextBuilder.build(Severity.CRITICAL, false, "Distress", "MV SECRET", "Gulf of Guinea", null)
        assertFalse(t.publicBody.contains("SECRET")); assertFalse(t.publicBody.contains("Gulf")); assertFalse(t.publicTitle.contains("SECRET"))
        assertEquals("BlueSentinel — CRITICAL", t.publicTitle)
    }
}
