package net.seatrace.stbluesentinel.fcm

import android.Manifest
import android.app.NotificationManager
import androidx.test.core.app.ApplicationProvider
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import net.seatrace.stbluesentinel.core.security.TestVectors
import net.seatrace.stbluesentinel.data.db.StbDatabase
import net.seatrace.stbluesentinel.testutil.Signed
import net.seatrace.stbluesentinel.testutil.TestStbApplication
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

/**
 * "UI closed" tests. The real FirebaseMessagingService is driven with a real RemoteMessage; no Activity is ever created.
 * Everything downstream is production code (parser, verifier, Room, notifier) except the secret store, which is an in-memory fake.
 */
@RunWith(RobolectricTestRunner::class)
@Config(application = TestStbApplication::class)
class BackgroundDeliveryTest {
    private val app get() = ApplicationProvider.getApplicationContext<TestStbApplication>()
    private val nm get() = shadowOf(app.getSystemService(NotificationManager::class.java))
    private val now get() = System.currentTimeMillis() / 1000

    @Before fun setUp() {
        shadowOf(app).grantPermissions(Manifest.permission.POST_NOTIFICATIONS)
        TestStbApplication.secrets.clear(); TestStbApplication.secrets.save(TestVectors.SECRET)
    }
    @After fun tearDown() = StbDatabase.resetForTesting()

    private fun push(data: Map<String, String>) =
        Robolectric.setupService(StbMessagingService::class.java).onMessageReceived(RemoteMessage.Builder("test@fcm").setData(data).build())
    private fun pushAlert(id: String, ageSeconds: Long = 0, severity: String = "high", type: String = "danger_zone_entry", secret: ByteArray = TestVectors.SECRET_BYTES, extra: String = "") =
        push(Signed.fcmData(Signed.envelope(Signed.frame(id, severity, type, extra), (now - ageSeconds).toString(), secret)))
    private fun rows() = runBlocking(Dispatchers.IO) { app.container.database.alertDao().observeAll().first() }
    private fun rejections() = runBlocking(Dispatchers.IO) { app.container.database.rejectionDao().observeRecent(20).first() }

    @Test fun testB_E_verifiedPushWithNoUi_isStoredAndNotified() {
        pushAlert("E1")
        assertEquals(1, nm.allNotifications.size)
        val a = rows().single()
        assertEquals("E1", a.alertId); assertEquals("VERIFIED", a.deliveryStatus); assertTrue(a.verified)
        assertTrue(nm.getNotification(a.id.toInt()) != null)   // notification id == Room row id
    }

    @Test fun databaseTest_theAlertIsAlreadyInHistoryWhenTheUiOpensLater() {
        pushAlert("H1"); pushAlert("H2", severity = "critical")
        assertEquals(listOf("H2", "H1"), rows().map { it.alertId })   // what the History screen will read, with no Activity ever created
    }

    @Test fun duplicateDelivery_oneRow_oneNotification() {
        repeat(3) { pushAlert("D1") }
        assertEquals(1, rows().size); assertEquals(1, nm.allNotifications.size)
    }

    @Test fun staleAlert_isKeptForHistory_butNeverNotified() {
        pushAlert("S1", ageSeconds = 3_600)
        assertEquals("STALE", rows().single().deliveryStatus); assertEquals(0, nm.allNotifications.size)
    }

    @Test fun forgedSignature_isRejected_notStored_notNotified_andAudited() {
        pushAlert("F1", secret = "a-completely-different-secret-value".toByteArray())
        assertEquals(0, rows().size); assertEquals(0, nm.allNotifications.size)
        assertEquals("SIGNATURE_MISMATCH", rejections().single().reason)
    }

    @Test fun futureDatedAlert_isRejected() {
        pushAlert("T1", ageSeconds = -600)
        assertEquals(0, rows().size); assertEquals("FUTURE_TIMESTAMP", rejections().single().reason)
    }

    @Test fun noSecretConfigured_nothingIsEverMarkedVerified() {
        TestStbApplication.secrets.clear()
        pushAlert("N1")
        assertEquals(0, rows().size); assertEquals(0, nm.allNotifications.size); assertEquals("SECRET_NOT_CONFIGURED", rejections().single().reason)
    }

    @Test fun notificationTestAlert_isStoredAsTest_andPostedOnTheTestChannel() {
        pushAlert("TST", severity = "info", type = "notification_test", extra = ""","test":true,"test_notice":"Dummy" """.trim())
        assertTrue(rows().single().testAlert)
        assertEquals(net.seatrace.stbluesentinel.notifications.NotificationChannels.TESTS, nm.allNotifications.single().channelId)
    }

    @Test fun androidNotificationsOff_alertStillStoredInHistory() {
        nm.setNotificationsEnabled(false)
        pushAlert("O1")
        assertEquals(1, rows().size); assertEquals(0, nm.allNotifications.size)
    }

    @Test fun unrelatedPush_isIgnoredEntirely() {
        push(mapOf("promo" to "hello"))
        assertEquals(0, rows().size); assertEquals(0, rejections().size); assertEquals(0, nm.allNotifications.size)
    }

    @Test fun malformedBase64Push_isRejectedAndAudited() {
        push(Signed.fcmData(Signed.envelope(Signed.frame("B1"), now.toString())) + mapOf(FcmContract.KEY_FRAME to "not base64!!"))
        assertEquals(0, rows().size); assertEquals("INVALID_PUSH_PAYLOAD", rejections().single().reason)
    }

    @Test fun userPreferenceOff_suppressesTheNotificationOnly_notTheHistory() {
        app.container.notificationPrefs.setSeverityEnabled(net.seatrace.stbluesentinel.core.model.Severity.MEDIUM, false)
        pushAlert("P1", severity = "medium")
        assertEquals(1, rows().size); assertEquals(0, nm.allNotifications.size)
    }
}
