package net.seatrace.stbluesentinel.core.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SecretPolicyTest {
    private val sixtyFourHex = "ab".repeat(32) // same shape as a real BlueSentinel secret, but obviously not one

    @Test fun typicalHexSecret_isAccepted() = assertEquals(sixtyFourHex, SecretPolicy.normalize(sixtyFourHex))

    @Test fun pastedWhitespaceAndNewlines_areTrimmed() {
        assertEquals(sixtyFourHex, SecretPolicy.normalize("  $sixtyFourHex\n"))
        assertEquals(sixtyFourHex, SecretPolicy.normalize("\t$sixtyFourHex \r\n"))
    }

    @Test fun lengthBounds() {
        assertNull(SecretPolicy.normalize("a".repeat(15)))
        assertEquals("a".repeat(16), SecretPolicy.normalize("a".repeat(16)))
        assertEquals("a".repeat(256), SecretPolicy.normalize("a".repeat(256)))
        assertNull(SecretPolicy.normalize("a".repeat(257)))
        assertNull(SecretPolicy.normalize(""))
        assertNull(SecretPolicy.normalize("                "))
    }

    @Test fun innerWhitespaceControlOrNonAscii_isRejected() {
        assertNull(SecretPolicy.normalize("abcdefgh ijklmnopqrst"))
        assertNull(SecretPolicy.normalize("abcdefgh\nijklmnopqrst"))
        assertNull(SecretPolicy.normalize("abcdefghijklmnop\u0000"))
        assertNull(SecretPolicy.normalize("abcdefghijklmn\u00E9\u00E9"))
    }
}
