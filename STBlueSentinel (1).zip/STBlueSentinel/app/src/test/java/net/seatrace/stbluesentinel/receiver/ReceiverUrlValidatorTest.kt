package net.seatrace.stbluesentinel.receiver

import org.junit.Assert.assertEquals
import org.junit.Test

class ReceiverUrlValidatorTest {
    private fun err(s: String) = (ReceiverUrlValidator.validate(s) as UrlValidation.Invalid).error
    private fun ok(s: String) = (ReceiverUrlValidator.validate(s) as UrlValidation.Valid).normalized

    @Test fun validPublicWssAddresses_areAccepted() {
        assertEquals("wss://alerts.example.com/bluesentinel", ok("wss://alerts.example.com/bluesentinel"))
        assertEquals("wss://alerts.example.com:8443/ws", ok("  wss://alerts.example.com:8443/ws  "))
        assertEquals("wss://alerts.example.com/", ok("WSS://alerts.example.com/"))        // scheme normalised
        assertEquals("wss://8.8.8.8/x", ok("wss://8.8.8.8/x"))
    }

    @Test fun emptyOrPlaceholder_isRejected() {
        assertEquals(UrlError.EMPTY, err("")); assertEquals(UrlError.EMPTY, err("   ")); assertEquals(UrlError.EMPTY, err("wss://"))
    }

    @Test fun nonWssSchemes_areRejected() {
        listOf("ws://alerts.example.com", "http://alerts.example.com", "https://alerts.example.com", "alerts.example.com", "ftp://x.example.com")
            .forEach { assertEquals(it, UrlError.NOT_WSS, err(it)) }
    }

    @Test fun credentialsInUrl_areRejected() {
        assertEquals(UrlError.CREDENTIALS_IN_URL, err("wss://user:pass@alerts.example.com/ws"))
        assertEquals(UrlError.CREDENTIALS_IN_URL, err("wss://token@alerts.example.com/ws"))
    }

    @Test fun anyQueryOrFragment_isRejected() {
        assertEquals(UrlError.QUERY_NOT_ALLOWED, err("wss://alerts.example.com/ws?secret=abc"))
        assertEquals(UrlError.QUERY_NOT_ALLOWED, err("wss://alerts.example.com/ws?"))
        assertEquals(UrlError.FRAGMENT_NOT_ALLOWED, err("wss://alerts.example.com/ws#frag"))
    }

    @Test fun nonPublicHosts_areRejected() {
        listOf("wss://localhost/ws", "wss://myserver/ws", "wss://nas.local/ws", "wss://box.internal/ws", "wss://127.0.0.1/ws",
            "wss://10.0.0.5/ws", "wss://192.168.1.10/ws", "wss://172.16.0.1/ws", "wss://169.254.1.1/ws", "wss://100.64.0.1/ws",
            "wss://0.0.0.0/ws", "wss://[::1]/ws")
            .forEach { assertEquals(it, UrlError.NOT_PUBLIC_HOST, err(it)) }
    }

    @Test fun publicEdgeOfPrivateRanges_isAccepted() {
        ok("wss://172.32.0.1/ws"); ok("wss://172.15.0.1/ws"); ok("wss://100.63.0.1/ws")
    }

    @Test fun whitespaceInside_orGarbage_isMalformed() {
        assertEquals(UrlError.MALFORMED, err("wss://alerts .example.com"))
        assertEquals(UrlError.MALFORMED, err("wss://"+"%zz"))
    }

    @Test fun overlongAddress_isRejected() = assertEquals(UrlError.TOO_LONG, err("wss://a.example.com/" + "x".repeat(2100)))
}
