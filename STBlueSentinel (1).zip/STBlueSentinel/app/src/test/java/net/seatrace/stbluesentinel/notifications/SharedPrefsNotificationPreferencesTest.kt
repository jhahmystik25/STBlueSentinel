package net.seatrace.stbluesentinel.notifications

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import net.seatrace.stbluesentinel.core.model.Severity
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class SharedPrefsNotificationPreferencesTest {
    private val ctx: Context = ApplicationProvider.getApplicationContext()
    @Before fun setUp() { SharedPrefsNotificationPreferences(ctx).clear() }

    @Test fun everythingIsOnByDefault_soAFreshInstallNeverSilentlyDropsAlerts() {
        val p = SharedPrefsNotificationPreferences(ctx)
        assertTrue(p.masterEnabled); assertTrue(p.testAlertsEnabled); Severity.entries.forEach { assertTrue(p.isSeverityEnabled(it)) }
        assertFalse(p.permissionRequested)
    }

    @Test fun changesPersistAcrossInstances_asTheBackgroundServiceSeesThem() {
        SharedPrefsNotificationPreferences(ctx).apply { masterEnabled = false; testAlertsEnabled = false; setSeverityEnabled(Severity.MEDIUM, false); permissionRequested = true }
        val p = SharedPrefsNotificationPreferences(ctx)
        assertFalse(p.masterEnabled); assertFalse(p.testAlertsEnabled); assertFalse(p.isSeverityEnabled(Severity.MEDIUM)); assertTrue(p.isSeverityEnabled(Severity.HIGH)); assertTrue(p.permissionRequested)
    }

    @Test fun clearRestoresDefaults() {
        val p = SharedPrefsNotificationPreferences(ctx); p.masterEnabled = false; p.clear()
        assertTrue(SharedPrefsNotificationPreferences(ctx).masterEnabled)
    }
}
