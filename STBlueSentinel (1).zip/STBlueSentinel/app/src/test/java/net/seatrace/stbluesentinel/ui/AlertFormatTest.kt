package net.seatrace.stbluesentinel.ui

import net.seatrace.stbluesentinel.ui.state.AlertFormat
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.Instant

class AlertFormatTest {
    private val t = Instant.parse("2026-10-04T10:42:07Z").toEpochMilli()

    @Test fun utcFormats() {
        assertEquals("10:42 UTC", AlertFormat.utcShort(t))
        assertEquals("04 Oct 10:42 UTC", AlertFormat.utcCompact(t))
        assertEquals("2026-10-04 10:42:07 UTC", AlertFormat.utcFull(t))
    }

    @Test fun coordinatesUseHemisphereLetters_notSignedNumbers() {
        assertEquals("5.123456° N", AlertFormat.latitude(5.123456)); assertEquals("33.500000° S", AlertFormat.latitude(-33.5))
        assertEquals("0.123456° W", AlertFormat.longitude(-0.123456)); assertEquals("151.200000° E", AlertFormat.longitude(151.2))
    }

    @Test fun measurements() {
        assertEquals("14.7 kn", AlertFormat.speedKnots(14.7)); assertEquals("182.4°", AlertFormat.courseDegrees(182.4)); assertEquals("3.4 km", AlertFormat.kilometres(3.4))
    }

    @Test fun durations() {
        assertEquals("45 s", AlertFormat.duration(45)); assertEquals("16 min", AlertFormat.duration(16 * 60 + 5)); assertEquals("1 h 05 min", AlertFormat.duration(3900))
    }

    @Test fun alertTypeLabels_coverDocumentedTypes_andShowUnknownHonestly() {
        assertEquals("Danger zone entry", AlertFormat.alertTypeLabel("danger_zone_entry"))
        assertEquals("Notification test", AlertFormat.alertTypeLabel("notification_test"))
        assertEquals("Brand new type", AlertFormat.alertTypeLabel("brand_new_type"))   // raw type shown, never relabelled
    }
}
