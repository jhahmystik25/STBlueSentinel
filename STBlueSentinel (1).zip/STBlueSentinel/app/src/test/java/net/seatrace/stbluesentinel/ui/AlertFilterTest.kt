package net.seatrace.stbluesentinel.ui

import net.seatrace.stbluesentinel.core.model.Severity
import net.seatrace.stbluesentinel.ui.state.AlertFilter
import net.seatrace.stbluesentinel.ui.state.ViewFilter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AlertFilterTest {
    @Test fun defaultFilter_matchesEverything() {
        assertTrue(AlertFilter().matches("critical", false, "VERIFIED")); assertTrue(AlertFilter().matches("info", true, "STALE"))
    }

    @Test fun severitySelection_isMultiSelect_andInfoGroupsWithLow() {
        val f = AlertFilter().toggle(Severity.HIGH).toggle(Severity.LOW)
        assertTrue(f.matches("high", false, "VERIFIED")); assertTrue(f.matches("low", false, "VERIFIED")); assertTrue(f.matches("info", false, "VERIFIED"))
        assertFalse(f.matches("critical", false, "VERIFIED")); assertFalse(f.matches("medium", false, "VERIFIED"))
        assertEquals(setOf(Severity.HIGH), f.toggle(Severity.LOW).severities)
    }

    @Test fun viewFilters() {
        assertTrue(AlertFilter(view = ViewFilter.REAL).matches("high", false, "STALE"))      // delayed real alerts are still real
        assertFalse(AlertFilter(view = ViewFilter.REAL).matches("info", true, "VERIFIED"))
        assertTrue(AlertFilter(view = ViewFilter.TEST).matches("info", true, "VERIFIED"))
        assertFalse(AlertFilter(view = ViewFilter.TEST).matches("high", false, "VERIFIED"))
        assertTrue(AlertFilter(view = ViewFilter.DELAYED).matches("high", false, "STALE"))
        assertFalse(AlertFilter(view = ViewFilter.DELAYED).matches("high", false, "VERIFIED"))
    }

    @Test fun combinedFilters_mustAllHold() {
        val f = AlertFilter(setOf(Severity.CRITICAL), ViewFilter.REAL)
        assertTrue(f.matches("critical", false, "VERIFIED")); assertFalse(f.matches("critical", true, "VERIFIED")); assertFalse(f.matches("high", false, "VERIFIED"))
    }
}
