package net.seatrace.stbluesentinel.ui

import net.seatrace.stbluesentinel.core.model.Severity
import net.seatrace.stbluesentinel.ui.state.AlertCounts
import org.junit.Assert.assertEquals
import org.junit.Test

class AlertCountsTest {
    @Test fun emptyInput_givesZeroForAllFourClasses() =
        assertEquals(mapOf(Severity.CRITICAL to 0, Severity.HIGH to 0, Severity.MEDIUM to 0, Severity.LOW to 0), AlertCounts.fold(emptyList()))

    @Test fun matchesTheBriefsExample() {
        val m = AlertCounts.fold(listOf("critical" to 3, "high" to 8, "medium" to 14, "low" to 7))
        assertEquals(3, m[Severity.CRITICAL]); assertEquals(8, m[Severity.HIGH]); assertEquals(14, m[Severity.MEDIUM]); assertEquals(7, m[Severity.LOW])
    }

    @Test fun infoIsFoldedIntoLow() = assertEquals(9, AlertCounts.fold(listOf("low" to 7, "info" to 2))[Severity.LOW])

    @Test fun unknownSeverityStrings_areIgnored_notMiscounted() {
        val m = AlertCounts.fold(listOf("apocalyptic" to 5, "high" to 1))
        assertEquals(1, m.values.sum()); assertEquals(1, m[Severity.HIGH])
    }

    @Test fun displayOrderIsCriticalFirst() =
        assertEquals(listOf(Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW), AlertCounts.fold(emptyList()).keys.toList())
}
