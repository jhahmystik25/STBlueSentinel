package net.seatrace.stbluesentinel.data.db

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import net.seatrace.stbluesentinel.testutil.alertEntity
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class AlertDaoTest {
    private lateinit var db: StbDatabase
    private val dao get() = db.alertDao()

    @Before fun setUp() {
        db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext<Context>(), StbDatabase::class.java).allowMainThreadQueries().build()
    }
    @After fun tearDown() = db.close()

    @Test fun firstInsertReturnsRowId_duplicateAlertIdReturnsMinusOne_andStoresNoSecondRow() = runBlocking {
        val first = dao.insertIgnore(alertEntity("A1"))
        val second = dao.insertIgnore(alertEntity("A1", title = "retry delivery"))
        assertTrue(first > 0); assertEquals(-1L, second)
        val all = dao.observeAll().first()
        assertEquals(1, all.size); assertEquals("Title", all.single().title)   // the original row is untouched
    }

    @Test fun alertIdColumnHasAUniqueIndex() {
        val c = db.openHelper.readableDatabase.query("PRAGMA index_list(alerts)")
        var unique = false
        while (c.moveToNext()) if (c.getString(c.getColumnIndexOrThrow("name")) == "index_alerts_alert_id") unique = c.getInt(c.getColumnIndexOrThrow("unique")) == 1
        c.close(); assertTrue(unique)
    }

    @Test fun existsReflectsStoredAlerts() = runBlocking {
        assertFalse(dao.exists("X")); dao.insertIgnore(alertEntity("X")); assertTrue(dao.exists("X"))
    }

    @Test fun historyIsNewestFirst() = runBlocking {
        dao.insertIgnore(alertEntity("old", receivedAt = 1_000)); dao.insertIgnore(alertEntity("new", receivedAt = 3_000)); dao.insertIgnore(alertEntity("mid", receivedAt = 2_000))
        assertEquals(listOf("new", "mid", "old"), dao.observeAll().first().map { it.alertId })
    }

    @Test fun severityCountsExcludeTestAlerts() = runBlocking {
        dao.insertIgnore(alertEntity("1", "critical")); dao.insertIgnore(alertEntity("2", "high")); dao.insertIgnore(alertEntity("3", "high"))
        dao.insertIgnore(alertEntity("4", "info", test = true)); dao.insertIgnore(alertEntity("5", "high", test = true))
        val counts = dao.observeSeverityCounts().first().associate { it.severity to it.count }
        assertEquals(mapOf("critical" to 1, "high" to 2), counts)
    }

    @Test fun latestRealAlertIgnoresTests() = runBlocking {
        dao.insertIgnore(alertEntity("real", receivedAt = 1_000)); dao.insertIgnore(alertEntity("test", test = true, receivedAt = 9_000))
        assertEquals("real", dao.observeLatestReal().first()!!.alertId)
    }

    @Test fun latestRealIsNullWhenOnlyTestsExist() = runBlocking {
        dao.insertIgnore(alertEntity("t", test = true)); assertNull(dao.observeLatestReal().first())
    }

    @Test fun readTracking() = runBlocking {
        val id1 = dao.insertIgnore(alertEntity("1")); dao.insertIgnore(alertEntity("2"))
        assertEquals(2, dao.observeUnreadCount().first())
        dao.markRead(id1); assertEquals(1, dao.observeUnreadCount().first())
        dao.markAllRead(); assertEquals(0, dao.observeUnreadCount().first())
    }

    @Test fun clearAllEmptiesHistory() = runBlocking {
        dao.insertIgnore(alertEntity("1")); dao.clearAll(); assertTrue(dao.observeAll().first().isEmpty())
    }

    @Test fun absentOptionalValuesStayNull_notZeroOrEmpty() = runBlocking {
        val id = dao.insertIgnore(alertEntity("N"))
        val a = dao.getById(id)!!
        assertNull(a.latitude); assertNull(a.mmsi); assertNull(a.speedKnots); assertNull(a.nearestIncidentKm); assertNull(a.areaLabel); assertNull(a.message)
    }

    @Test fun rejectionLogIsBounded_keepingTheNewest() = runBlocking {
        val r = db.rejectionDao()
        (1..5).forEach { r.insert(RejectionEntity(alertId = "a$it", reason = "SIGNATURE_MISMATCH", receivedAt = it.toLong())) }
        r.prune(3)
        assertEquals(listOf("a5", "a4", "a3"), r.observeRecent(10).first().map { it.alertId })
    }
}
