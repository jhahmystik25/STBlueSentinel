package net.seatrace.stbluesentinel.core.pipeline

import kotlinx.coroutines.test.runTest
import net.seatrace.stbluesentinel.core.model.Severity
import net.seatrace.stbluesentinel.core.security.RejectReason
import net.seatrace.stbluesentinel.core.security.SignatureVerifier
import net.seatrace.stbluesentinel.core.security.TestVectors
import net.seatrace.stbluesentinel.data.db.AlertEntity
import net.seatrace.stbluesentinel.fcm.FcmContract
import net.seatrace.stbluesentinel.fcm.FcmEnvelopeParser
import net.seatrace.stbluesentinel.fcm.FcmParseResult
import net.seatrace.stbluesentinel.notifications.NotificationPreferences
import net.seatrace.stbluesentinel.notifications.NotifyDecision
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Base64

/**
 * Pure-JVM tests of the whole background path. No Activity, Application or UI object exists anywhere in
 * these tests - which is exactly the "FCM message while the UI is not open" condition.
 */
class AlertProcessorTest {
    private val signedAt = TestVectors.TIMESTAMP.toLong()

    private class FakeStore : AlertWriter, RejectionRecorder {
        val rows = linkedMapOf<String, AlertEntity>()
        val rejected = mutableListOf<Pair<String?, RejectReason>>()
        var failInsert = false
        override suspend fun insertIfNew(alert: AlertEntity): Long {
            if (failInsert) throw IllegalStateException("disk full")
            if (rows.containsKey(alert.alertId)) return -1
            rows[alert.alertId] = alert.copy(id = rows.size + 1L)
            return rows.size.toLong()
        }
        override suspend fun record(alertId: String?, reason: RejectReason, atMillis: Long) { rejected += alertId to reason }
    }

    private class FakeNotifier(var posts: Boolean = true) : AlertNotifier {
        val shown = mutableListOf<AlertEntity>()
        override fun notify(alert: AlertEntity): Boolean { if (posts) shown += alert; return posts }
    }

    private class Prefs(var master: Boolean = true, var test: Boolean = true, var off: Set<Severity> = emptySet()) : NotificationPreferences {
        override val masterEnabled get() = master
        override val testAlertsEnabled get() = test
        override fun isSeverityEnabled(severity: Severity) = severity !in off
    }

    private fun rig(nowSeconds: Long = signedAt + 10, store: FakeStore = FakeStore(), notifier: FakeNotifier = FakeNotifier(), prefs: Prefs = Prefs()) =
        Triple(store, notifier, AlertProcessor(
            verifier = AlertVerifier({ TestVectors.SECRET_BYTES }, { nowSeconds }),
            writer = store, rejections = store, notifier = notifier, prefs = prefs, nowMillis = { nowSeconds * 1000 },
        ))

    private fun frame(id: String, sev: String = "high", type: String = "danger_zone_entry", extra: String = "") =
        """{"schema_version":"1.0","source":"seatracepro","product":"bluesentinel","event":"vessel_alert","alert_id":"$id","alert_type":"$type","severity":"$sev","title":"Entered high-incident area","vessel":{"ship_name":"MV EXAMPLE"}$extra}"""

    private fun envelope(frame: String, ts: String = TestVectors.TIMESTAMP, id: String? = null): AlertEnvelope {
        val bytes = frame.toByteArray(Charsets.UTF_8)
        val alertId = id ?: Regex("\"alert_id\":\"([^\"]+)\"").find(frame)!!.groupValues[1]
        return AlertEnvelope("vessel_alert", alertId, ts, "sha256=" + SignatureVerifier.computeHex(TestVectors.SECRET_BYTES, ts, bytes), bytes)
    }

    @Test fun testA_liveVerifiedAlert_isStoredAndNotified() = runTest {
        val (store, notifier, p) = rig()
        val r = p.process(envelope(frame("A1")))
        assertTrue(r is ProcessResult.Notified)
        assertEquals(1, store.rows.size); assertEquals(1, notifier.shown.size)
        assertEquals(1L, notifier.shown[0].id)                       // notification carries the real row id
        assertTrue(notifier.shown[0].verified)
    }

    @Test fun duplicateAlertId_producesOneRowAndOneNotification() = runTest {
        val (store, notifier, p) = rig()
        assertTrue(p.process(envelope(frame("D1"))) is ProcessResult.Notified)
        assertTrue(p.process(envelope(frame("D1"))) === ProcessResult.Duplicate)   // SeaTracePro retry
        assertTrue(p.process(envelope(frame("D1"))) === ProcessResult.Duplicate)
        assertEquals(1, store.rows.size); assertEquals(1, notifier.shown.size)
    }

    @Test fun staleAlert_isStoredForHistory_butNeverNotified() = runTest {
        val (store, notifier, p) = rig(nowSeconds = signedAt + 3600)
        val r = p.process(envelope(frame("S1", sev = "critical")))
        assertEquals(NotifyDecision.SKIP_STALE, (r as ProcessResult.StoredSilently).decision)
        assertEquals("STALE", store.rows["S1"]!!.deliveryStatus)
        assertEquals(0, notifier.shown.size)
    }

    @Test fun invalidSignature_isRejected_notStored_notNotified_andAudited() = runTest {
        val (store, notifier, p) = rig()
        val good = envelope(frame("X1"))
        val forged = AlertEnvelope(good.event, good.alertId, good.timestamp, "sha256=" + "ab".repeat(32), good.frame)
        val r = p.process(forged)
        assertEquals(RejectReason.SIGNATURE_MISMATCH, (r as ProcessResult.Rejected).reason)
        assertEquals(0, store.rows.size); assertEquals(0, notifier.shown.size)
        assertEquals(listOf<Pair<String?, RejectReason>>("X1" to RejectReason.SIGNATURE_MISMATCH), store.rejected)
    }

    @Test fun notificationTest_isStoredAsTestAlert_andNotifiedAsTest() = runTest {
        val (store, notifier, p) = rig()
        p.process(envelope(frame("T1", sev = "info", type = "notification_test", extra = ""","test":true,"test_notice":"Dummy" """.trimEnd())))
        assertTrue(store.rows["T1"]!!.testAlert); assertTrue(notifier.shown.single().testAlert)
    }

    @Test fun disabledSeverity_isStillStored_butNotNotified() = runTest {
        val (store, notifier, p) = rig(prefs = Prefs(off = setOf(Severity.MEDIUM)))
        val r = p.process(envelope(frame("M1", sev = "medium")))
        assertEquals(NotifyDecision.SKIP_SEVERITY_DISABLED, (r as ProcessResult.StoredSilently).decision)
        assertEquals(1, store.rows.size); assertEquals(0, notifier.shown.size)
    }

    @Test fun androidRefusesToPost_alertStaysInHistory() = runTest {
        val (store, _, p) = rig(notifier = FakeNotifier(posts = false))
        assertTrue(p.process(envelope(frame("N1"))) is ProcessResult.StoredNotificationBlocked)
        assertEquals(1, store.rows.size)
    }

    @Test fun databaseFailure_doesNotCrash_andDoesNotNotify() = runTest {
        val store = FakeStore().apply { failInsert = true }
        val (_, notifier, p) = rig(store = store)
        assertTrue(p.process(envelope(frame("F1"))) is ProcessResult.StorageFailed)
        assertEquals(0, notifier.shown.size)
    }

    @Test fun testE_fcmDataMessageWithNoUi_endToEnd() = runTest {
        val (store, notifier, p) = rig()
        val f = frame("E1")
        val e = envelope(f)
        val fcmData = mapOf(
            FcmContract.KEY_VERSION to FcmContract.VERSION, FcmContract.KEY_EVENT to e.event!!, FcmContract.KEY_ALERT_ID to e.alertId!!,
            FcmContract.KEY_TIMESTAMP to e.timestamp!!, FcmContract.KEY_SIGNATURE to e.signature!!,
            FcmContract.KEY_FRAME to Base64.getEncoder().encodeToString(e.frame),
        )
        val parsed = FcmEnvelopeParser.parse(fcmData) as FcmParseResult.Envelope
        assertTrue(p.process(parsed.envelope) is ProcessResult.Notified)
        // Test "Database": the alert is already in history when the UI opens later.
        assertEquals("E1", store.rows.values.single().alertId)
        assertEquals(1, notifier.shown.size)
    }

    @Test fun masterSwitchOff_storesButNeverNotifies() = runTest {
        val (store, notifier, p) = rig(prefs = Prefs(master = false))
        p.process(envelope(frame("O1")))
        assertEquals(1, store.rows.size); assertEquals(0, notifier.shown.size)
    }
}
