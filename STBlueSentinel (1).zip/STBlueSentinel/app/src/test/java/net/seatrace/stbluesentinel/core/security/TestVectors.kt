package net.seatrace.stbluesentinel.core.security

/**
 * Cross-checked vector: the MAC below was computed independently with Python's hmac module AND with
 * the Node.js verifier snippet from the BlueSentinel developer reference. It uses a DUMMY secret -
 * the real signing secret must never be committed to source control.
 */
object TestVectors {
    const val SECRET = "test-secret-0123456789abcdef-NOT-REAL"
    const val TIMESTAMP = "1790000000"
    const val EXPECTED_HEX = "1369db11cbb94d59804218812b9c8669a8fd25a1aa10e702f5980e84198b7f84"
    val SECRET_BYTES: ByteArray get() = SECRET.toByteArray(Charsets.UTF_8)

    /** Compact single-line frame containing non-ASCII text (UTF-8 exactness) and an unknown field. */
    const val FRAME = """{"schema_version":"1.0","source":"seatracepro","product":"bluesentinel","event":"vessel_alert","alert_id":"12345","alert_type":"danger_zone_entry","severity":"high","title":"Entered high-incident area","message":"MV ÅLESUND entered an area with 4 reported incidents within 50 km.","timestamp_utc":"2026-10-04T10:25:31Z","created_utc":"2026-10-04T10:26:00Z","vessel":{"mmsi":123456789,"ship_name":"MV ÅLESUND","latitude":5.123456,"longitude":-0.123456},"threat":{"state":"INSIDE","area_label":"Near Lagos (NGA)","incidents_within_radius":4,"radius_km":50,"future_field":"ignored"}}"""
    val FRAME_BYTES: ByteArray get() = FRAME.toByteArray(Charsets.UTF_8)
    const val SIGNATURE_HEADER = "sha256=$EXPECTED_HEX"

    /** A "safe" in-window clock: 10 s after signing. */
    const val NOW = 1790000010L
}
