package net.seatrace.stbluesentinel.fcm

import net.seatrace.stbluesentinel.core.security.RejectReason
import net.seatrace.stbluesentinel.core.security.SignatureResult
import net.seatrace.stbluesentinel.core.security.SignatureVerifier
import net.seatrace.stbluesentinel.core.security.TestVectors
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import java.util.Base64
import org.junit.Test

class FcmEnvelopeParserTest {
    private fun payload(frame: ByteArray = TestVectors.FRAME_BYTES, extra: Map<String, String> = emptyMap()): Map<String, String> =
        mapOf(
            FcmContract.KEY_VERSION to FcmContract.VERSION,
            FcmContract.KEY_EVENT to "vessel_alert",
            FcmContract.KEY_ALERT_ID to "12345",
            FcmContract.KEY_TIMESTAMP to TestVectors.TIMESTAMP,
            FcmContract.KEY_SIGNATURE to TestVectors.SIGNATURE_HEADER,
            FcmContract.KEY_FRAME to Base64.getEncoder().encodeToString(frame),
        ) + extra

    private fun invalid(r: FcmParseResult) = (r as FcmParseResult.Invalid).reason

    @Test fun contractConstants_matchTheAgreedDesign() {
        assertEquals(300, FcmContract.TTL_SECONDS)          // aligned with the gateway's 300 s freshness window
        assertEquals(4096, FcmContract.MAX_PAYLOAD_BYTES)
    }

    @Test fun validPayload_roundTripsTheExactSignedBytes() {
        val env = (FcmEnvelopeParser.parse(payload()) as FcmParseResult.Envelope).envelope
        assertEquals("vessel_alert", env.event); assertEquals("12345", env.alertId)
        assertEquals(TestVectors.TIMESTAMP, env.timestamp)
        assertTrue(env.frame!!.contentEquals(TestVectors.FRAME_BYTES))
        // The decisive property: the signature still verifies over the bytes that came out of the push.
        assertEquals(SignatureResult.VALID, SignatureVerifier.verify(TestVectors.SECRET_BYTES, env.timestamp!!, env.frame!!, env.signature))
    }

    @Test fun nonAsciiFrameSurvivesTransport() {
        val env = (FcmEnvelopeParser.parse(payload()) as FcmParseResult.Envelope).envelope
        assertTrue(String(env.frame!!, Charsets.UTF_8).contains("\u00C5LESUND"))
    }

    @Test fun unrelatedPush_isIgnoredSilently() {
        assertTrue(FcmEnvelopeParser.parse(mapOf("promo" to "hello")) === FcmParseResult.NotBlueSentinel)
        assertTrue(FcmEnvelopeParser.parse(emptyMap()) === FcmParseResult.NotBlueSentinel)
    }

    @Test fun unsupportedVersion_isInvalid() =
        assertEquals(RejectReason.UNSUPPORTED_PUSH_VERSION, invalid(FcmEnvelopeParser.parse(payload(extra = mapOf("v" to "2")))))

    @Test fun missingOrEmptyFrame_isInvalid() {
        assertEquals(RejectReason.INVALID_PUSH_PAYLOAD, invalid(FcmEnvelopeParser.parse(payload() - FcmContract.KEY_FRAME)))
        assertEquals(RejectReason.INVALID_PUSH_PAYLOAD, invalid(FcmEnvelopeParser.parse(payload(extra = mapOf("frame_b64" to "")))))
    }

    @Test fun malformedBase64_isRejected_notRepaired() {
        listOf("not base64!!", "abcd\nefgh", "ab cd", "ab-_", "====")
            .forEach { assertEquals("'$it'", RejectReason.INVALID_PUSH_PAYLOAD, invalid(FcmEnvelopeParser.parse(payload(extra = mapOf("frame_b64" to it))))) }
    }

    @Test fun oversizePayload_isRejected_notTruncated() {
        val big = ByteArray(FcmContract.MAX_PAYLOAD_BYTES) { 'a'.code.toByte() }
        assertEquals(RejectReason.PUSH_PAYLOAD_TOO_LARGE, invalid(FcmEnvelopeParser.parse(payload(frame = big))))
    }

    @Test fun missingHeaderValues_arePassedThroughForTheVerifierToReject() {
        val env = (FcmEnvelopeParser.parse(payload() - FcmContract.KEY_SIGNATURE) as FcmParseResult.Envelope).envelope
        assertEquals(null, env.signature)
    }

    @Test fun payloadNeverCarriesASecretField() {
        val keys = setOf(FcmContract.KEY_VERSION, FcmContract.KEY_EVENT, FcmContract.KEY_ALERT_ID, FcmContract.KEY_TIMESTAMP, FcmContract.KEY_SIGNATURE, FcmContract.KEY_FRAME)
        assertTrue(keys.none { it.contains("secret", ignoreCase = true) || it.contains("key", ignoreCase = true) })
    }
}
