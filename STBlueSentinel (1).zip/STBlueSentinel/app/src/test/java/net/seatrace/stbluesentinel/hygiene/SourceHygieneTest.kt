package net.seatrace.stbluesentinel.hygiene

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/**
 * Guards the brief's "DO NOT" list by scanning the shipped sources (src/main + build script). It cannot prove the
 * absence of every possible mistake, but it fails the build if any of these specific regressions is introduced.
 */
class SourceHygieneTest {
    private val appDir: File = run {
        val configured = System.getProperty("stb.app.dir")?.let(::File)
        listOfNotNull(configured, File("."), File("app")).first { File(it, "src/main").isDirectory }
    }
    private val mainFiles: List<File> = File(appDir, "src/main").walkTopDown()
        .filter { it.isFile && it.extension in setOf("kt", "xml") }.toList()

    private fun relative(f: File) = f.relativeTo(appDir).path

    /** Removes comments so code-pattern checks do not trip on text that WARNS against a pattern. `(?<!:)//` keeps URLs like wss://. */
    private fun withoutComments(f: File): String {
        val text = f.readText()
        return if (f.extension == "xml") text.replace(Regex("<!--.*?-->", RegexOption.DOT_MATCHES_ALL), "")
        else text.replace(Regex("/\\*.*?\\*/", RegexOption.DOT_MATCHES_ALL), "").replace(Regex("(?<!:)//.*"), "")
    }

    /** [includeComments] = true for leak checks (a secret in a comment is still a leak); false for code-pattern checks. */
    private fun offenders(includeComments: Boolean = false, predicate: (File, String) -> Boolean): List<String> =
        mainFiles.filter { predicate(it, if (includeComments) it.readText() else withoutComments(it)) }.map(::relative)

    @Test fun scannerActuallyFoundTheSources() = assertTrue("found ${mainFiles.size} files", mainFiles.size > 30)

    @Test fun noHardcodedSigningSecret_noLongHexLiteralsAnywhereInShippedSources() {
        val hex64 = Regex("(?<![0-9A-Fa-f])[0-9A-Fa-f]{64}(?![0-9A-Fa-f])")
        assertEquals(emptyList<String>(), offenders(includeComments = true) { _, text -> hex64.containsMatchIn(text) })
    }

    @Test fun noCustomTlsTrustOrHostnameVerification() {
        val bad = listOf("TrustManager", "HostnameVerifier", "TrustAll", "ALLOW_ALL", "setSslSocketFactory", "sslSocketFactory", "X509Certificate")
        assertEquals(emptyList<String>(), offenders { _, text -> bad.any { text.contains(it) } })
    }

    @Test fun noCleartextAnywhere() {
        assertEquals(emptyList<String>(), offenders { _, t -> t.contains("cleartextTrafficPermitted=\"true\"") || t.contains("usesCleartextTraffic") })
        assertEquals(emptyList<String>(), offenders { _, t -> t.contains("debug-overrides") || t.contains("src=\"user\"") })
    }

    @Test fun plainWsSchemeOnlyAppearsInTheValidatorsRejectionMessage() {
        val plainWs = Regex("(?<![A-Za-z])ws://")
        assertEquals(listOf("src/main/java/net/seatrace/stbluesentinel/receiver/ReceiverUrlValidator.kt"),
            offenders { _, t -> plainWs.containsMatchIn(t) }.map { it.replace('\\', '/') })
    }

    @Test fun manifestRequestsOnlyInternetAndPostNotifications() {
        val manifest = File(appDir, "src/main/AndroidManifest.xml").readText()
        val perms = Regex("<uses-permission\\s+android:name=\"([^\"]+)\"").findAll(manifest).map { it.groupValues[1] }.toSet()
        assertEquals(setOf("android.permission.INTERNET", "android.permission.POST_NOTIFICATIONS"), perms)
    }

    @Test fun manifestDisablesBackup_declaresNoForegroundService_andKeepsServiceUnexported() {
        val manifest = File(appDir, "src/main/AndroidManifest.xml").readText()
        assertTrue(manifest.contains("android:allowBackup=\"false\""))
        assertTrue(!manifest.contains("foregroundServiceType") && !manifest.contains("FOREGROUND_SERVICE"))
        val service = Regex("<service[^>]*StbMessagingService[^>]*>").find(manifest)!!.value
        assertTrue(service.contains("android:exported=\"false\""))
    }

    @Test fun noSensitiveValuesInterpolatedIntoLogCalls() {
        val sensitive = Regex("""\$\{?\w*(secret|token|signature|frame|payload|sig)\w*""", RegexOption.IGNORE_CASE)
        val badLines = mainFiles.flatMap { f ->
            f.readLines().filter { (it.contains("SafeLog.") || it.contains("Log.")) && sensitive.containsMatchIn(it) }.map { "${relative(f)}: ${it.trim()}" }
        }
        assertEquals(emptyList<String>(), badLines)
    }

    @Test fun noSecretsInBuildConfigOrBuildScript() {
        val gradle = File(appDir, "build.gradle.kts").readText()
        assertTrue(!gradle.contains("buildConfigField"))
        assertTrue(!Regex("(?i)(password|secret)\\s*=\\s*\"[^\"]+\"").containsMatchIn(gradle))
    }

    @Test fun noPlaintextSharedPreferencesKeyForTheSecretOutsideTheKeystoreStore() {
        val bad = offenders { f, t -> !f.name.endsWith("KeystoreSecretStore.kt") && Regex("""putString\(\s*"[^"]*secret[^"]*"""", RegexOption.IGNORE_CASE).containsMatchIn(t) }
        assertEquals(emptyList<String>(), bad)
    }

    @Test fun noAdvertisingOrTrackingSdksDeclared() {
        val catalog = File(appDir, "../gradle/libs.versions.toml").takeIf { it.exists() }?.readText().orEmpty().lowercase()
        listOf("admob", "play-services-ads", "crashlytics", "firebase-analytics", "appsflyer", "adjust", "facebook", "mixpanel", "amplitude")
            .forEach { assertTrue("catalog must not contain $it", !catalog.contains(it)) }
    }
}
