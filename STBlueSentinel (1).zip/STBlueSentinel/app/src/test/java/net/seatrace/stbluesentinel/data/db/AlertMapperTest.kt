package net.seatrace.stbluesentinel.data.db

import net.seatrace.stbluesentinel.core.model.AlertPayload
import net.seatrace.stbluesentinel.core.model.DeliveryStatus
import net.seatrace.stbluesentinel.core.model.NearestIncidentPayload
import net.seatrace.stbluesentinel.core.model.ThreatPayload
import net.seatrace.stbluesentinel.core.model.VesselPayload
import net.seatrace.stbluesentinel.core.pipeline.VerificationOutcome
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant

class AlertMapperTest {
    private fun accepted(alert: AlertPayload, status: DeliveryStatus = DeliveryStatus.VERIFIED) =
        VerificationOutcome.Accepted(status, alert, rawFrame = "RAW", signedAtEpochSeconds = 1_790_000_000L, ageSeconds = 7)

    private val minimal = AlertPayload(alertId = "1", alertType = "speed_change", severity = "LOW", title = "T")

    @Test fun minimalAlert_mapsWithEveryOptionalFieldNull() {
        val e = accepted(minimal).toEntity(5_000)
        assertEquals("1", e.alertId); assertEquals("low", e.severity)                 // severity normalised to lower case
        assertNull(e.message); assertNull(e.shipName); assertNull(e.latitude); assertNull(e.areaLabel); assertNull(e.timestampUtc)
        assertTrue(e.verified); assertFalse(e.testAlert); assertFalse(e.read)
        assertEquals("RAW", e.rawPayload); assertEquals(5_000L, e.receivedAt); assertEquals(1_790_000_000L, e.signedAt); assertEquals(7L, e.deliveryAgeSeconds)
    }

    @Test fun deliveryStatusIsCarriedThrough() {
        assertEquals("VERIFIED", accepted(minimal, DeliveryStatus.VERIFIED).toEntity(0).deliveryStatus)
        assertEquals("STALE", accepted(minimal, DeliveryStatus.STALE).toEntity(0).deliveryStatus)
    }

    @Test(expected = IllegalArgumentException::class)
    fun aRejectedStatusCanNeverBeStored() { accepted(minimal, DeliveryStatus.REJECTED).toEntity(0) }

    @Test fun fullAlert_mapsEveryDocumentedField() {
        val full = minimal.copy(
            message = "m", timestampUtc = "2026-10-04T10:25:31Z", createdUtc = "2026-10-04T10:26:00Z", testNotice = "n",
            vessel = VesselPayload(1, 2, "MV EXAMPLE", 3, 5.123456, -0.123456, 14.7, 182.4, "2026-10-04T10:25:31Z"),
            threat = ThreatPayload("INSIDE", "Near Lagos (NGA)", 3.4, 4, 50.0, "2026-03-25", NearestIncidentPayload("2026-03-20", "Boarding", "Nigeria", "Offshore", 3.4)),
        )
        val e = accepted(full).toEntity(0)
        assertEquals(Instant.parse("2026-10-04T10:25:31Z").toEpochMilli(), e.timestampUtc)
        assertEquals(Instant.parse("2026-10-04T10:26:00Z").toEpochMilli(), e.createdUtc)
        assertEquals(Instant.parse("2026-10-04T10:25:31Z").toEpochMilli(), e.lastSeenUtc)
        assertEquals(2L, e.mmsi); assertEquals("MV EXAMPLE", e.shipName); assertEquals(5.123456, e.latitude!!, 0.0); assertEquals(-0.123456, e.longitude!!, 0.0)
        assertEquals("INSIDE", e.threatState); assertEquals(4, e.incidentsWithinRadius); assertEquals(50.0, e.radiusKm!!, 0.0)
        assertEquals("Boarding", e.nearestIncidentAttackType); assertEquals("Nigeria", e.nearestIncidentCountry); assertEquals(3.4, e.nearestIncidentDistanceKm!!, 0.0)
    }

    @Test fun isoParsing_acceptsZAndOffsets_andNeverInventsATimeForGarbage() {
        val expected = Instant.parse("2026-10-04T10:25:31Z").toEpochMilli()
        assertEquals(expected, parseIsoMillis("2026-10-04T10:25:31Z"))
        assertEquals(expected, parseIsoMillis("2026-10-04T12:25:31+02:00"))
        assertNull(parseIsoMillis("yesterday")); assertNull(parseIsoMillis("")); assertNull(parseIsoMillis(null))
    }

    @Test fun testFlagFollowsEitherSignal() {
        assertTrue(accepted(minimal.copy(test = true)).toEntity(0).testAlert)
        assertTrue(accepted(minimal.copy(alertType = "notification_test")).toEntity(0).testAlert)
    }
}
