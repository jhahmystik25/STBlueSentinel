package net.seatrace.stbluesentinel

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.rule.GrantPermissionRule
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import net.seatrace.stbluesentinel.core.model.Severity
import net.seatrace.stbluesentinel.core.pipeline.AlertEnvelope
import net.seatrace.stbluesentinel.core.pipeline.AlertProcessor
import net.seatrace.stbluesentinel.core.pipeline.AlertVerifier
import net.seatrace.stbluesentinel.core.pipeline.ProcessResult
import net.seatrace.stbluesentinel.core.security.KeystoreSecretStore
import net.seatrace.stbluesentinel.core.security.SignatureVerifier
import net.seatrace.stbluesentinel.data.db.RejectionEntity
import net.seatrace.stbluesentinel.data.db.StbDatabase
import net.seatrace.stbluesentinel.notifications.AndroidAlertNotifier
import net.seatrace.stbluesentinel.notifications.NotificationChannels
import net.seatrace.stbluesentinel.notifications.NotificationPreferences
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Real device: real Keystore secret, real Room, real Android notification manager, full verification path.
 * This is the on-device counterpart of BackgroundDeliveryTest (and the automated part of QA tests A, B and E).
 * It builds its own components, so it never touches the installed app's real secret or history.
 */
@RunWith(AndroidJUnit4::class)
class DevicePipelineInstrumentedTest {
    @get:Rule val permission: GrantPermissionRule =
        if (Build.VERSION.SDK_INT >= 33) GrantPermissionRule.grant(Manifest.permission.POST_NOTIFICATIONS) else GrantPermissionRule.grant()

    private val ctx: Context = ApplicationProvider.getApplicationContext()
    private val secretText = "instrumented-pipeline-secret-0123456789"
    private lateinit var store: KeystoreSecretStore
    private lateinit var db: StbDatabase
    private lateinit var processor: AlertProcessor
    private val nm get() = ctx.getSystemService(NotificationManager::class.java)
    private val allOn = object : NotificationPreferences {
        override val masterEnabled = true; override val testAlertsEnabled = true
        override fun isSeverityEnabled(severity: Severity) = true
    }

    @Before fun setUp() {
        NotificationChannels.create(ctx)
        store = KeystoreSecretStore(ctx, "stb_pipeline_test_key", "stb_pipeline_test_prefs").also { it.clear(); it.save(secretText) }
        db = Room.inMemoryDatabaseBuilder(ctx, StbDatabase::class.java).allowMainThreadQueries().build()
        processor = AlertProcessor(
            verifier = AlertVerifier({ store.load() }),
            writer = { db.alertDao().insertIgnore(it) },
            rejections = { id, reason, at -> db.rejectionDao().insert(RejectionEntity(alertId = id, reason = reason.name, receivedAt = at)) },
            notifier = AndroidAlertNotifier(ctx), prefs = allOn,
        )
    }
    @After fun tearDown() { nm.cancelAll(); db.close(); store.clear(); ctx.deleteSharedPreferences("stb_pipeline_test_prefs") }

    private fun envelope(id: String, ageSeconds: Long = 0, secret: String = secretText): AlertEnvelope {
        val ts = (System.currentTimeMillis() / 1000 - ageSeconds).toString()
        val frame = """{"schema_version":"1.0","source":"seatracepro","product":"bluesentinel","event":"vessel_alert","alert_id":"$id","alert_type":"danger_zone_entry","severity":"high","title":"Instrumented test alert","vessel":{"ship_name":"MV TEST"}}""".toByteArray()
        return AlertEnvelope("vessel_alert", id, ts, "sha256=" + SignatureVerifier.computeHex(secret.toByteArray(), ts, frame), frame)
    }
    private fun rows() = runBlocking { db.alertDao().observeAll().first() }

    @Test fun verifiedAlert_isStored_andAnAndroidNotificationIsReallyPosted() {
        val r = runBlocking { processor.process(envelope("I1")) }
        assertTrue(r is ProcessResult.Notified)
        assertEquals(1, rows().size)
        assertTrue(nm.activeNotifications.any { it.id == rows().single().id.toInt() && it.notification.channelId == NotificationChannels.ALERTS })
    }

    @Test fun duplicate_doesNotPostASecondNotification() {
        runBlocking { processor.process(envelope("I2")); processor.process(envelope("I2")) }
        assertEquals(1, rows().size); assertEquals(1, nm.activeNotifications.size)
    }

    @Test fun staleAlert_isStoredButPostsNothing() {
        runBlocking { processor.process(envelope("I3", ageSeconds = 3_600)) }
        assertEquals("STALE", rows().single().deliveryStatus); assertEquals(0, nm.activeNotifications.size)
    }

    @Test fun wrongSecret_postsNothingAndStoresNothing() {
        runBlocking { processor.process(envelope("I4", secret = "some-other-secret-value-0123456789")) }
        assertEquals(0, rows().size); assertEquals(0, nm.activeNotifications.size)
    }
}
