package net.seatrace.stbluesentinel

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import net.seatrace.stbluesentinel.core.security.KeystoreSecretStore
import net.seatrace.stbluesentinel.core.security.SaveResult
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.security.KeyStore
import javax.crypto.SecretKey

/** Runs on a real device/emulator against the real Android Keystore. Uses its OWN key alias and prefs file, never the app's real ones. */
@RunWith(AndroidJUnit4::class)
class KeystoreSecretStoreInstrumentedTest {
    private val ctx: Context = ApplicationProvider.getApplicationContext()
    private val alias = "stb_instrumented_test_key"
    private val prefsName = "stb_instrumented_test_prefs"
    private lateinit var store: KeystoreSecretStore
    private val secret = "instrumented-test-secret-0123456789abcdef"

    @Before fun setUp() { store = KeystoreSecretStore(ctx, alias, prefsName); store.clear() }
    @After fun tearDown() { store.clear(); ctx.deleteSharedPreferences(prefsName) }

    @Test fun roundTrip_returnsTheExactSecretBytes() {
        assertEquals(SaveResult.Saved, store.save(secret))
        assertArrayEquals(secret.toByteArray(), store.load())
    }

    @Test fun notStoredAsPlaintext_orAsPlainBase64OfIt() {
        store.save(secret)
        val stored = ctx.getSharedPreferences(prefsName, Context.MODE_PRIVATE).all.values.joinToString("|")
        val b64 = android.util.Base64.encodeToString(secret.toByteArray(), android.util.Base64.NO_WRAP)
        assertFalse(stored.contains(secret)); assertFalse(stored.contains(b64)); assertTrue(stored.isNotEmpty())
    }

    @Test fun keyIsNonExportable_theAppCannotReadItsBytes() {
        store.save(secret)
        val key = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.getKey(alias, null) as SecretKey
        assertNull(key.encoded)
    }

    @Test fun persistsAcrossInstances_likeAProcessRestartWithTheUiClosed() {
        store.save(secret)
        assertArrayEquals(secret.toByteArray(), KeystoreSecretStore(ctx, alias, prefsName).load())
        assertTrue(KeystoreSecretStore(ctx, alias, prefsName).hasSecret())
    }

    @Test fun eachSaveUsesAFreshIv() {
        store.save(secret); val first = ctx.getSharedPreferences(prefsName, Context.MODE_PRIVATE).getString("blob_v1", null)
        store.save(secret); val second = ctx.getSharedPreferences(prefsName, Context.MODE_PRIVATE).getString("blob_v1", null)
        assertNotNull(first); assertTrue(first != second)
    }

    @Test fun loadReturnsIndependentCopies_soCallersCanZeroThem() {
        store.save(secret)
        val a = store.load()!!; a.fill(0)
        assertArrayEquals(secret.toByteArray(), store.load())
    }

    @Test fun invalidSecretsAreRefused_andNothingIsStored() {
        assertEquals(SaveResult.Invalid, store.save("short")); assertEquals(SaveResult.Invalid, store.save("has a space inside the secret value"))
        assertFalse(store.hasSecret()); assertNull(store.load())
    }

    @Test fun clearRemovesTheSecretAndTheKey() {
        store.save(secret); store.clear()
        assertFalse(store.hasSecret()); assertNull(store.load())
        assertFalse(KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.containsAlias(alias))
    }

    @Test fun aCorruptedBlob_isTreatedAsNoSecret_neverAsAWrongSecret() {
        store.save(secret)
        ctx.getSharedPreferences(prefsName, Context.MODE_PRIVATE).edit().putString("blob_v1", "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA").commit()
        assertNull(store.load())
    }

    @Test fun overwritingReplacesTheOldSecret() {
        store.save(secret); store.save("a-second-different-secret-value-9876")
        assertArrayEquals("a-second-different-secret-value-9876".toByteArray(), store.load())
    }
}
