import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
}

// ---------------------------------------------------------------------------
// Firebase: the google-services plugin is applied only when the project-specific
// google-services.json exists. Debug builds without it still compile (push is then
// reported as "not configured" at runtime). Release builds REQUIRE it - see check below.
// ---------------------------------------------------------------------------
val googleServicesFile = file("google-services.json")
if (googleServicesFile.exists()) {
    apply(plugin = libs.plugins.google.services.get().pluginId)
}

// ---------------------------------------------------------------------------
// Release signing: values come from environment variables (CI) or an untracked
// keystore.properties file (local). Nothing is stored in source control.
// ---------------------------------------------------------------------------
val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun signingValue(env: String, prop: String): String? =
    System.getenv(env)?.takeIf { it.isNotBlank() } ?: keystoreProps.getProperty(prop)?.takeIf { it.isNotBlank() }

val releaseStoreFile = signingValue("STB_KEYSTORE_FILE", "storeFile")
val releaseStorePassword = signingValue("STB_KEYSTORE_PASSWORD", "storePassword")
val releaseKeyAlias = signingValue("STB_KEY_ALIAS", "keyAlias")
val releaseKeyPassword = signingValue("STB_KEY_PASSWORD", "keyPassword")
val hasReleaseSigning = listOf(releaseStoreFile, releaseStorePassword, releaseKeyAlias, releaseKeyPassword)
    .all { it != null } && file(releaseStoreFile!!).exists()

android {
    namespace = "net.seatrace.stbluesentinel"
    compileSdk = 36

    defaultConfig {
        applicationId = "net.seatrace.stbluesentinel"
        minSdk = 29
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    signingConfigs {
        if (hasReleaseSigning) {
            create("release") {
                storeFile = file(releaseStoreFile!!)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        debug {
            versionNameSuffix = "-debug"
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Deliberately NO fallback to the debug key. Without signing config the
            // release tasks fail fast (see taskGraph check below).
            if (hasReleaseSigning) signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true   // only used for BuildConfig.DEBUG (release-safe logging). No secrets here.
    }

    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }

    testOptions { unitTests { isIncludeAndroidResources = true } }

    lint { abortOnError = true; checkReleaseBuilds = true }
}

kotlin {
    compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) }
}

// Fail fast, with an actionable message, instead of silently producing an unsigned
// artifact or a build with no Firebase config.
gradle.taskGraph.whenReady {
    val releaseRequested = gradle.startParameter.taskNames.any {
        it.endsWith("assembleRelease") || it.endsWith("bundleRelease")
    }
    if (releaseRequested) {
        if (!hasReleaseSigning) throw GradleException(
            "Release signing is not configured. Set STB_KEYSTORE_FILE / STB_KEYSTORE_PASSWORD / " +
                "STB_KEY_ALIAS / STB_KEY_PASSWORD or create keystore.properties (see keystore.properties.example)."
        )
        if (!googleServicesFile.exists()) throw GradleException(
            "app/google-services.json is missing. Download it from your Firebase project for package " +
                "net.seatrace.stbluesentinel (see docs/FIREBASE_SETUP.md)."
        )
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.core.splashscreen)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.navigation.compose)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.extended)
    debugImplementation(libs.androidx.compose.ui.tooling)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    implementation(libs.androidx.datastore.preferences)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.serialization.json)

    // Used only for the optional "test receiver connection" action (wss:// only, default TLS validation).
    implementation(libs.okhttp)

    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.messaging)

    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
    testImplementation(libs.robolectric)
    testImplementation(libs.androidx.test.core)
    testImplementation(libs.androidx.test.ext.junit)
    testImplementation(libs.androidx.room.testing)

    androidTestImplementation(libs.androidx.test.ext.junit)
    androidTestImplementation(libs.androidx.test.runner)
    androidTestImplementation(libs.androidx.test.rules)
    androidTestImplementation(libs.kotlinx.coroutines.test)
}
