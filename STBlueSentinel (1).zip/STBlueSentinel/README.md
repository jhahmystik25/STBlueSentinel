# STBlueSentinel

Android companion app for **SeaTracePro BlueSentinel** maritime security alerts. It receives alerts that a receiver gateway has already verified, **verifies them again on the phone**, stores them locally, and shows trustworthy Android notifications, including when the app is closed, the screen is locked or the phone is idle.

| | |
|---|---|
| Package | `net.seatrace.stbluesentinel` |
| Version | `1.0.0` (versionCode `1`) |
| Android | minSdk **29** (Android 10) · targetSdk / compileSdk **36** (Android 16) |
| Stack | Kotlin, Jetpack Compose + Material 3, Room, Coroutines, Firebase Cloud Messaging, Android Keystore |
| Ads / analytics / tracking | none |

> **Honest status.** The security core, push parsing, notification policy, URL validation and status logic were compiled and run in isolation (92 tests), the Node gateway has 58 passing tests, and the gateway's push payload was verified by the app's own Kotlin verifier. The Android UI, Room, Robolectric and on-device tests are **written but have not yet been built or run**: that happens on your first Gradle sync. See [docs/TESTING.md](docs/TESTING.md). No APK/AAB is included; build them with the steps below.

## How it works (and what it deliberately is not)

BlueSentinel does **not** let a phone subscribe to SeaTracePro. SeaTracePro opens a connection **to your** public `wss://` endpoint and sends one signed frame per alert. A phone is not a publicly reachable server, so a small gateway sits in the middle:

```
SeaTracePro --wss, X-SeaTrace-* headers, ONE signed frame--> Receiver Gateway (public, TLS)
                                                               | verify HMAC, 300 s window, de-duplicate
                                                               v
                                                      FCM data message (high priority, 300 s TTL)
                                                               v
                                          STBlueSentinel: verify again -> Room -> notification
```

* The **gateway** ([gateway/](gateway/README.md)) holds the signing secret(s) and is the only thing SeaTracePro talks to.
* The **app** never opens a SeaTracePro socket and never pretends to be a server. It receives push messages through Android's supported background mechanism and re-checks every one with its own copy of the secret, so a forged push is rejected.
* **FCM** is the background delivery path. There is no always-on service, no polling, no foreground service and no battery-exemption request.

Details: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) · gateway ↔ app message format: [docs/FCM_CONTRACT.md](docs/FCM_CONTRACT.md).

## Repository layout

```
app/                     Android application (Kotlin)
  core/security/         HMAC verifier, timestamp policy, Keystore secret store
  core/pipeline/         AlertVerifier + AlertProcessor (verify -> dedupe -> store -> notify)
  fcm/                   FirebaseMessagingService + push payload parser
  notifications/         channels, notifier, permission/battery diagnostics
  data/                  Room database, config repository
  ui/                    Compose screens (dashboard, history, detail, settings, help)
gateway/                 Reference Node.js receiver gateway (ws + firebase-admin)
docs/                    architecture, FCM contract, Firebase setup, release signing, testing
```

## Quick start (development)

1. **Open in Android Studio** (a recent release that supports Android Gradle Plugin 8.11). The Gradle wrapper *jar* is not included; Android Studio generates it, or run `gradle wrapper --gradle-version 8.14.3` once. If a dependency version cannot be resolved, bump it in `gradle/libs.versions.toml`.
2. **Firebase** (needed for push, not for compiling): follow [docs/FIREBASE_SETUP.md](docs/FIREBASE_SETUP.md) and place `google-services.json` in `app/`. Without it a debug build still runs; the app reports *Push: Not configured*.
3. **Run the debug build** on a device or emulator (Android 10+).
4. **In the app**: *Settings → Receiver* enter your `wss://` address, *Settings → Security* paste the BlueSentinel signing secret, allow notifications.
5. **Run the gateway** ([gateway/README.md](gateway/README.md)), register the phone (*Settings → This device → Copy push token*), and send a test alert with `scripts/simulate-seatrace.js` or SeaTracePro's own test notification.

## No Android Studio? Build the APK in the cloud

1. Put this project in a GitHub repository (your own, private is fine).
2. *Optional, for push:* add the contents of `google-services.json` as a repository secret named `GOOGLE_SERVICES_JSON` ([docs/FIREBASE_SETUP.md](docs/FIREBASE_SETUP.md)).
3. **Actions → Build debug APK → Run workflow.** When it finishes, download the **STBlueSentinel-debug-apk** artifact and install `app-debug.apk` (allow installs from your file manager/browser when Android asks).

This yields a **debug** build for testing. A Play-ready **signed release** APK/AAB needs your own keystore ([docs/RELEASE_SIGNING.md](docs/RELEASE_SIGNING.md)). The workflow has not been run by its author, so the first run may need a small fix; the log shows which line.

## Build

| Artifact | Command | Output |
|---|---|---|
| Debug APK (testing only) | `./gradlew assembleDebug` | `app/build/outputs/apk/debug/app-debug.apk` |
| **Signed release APK** | `./gradlew assembleRelease` | `app/build/outputs/apk/release/app-release.apk` |
| **Signed release AAB** (Play upload) | `./gradlew bundleRelease` | `app/build/outputs/bundle/release/app-release.aab` |

Release builds **fail fast** unless signing credentials *and* `app/google-services.json` are present. There is no fallback to the debug key: a debug-signed file can never be mistaken for a release. Setup: [docs/RELEASE_SIGNING.md](docs/RELEASE_SIGNING.md).

## Permissions

| Permission | Why |
|---|---|
| `INTERNET` | Push delivery and the optional "Test connection" reachability check. |
| `POST_NOTIFICATIONS` (Android 13+) | To show alerts. Requested only after an in-app explanation, never on launch. |

Nothing else: no location, camera, microphone, contacts, SMS, phone, foreground-service or battery-exemption permissions. A build-time test enforces this list.

## Notifications

* Three channels: **BlueSentinel Alerts** (critical, high; heads-up), **BlueSentinel Updates** (medium, low), **BlueSentinel Test Alerts**.
* Title always spells the severity in words, e.g. `BlueSentinel — HIGH`; colour is only a secondary cue.
* **Test alerts** (`notification_test` / `"test": true`) use their own channel and the title **TEST ALERT — NOT A REAL INCIDENT**.
* The lock-screen version shows no vessel or position, only the severity.
* **One notification per alert**: duplicates (SeaTracePro retries) produce neither a second row nor a second notification.
* **Delayed alerts**: a verified alert signed more than **15 minutes** before it reached the phone is stored and marked *DELAYED* but **never** raises a notification. Alerts more than 60 s in the future, or older than 24 h, are rejected.
* Preferences only suppress notifications; verified alerts are always saved to history.

## Background behaviour

Alerts arrive through FCM, which Android delivers without any UI: the system starts the app's process and runs `FirebaseMessagingService`, which verifies, stores and notifies. The full per-state test plan is in [docs/QA_BACKGROUND_NOTIFICATIONS.md](docs/QA_BACKGROUND_NOTIFICATIONS.md); the headlines:

| State | Expected |
|---|---|
| App open / in background / screen locked / screen off / UI closed | Alert stored + notification (lock screen follows your Android lock-screen settings) |
| Device idle (Doze) | High-priority FCM can wake the device; delivery is subject to Android/FCM rules, not guaranteed |
| Network temporarily unavailable | FCM queues it, **but only for 5 minutes**; after that the alert is not delivered to the phone |
| Notifications disabled in Android | Alert is still stored; no notification can be shown. The app explains and links to Settings |
| Battery "Restricted" / aggressive OEM battery manager | Delivery may be delayed or blocked. *Help & diagnostics* shows your state |
| **App force-stopped by the user** | **Android blocks all background activity until the app is opened again. This cannot be bypassed and is not attempted.** Alerts sent meanwhile are not delivered |

Do not read this as a delivery guarantee: Android itself can block notifications, and the 5-minute TTL is deliberate (a live alert must not arrive late).

## Security model

* **Where verification happens:** the gateway on the live handshake (headers, 300 s replay window, HMAC over exact bytes, de-duplication) and again in the app (HMAC, timestamp policy, schema, de-duplication).
* **Signing secret:** entered once, stored as AES-256-GCM ciphertext under a non-exportable Android Keystore key, never shown again, never logged, never in BuildConfig/resources/FCM/URLs/backups. The Settings screen blocks screenshots.
* **TLS:** `wss://` only; no custom trust managers or hostname verifiers; cleartext disabled app-wide.
* **Rejections** are audited by reason and alert ID only (never payloads, headers or secrets).
* `SourceHygieneTest` fails the build if a hard-coded 64-hex secret, custom TLS trust, cleartext, extra permission, foreground service, secret-in-log or tracking SDK appears.

## Privacy

No advertising, tracking or analytics SDKs (Firebase Analytics collection is switched off). Alert history stays on the device and is excluded from cloud backup and device transfer. FCM itself uses a Firebase installation ID and push token; the push token leaves the phone only when *you* copy it to your gateway operator. Review Google's Firebase data disclosures when completing the Play Data safety form.

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| Dashboard says **NOT CONFIGURED** | No valid receiver URL or no signing secret saved |
| **ATTENTION NEEDED** | Configured, but push isn't active or notifications are off; the line below says which |
| *Push: Not configured* | Build has no `google-services.json` |
| *Security verification failed* | A signature was rejected after your last accepted alert: wrong secret, or the vessel's secret was regenerated |
| Alerts in history marked **DELAYED**, no notification | Delivery took more than 15 minutes (phone was idle/offline) |
| Nothing arrives | See *Help & diagnostics* and the gateway log (`handshake_rejected`, `frame_rejected`, `push_failed`, `device_token_invalid`) |
| Gateway: `device_token_invalid` | App reinstalled/data cleared: re-copy the push token and re-run `device:add` |

## Known limitations

* A phone offline for more than 5 minutes misses that alert (still visible in SeaTracePro). A future "catch-up" feature could recover it as labelled history.
* One signing secret in the Android UI (V1); the gateway supports many.
* English-only strings; no tablet-specific layouts.
* The reference gateway's de-duplication is in-memory (single instance).

## Documentation

[Architecture](docs/ARCHITECTURE.md) · [FCM contract](docs/FCM_CONTRACT.md) · [Firebase setup](docs/FIREBASE_SETUP.md) · [Release signing](docs/RELEASE_SIGNING.md) · [Testing](docs/TESTING.md) · [Background QA checklist](docs/QA_BACKGROUND_NOTIFICATIONS.md) · [Status](docs/STATUS.md) · [Gateway](gateway/README.md)
